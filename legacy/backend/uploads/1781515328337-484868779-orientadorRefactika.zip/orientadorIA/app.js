// ============================================================
// ORIENTADOR IA — by REFACTIKA
// Lean career orientation app with AI-first sector guidance
// ============================================================

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ============================================================
// 1. DATA — Sectors, Academies, Market, Sources
// ============================================================

const SECTORS = {
  marketing: {
    id: 'marketing',
    name: 'Marketing',
    icon: '📣',
    tagline: 'Vender en la era de la IA generativa',
    aiImpact: 'Alto',
    impactScore: 92,
    description: 'La IA redefine cómo se crea contenido, se segmenta audiencia y se mide el ROI. Los perfiles que dominan IA generativa ya ganan 30–40% más.',
    todayYouShouldKnow: [
      'Prompt engineering para copywriting (ChatGPT, Claude, Gemini)',
      'IA generativa de imagen y vídeo (Midjourney, Runway, Sora)',
      'Automatización de campañas con herramientas de IA (HubSpot AI, Jasper)',
      'Analítica predictiva con GA4 + modelos de atribución IA',
      'SEO para búsquedas de IA (AEO, GEO)',
    ],
    trends: [
      { k: 'IA generativa aplicada al contenido', v: '+148%', color: 'orange' },
      { k: 'Marketing automation con IA', v: '+92%', color: 'orange' },
      { k: 'Vídeo generativo', v: '+210%', color: 'orange' },
    ],
    global: {
      demandIndex: 88,
      growthYoy: '+22%',
      aiPenetration: 58,
      topHubs: [
        { city: 'Nueva York', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 92 },
        { city: 'São Paulo', country: '🇧🇷', weight: 76 },
        { city: 'Madrid', country: '🇪🇸', weight: 72 },
        { city: 'CDMX', country: '🇲🇽', weight: 68 },
        { city: 'Berlín', country: '🇩🇪', weight: 64 },
      ],
      hotSkills: [
        { skill: 'Generative AI content', demand: 96 },
        { skill: 'Prompt engineering', demand: 92 },
        { skill: 'Marketing automation IA', demand: 88 },
        { skill: 'Atribución con ML', demand: 76 },
        { skill: 'AEO / GEO (SEO para IA)', demand: 72 },
        { skill: 'Video generativo', demand: 68 },
      ],
      topHiring: ['Google', 'Meta', 'WPP', 'Publicis', 'HubSpot', 'Salesforce'],
      reportHighlight: 'El 71% de los CMOs globales ya incluye IA generativa como skill crítica (LinkedIn Economic Graph 2026).',
    },
    academy: 'ia-marketing',
  },
  desarrollo: {
    id: 'desarrollo',
    name: 'Desarrollo Web & Software',
    icon: '💻',
    tagline: 'Construir software con IA como copiloto',
    aiImpact: 'Muy alto',
    impactScore: 95,
    description: 'Copilots y agentes de IA transforman la productividad del desarrollador. El 78% de perfiles senior ya usan IA a diario.',
    todayYouShouldKnow: [
      'GitHub Copilot, Cursor, Claude Code en workflow real',
      'Arquitectura de agentes IA (LangChain, LangGraph, MCP)',
      'RAG y bases de datos vectoriales (Pinecone, Weaviate)',
      'Fine-tuning y embeddings para casos de uso específicos',
      'Evals, observabilidad y seguridad en sistemas LLM',
    ],
    trends: [
      { k: 'Desarrolladores con IA', v: '+182%', color: 'orange' },
      { k: 'Ingeniería de prompts', v: '+240%', color: 'orange' },
      { k: 'AI agents engineering', v: '+310%', color: 'orange' },
    ],
    global: {
      demandIndex: 96,
      growthYoy: '+38%',
      aiPenetration: 72,
      topHubs: [
        { city: 'San Francisco', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 88 },
        { city: 'Berlín', country: '🇩🇪', weight: 82 },
        { city: 'Bangalore', country: '🇮🇳', weight: 80 },
        { city: 'Madrid', country: '🇪🇸', weight: 74 },
        { city: 'Santiago', country: '🇨🇱', weight: 68 },
      ],
      hotSkills: [
        { skill: 'AI agents / LangChain', demand: 98 },
        { skill: 'Copilot workflows', demand: 95 },
        { skill: 'RAG + vector DBs', demand: 92 },
        { skill: 'Fine-tuning y embeddings', demand: 84 },
        { skill: 'Evals & observability', demand: 78 },
        { skill: 'MCP / model integration', demand: 74 },
      ],
      topHiring: ['Anthropic', 'OpenAI', 'Google', 'Microsoft', 'Stripe', 'Shopify'],
      reportHighlight: 'El 78% de perfiles senior ya usa IA como copiloto diario. Los equipos con IA son 2.5x más productivos (GitHub Octoverse 2026).',
    },
    academy: 'ia-desarrollo',
  },
  ventas: {
    id: 'ventas',
    name: 'Ventas & Negocio',
    icon: '💼',
    tagline: 'Cerrar más con menos, con IA',
    aiImpact: 'Alto',
    impactScore: 85,
    description: 'Pipelines automatizados, scoring predictivo y asistentes de venta con IA elevan el ratio de conversión un 25–40%.',
    todayYouShouldKnow: [
      'CRM con IA (HubSpot AI, Salesforce Einstein)',
      'Prospección automática con herramientas de IA (Apollo, Clay)',
      'Asistentes de venta y transcripción (Gong, Fireflies)',
      'Generación de propuestas con IA',
      'Análisis predictivo de lead scoring',
    ],
    trends: [
      { k: 'Sales ops con IA', v: '+96%', color: 'orange' },
      { k: 'Revenue operations', v: '+72%', color: 'orange' },
      { k: 'Conversational AI sales', v: '+134%', color: 'orange' },
    ],
    global: {
      demandIndex: 82,
      growthYoy: '+18%',
      aiPenetration: 46,
      topHubs: [
        { city: 'Nueva York', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 86 },
        { city: 'CDMX', country: '🇲🇽', weight: 78 },
        { city: 'Bogotá', country: '🇨🇴', weight: 72 },
        { city: 'Barcelona', country: '🇪🇸', weight: 70 },
        { city: 'Dubai', country: '🇦🇪', weight: 64 },
      ],
      hotSkills: [
        { skill: 'Revenue Operations', demand: 92 },
        { skill: 'AI-powered prospecting', demand: 88 },
        { skill: 'Conversational AI', demand: 82 },
        { skill: 'CRM + IA (HubSpot, Salesforce)', demand: 80 },
        { skill: 'Sales forecasting ML', demand: 72 },
        { skill: 'Call analytics (Gong, Chorus)', demand: 70 },
      ],
      topHiring: ['Salesforce', 'HubSpot', 'Oracle', 'ServiceNow', 'Adobe', 'Zoom'],
      reportHighlight: 'Los equipos de ventas con IA cierran 25% más rápido y escalan sin más cabezas (Gartner Sales Outlook 2026).',
    },
    academy: 'ia-ventas',
  },
  logistica: {
    id: 'logistica',
    name: 'Logística',
    icon: '📦',
    tagline: 'Optimización inteligente de la cadena',
    aiImpact: 'Alto',
    impactScore: 80,
    description: 'Planificación predictiva, rutas optimizadas con IA y almacenes autónomos. La logística vive su mayor salto desde la automatización.',
    todayYouShouldKnow: [
      'Planificación de demanda con ML (SAP IBP, o9)',
      'Optimización de rutas con IA (Onfleet, Bringg)',
      'Digital twins de cadena de suministro',
      'Computer vision en almacén (quality checks)',
      'Forecasting y análisis de stocks con IA',
    ],
    trends: [
      { k: 'Supply chain analytics', v: '+88%', color: 'orange' },
      { k: 'Last-mile con IA', v: '+112%', color: 'orange' },
      { k: 'Warehouse automation', v: '+70%', color: 'orange' },
    ],
    global: {
      demandIndex: 76,
      growthYoy: '+15%',
      aiPenetration: 38,
      topHubs: [
        { city: 'Shanghai', country: '🇨🇳', weight: 100 },
        { city: 'Rotterdam', country: '🇳🇱', weight: 88 },
        { city: 'Singapur', country: '🇸🇬', weight: 84 },
        { city: 'Valencia', country: '🇪🇸', weight: 68 },
        { city: 'São Paulo', country: '🇧🇷', weight: 64 },
        { city: 'Ciudad de Panamá', country: '🇵🇦', weight: 58 },
      ],
      hotSkills: [
        { skill: 'Demand forecasting ML', demand: 88 },
        { skill: 'Route optimization IA', demand: 82 },
        { skill: 'Digital twins supply chain', demand: 76 },
        { skill: 'Computer vision almacén', demand: 70 },
        { skill: 'SAP IBP / o9 platforms', demand: 68 },
        { skill: 'Sustainable logistics', demand: 64 },
      ],
      topHiring: ['DHL', 'Maersk', 'Amazon', 'UPS', 'Inditex', 'Walmart'],
      reportHighlight: 'La logística inteligente ahorra 18% en costes operativos y reduce 25% las entregas fallidas (McKinsey Supply Chain 2026).',
    },
    academy: 'ia-logistica',
  },
  gestion: {
    id: 'gestion',
    name: 'Administración & Gestión',
    icon: '📊',
    tagline: 'Dirigir con datos y copilotos IA',
    aiImpact: 'Muy alto',
    impactScore: 90,
    description: 'Reportes financieros automáticos, análisis de KPI en tiempo real, agentes de gestión que automatizan tareas repetitivas de dirección.',
    todayYouShouldKnow: [
      'Business intelligence con IA (Power BI Copilot, Tableau Pulse)',
      'Automatización de procesos (RPA + IA)',
      'Análisis financiero con IA generativa',
      'Gestión de proyectos con asistentes IA (ClickUp Brain, Notion AI)',
      'Estrategia data-driven con modelos de previsión',
    ],
    trends: [
      { k: 'FP&A con IA', v: '+102%', color: 'orange' },
      { k: 'BI + copilots', v: '+156%', color: 'orange' },
      { k: 'Process automation', v: '+84%', color: 'orange' },
    ],
    global: {
      demandIndex: 90,
      growthYoy: '+25%',
      aiPenetration: 62,
      topHubs: [
        { city: 'Nueva York', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 94 },
        { city: 'Singapur', country: '🇸🇬', weight: 88 },
        { city: 'Madrid', country: '🇪🇸', weight: 74 },
        { city: 'Dubai', country: '🇦🇪', weight: 72 },
        { city: 'CDMX', country: '🇲🇽', weight: 68 },
      ],
      hotSkills: [
        { skill: 'BI con copilots IA', demand: 94 },
        { skill: 'FP&A con IA', demand: 88 },
        { skill: 'Process automation (RPA+IA)', demand: 82 },
        { skill: 'Power BI Copilot', demand: 80 },
        { skill: 'Notion AI / ClickUp Brain', demand: 74 },
        { skill: 'Strategic forecasting ML', demand: 70 },
      ],
      topHiring: ['Deloitte', 'EY', 'KPMG', 'Accenture', 'McKinsey', 'BCG'],
      reportHighlight: 'El 64% de los C-level globales planea desplegar copilots IA en gestión el próximo año (Deloitte State of AI 2026).',
    },
    academy: 'ia-gestion',
  },
  operaciones: {
    id: 'operaciones',
    name: 'Operaciones',
    icon: '⚙️',
    tagline: 'Fábricas, servicios y procesos con IA',
    aiImpact: 'Alto',
    impactScore: 86,
    description: 'Copilots operativos, monitoreo predictivo y agentes que reducen tareas repetitivas. Operaciones es uno de los sectores con mayor retorno rápido de IA.',
    todayYouShouldKnow: [
      'Asistentes IA para operaciones (Microsoft Copilot, agentes personalizados)',
      'Mantenimiento predictivo con IA',
      'Automatización de procesos (RPA + agentes IA)',
      'Monitoreo en tiempo real con computer vision',
      'Optimización de KPIs operativos con IA',
    ],
    trends: [
      { k: 'Copilots operativos', v: '+118%', color: 'orange' },
      { k: 'Predictive maintenance', v: '+92%', color: 'orange' },
      { k: 'Process automation', v: '+104%', color: 'orange' },
    ],
    global: {
      demandIndex: 84,
      growthYoy: '+19%',
      aiPenetration: 48,
      topHubs: [
        { city: 'Detroit', country: '🇺🇸', weight: 100 },
        { city: 'Stuttgart', country: '🇩🇪', weight: 94 },
        { city: 'Tokio', country: '🇯🇵', weight: 88 },
        { city: 'Barcelona', country: '🇪🇸', weight: 72 },
        { city: 'Monterrey', country: '🇲🇽', weight: 68 },
        { city: 'São Paulo', country: '🇧🇷', weight: 64 },
      ],
      hotSkills: [
        { skill: 'Asistentes IA para operaciones', demand: 92 },
        { skill: 'Mantenimiento predictivo', demand: 88 },
        { skill: 'Automatización con agentes', demand: 82 },
        { skill: 'Computer vision operativa', demand: 76 },
        { skill: 'Lean + IA', demand: 72 },
        { skill: 'IoT + edge AI', demand: 68 },
      ],
      topHiring: ['Siemens', 'Bosch', 'GE', 'Repsol', 'Ferrovial', 'Nestlé'],
      reportHighlight: 'Las empresas operativas con IA recuperan 12-18% de su margen bruto en el primer año (McKinsey Operations 2026).',
    },
    academy: 'ia-operaciones',
  },
  rrhh: {
    id: 'rrhh',
    name: 'Recursos Humanos',
    icon: '👥',
    tagline: 'Personas y talento potenciados por IA',
    aiImpact: 'Alto',
    impactScore: 84,
    description: 'Selección, formación, clima laboral y analítica de personas. RRHH pasa de administración a ser el arquitecto de la transformación con IA.',
    todayYouShouldKnow: [
      'Reclutamiento con IA (screening, matching, entrevistas)',
      'People analytics con IA generativa',
      'Onboarding automatizado con agentes',
      'Learning con copilots personalizados',
      'Encuestas de clima con análisis de sentimiento IA',
    ],
    trends: [
      { k: 'People analytics con IA', v: '+124%', color: 'orange' },
      { k: 'Talent matching IA', v: '+98%', color: 'orange' },
      { k: 'Learning personalizado', v: '+142%', color: 'orange' },
    ],
    global: {
      demandIndex: 80,
      growthYoy: '+21%',
      aiPenetration: 44,
      topHubs: [
        { city: 'Londres', country: '🇬🇧', weight: 100 },
        { city: 'Nueva York', country: '🇺🇸', weight: 96 },
        { city: 'Madrid', country: '🇪🇸', weight: 78 },
        { city: 'Singapur', country: '🇸🇬', weight: 74 },
        { city: 'CDMX', country: '🇲🇽', weight: 66 },
        { city: 'Bogotá', country: '🇨🇴', weight: 60 },
      ],
      hotSkills: [
        { skill: 'Reclutamiento con IA', demand: 90 },
        { skill: 'People analytics', demand: 86 },
        { skill: 'Learning personalizado con IA', demand: 82 },
        { skill: 'Clima + sentimiento IA', demand: 76 },
        { skill: 'Compensación data-driven', demand: 70 },
        { skill: 'Onboarding con agentes', demand: 66 },
      ],
      topHiring: ['LinkedIn', 'Workday', 'SAP SuccessFactors', 'Grupo Adecco', 'Randstad', 'ManpowerGroup'],
      reportHighlight: 'El 58% de los CHROs líderes ya usa IA para selección y desarrollo (LinkedIn Future of Talent 2026).',
    },
    academy: 'ia-rrhh',
  },
  factoria: {
    id: 'factoria',
    name: 'Factoría de Software',
    icon: '🏭',
    tagline: 'Software con IA de inicio a fin',
    aiImpact: 'Muy alto',
    impactScore: 94,
    description: 'Fábricas de código que entregan con agentes IA, revisiones automatizadas y despliegue continuo. El coste por línea de código cae 40-60%.',
    todayYouShouldKnow: [
      'Pipelines CI/CD con agentes IA',
      'Code review automatizado con LLMs',
      'Testing generativo y quality gates IA',
      'AI coding assistants a escala de equipo',
      'Monitoring con observabilidad IA',
    ],
    trends: [
      { k: 'Agentic engineering', v: '+286%', color: 'orange' },
      { k: 'AI code review', v: '+168%', color: 'orange' },
      { k: 'Testing con IA', v: '+94%', color: 'orange' },
    ],
    global: {
      demandIndex: 92,
      growthYoy: '+34%',
      aiPenetration: 68,
      topHubs: [
        { city: 'San Francisco', country: '🇺🇸', weight: 100 },
        { city: 'Bangalore', country: '🇮🇳', weight: 92 },
        { city: 'Dublín', country: '🇮🇪', weight: 82 },
        { city: 'Barcelona', country: '🇪🇸', weight: 78 },
        { city: 'Buenos Aires', country: '🇦🇷', weight: 72 },
        { city: 'Medellín', country: '🇨🇴', weight: 68 },
      ],
      hotSkills: [
        { skill: 'Agentic software engineering', demand: 96 },
        { skill: 'AI pair programming', demand: 92 },
        { skill: 'DevOps + IA', demand: 86 },
        { skill: 'Test generation con IA', demand: 82 },
        { skill: 'Platform engineering', demand: 78 },
        { skill: 'AI observability', demand: 72 },
      ],
      topHiring: ['GitHub', 'GitLab', 'Stripe', 'Mercado Libre', 'Globant', 'EPAM'],
      reportHighlight: 'Los equipos con agentic engineering lanzan 3x más features al año con la misma plantilla (GitHub Octoverse 2026).',
    },
    academy: 'ia-factoria',
  },
  innovacion: {
    id: 'innovacion',
    name: 'Innovación',
    icon: '💡',
    tagline: 'Diseñar el próximo producto con IA',
    aiImpact: 'Muy alto',
    impactScore: 88,
    description: 'Prototipado ultra-rápido, exploración de oportunidades y validación acelerada. La innovación deja de tardar meses para hacerse en semanas.',
    todayYouShouldKnow: [
      'Prototipado con IA generativa (Figma Make, Claude Artifacts, Bolt)',
      'Descubrimiento de oportunidades con IA',
      'Validación de ideas con usuarios simulados IA',
      'Design thinking aumentado con IA',
      'Métricas de innovación con analytics IA',
    ],
    trends: [
      { k: 'Rapid prototyping con IA', v: '+212%', color: 'orange' },
      { k: 'AI product discovery', v: '+158%', color: 'orange' },
      { k: 'Synthetic user research', v: '+96%', color: 'orange' },
    ],
    global: {
      demandIndex: 82,
      growthYoy: '+28%',
      aiPenetration: 58,
      topHubs: [
        { city: 'San Francisco', country: '🇺🇸', weight: 100 },
        { city: 'Tel Aviv', country: '🇮🇱', weight: 88 },
        { city: 'Berlín', country: '🇩🇪', weight: 82 },
        { city: 'Madrid', country: '🇪🇸', weight: 74 },
        { city: 'Santiago', country: '🇨🇱', weight: 70 },
        { city: 'CDMX', country: '🇲🇽', weight: 64 },
      ],
      hotSkills: [
        { skill: 'Prototipado generativo', demand: 94 },
        { skill: 'Product discovery IA', demand: 88 },
        { skill: 'Validación acelerada', demand: 80 },
        { skill: 'Design systems IA', demand: 74 },
        { skill: 'Innovation metrics', demand: 68 },
        { skill: 'Venture building con IA', demand: 64 },
      ],
      topHiring: ['IDEO', 'Frog', 'Accenture Song', 'Telefónica Innovation', 'BBVA Next', 'Banco Santander Innovation'],
      reportHighlight: 'Los equipos de innovación con IA llegan al MVP 4x más rápido y reducen un 52% los costes de validación (BCG Henderson 2026).',
    },
    academy: 'ia-innovacion',
  },
  finanzas: {
    id: 'finanzas',
    name: 'Finanzas',
    icon: '💰',
    tagline: 'Finanzas inteligentes con IA',
    aiImpact: 'Muy alto',
    impactScore: 93,
    description: 'Cierre contable automático, análisis financiero con IA generativa, scoring de riesgo y planificación en tiempo real. Las finanzas se convierten en función estratégica con IA.',
    todayYouShouldKnow: [
      'FP&A con IA (forecasting automático)',
      'Cierre contable automatizado',
      'Análisis de riesgo con ML',
      'Tesorería predictiva',
      'Reporting con copilots (Power BI, Tableau)',
    ],
    trends: [
      { k: 'FP&A con IA', v: '+142%', color: 'orange' },
      { k: 'Risk scoring ML', v: '+98%', color: 'orange' },
      { k: 'Financial copilots', v: '+176%', color: 'orange' },
    ],
    global: {
      demandIndex: 90,
      growthYoy: '+27%',
      aiPenetration: 60,
      topHubs: [
        { city: 'Nueva York', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 96 },
        { city: 'Singapur', country: '🇸🇬', weight: 86 },
        { city: 'Madrid', country: '🇪🇸', weight: 76 },
        { city: 'São Paulo', country: '🇧🇷', weight: 70 },
        { city: 'CDMX', country: '🇲🇽', weight: 64 },
      ],
      hotSkills: [
        { skill: 'FP&A con IA', demand: 94 },
        { skill: 'Forecasting automatizado', demand: 88 },
        { skill: 'Risk scoring ML', demand: 84 },
        { skill: 'Financial copilots', demand: 80 },
        { skill: 'Cierre automatizado', demand: 74 },
        { skill: 'Tesorería predictiva', demand: 68 },
      ],
      topHiring: ['JP Morgan', 'Goldman Sachs', 'BBVA', 'Santander', 'Banco Macro', 'Deloitte Finance'],
      reportHighlight: 'El 71% de los CFOs globales priorizará IA en los próximos 12 meses (Deloitte CFO Signals 2026).',
    },
    academy: 'ia-finanzas',
  },
  sostenibilidad: {
    id: 'sostenibilidad',
    name: 'Sostenibilidad · RSC · Economía Circular',
    icon: '🌱',
    tagline: 'Impacto positivo acelerado con IA',
    aiImpact: 'Alto',
    impactScore: 82,
    description: 'Cálculo de huella, reporting ESG, economía circular y gobernanza. La IA hace viable medir y reducir impacto a gran escala.',
    todayYouShouldKnow: [
      'Cálculo de huella carbono con IA',
      'Reporting ESG automatizado (CSRD, GRI)',
      'Trazabilidad de cadena con IA',
      'Optimización de recursos circular',
      'Transición energética + ML',
    ],
    trends: [
      { k: 'ESG reporting con IA', v: '+156%', color: 'orange' },
      { k: 'Circular economy IA', v: '+92%', color: 'orange' },
      { k: 'Climate analytics', v: '+118%', color: 'orange' },
    ],
    global: {
      demandIndex: 78,
      growthYoy: '+24%',
      aiPenetration: 40,
      topHubs: [
        { city: 'Copenhague', country: '🇩🇰', weight: 100 },
        { city: 'Ámsterdam', country: '🇳🇱', weight: 94 },
        { city: 'Madrid', country: '🇪🇸', weight: 80 },
        { city: 'Nueva York', country: '🇺🇸', weight: 76 },
        { city: 'Santiago', country: '🇨🇱', weight: 70 },
        { city: 'São Paulo', country: '🇧🇷', weight: 66 },
      ],
      hotSkills: [
        { skill: 'ESG reporting IA', demand: 86 },
        { skill: 'Huella carbono automatizada', demand: 82 },
        { skill: 'Economía circular IA', demand: 78 },
        { skill: 'Climate risk ML', demand: 74 },
        { skill: 'Trazabilidad sostenible', demand: 68 },
        { skill: 'Compliance CSRD/GRI', demand: 62 },
      ],
      topHiring: ['Iberdrola', 'Enel', 'Acciona', 'Schneider Electric', 'Natura &Co', 'Unilever'],
      reportHighlight: 'Las empresas con IA en sostenibilidad reducen un 21% su huella con las mismas operaciones (WEF 2026).',
    },
    academy: 'ia-sostenibilidad',
  },
  tecnologia: {
    id: 'tecnologia',
    name: 'Tecnología · IT',
    icon: '🖥️',
    tagline: 'Infra, cloud, datos y ciberseguridad con IA',
    aiImpact: 'Muy alto',
    impactScore: 91,
    description: 'Arquitectura cloud, ciberseguridad, plataformas de datos y administración IT potenciadas con IA. El núcleo tecnológico de cualquier empresa.',
    todayYouShouldKnow: [
      'Arquitectura cloud con copilots (AWS, Azure, GCP)',
      'Ciberseguridad con IA (detección de amenazas, SOC copilots)',
      'Data platforms (Databricks, Snowflake) + IA',
      'MLOps y AIOps en producción',
      'Gobierno de IA (políticas, acceso, auditoría)',
    ],
    trends: [
      { k: 'AI-driven cloud architecture', v: '+148%', color: 'orange' },
      { k: 'Ciberseguridad con IA', v: '+176%', color: 'orange' },
      { k: 'MLOps / AIOps', v: '+124%', color: 'orange' },
    ],
    global: {
      demandIndex: 93,
      growthYoy: '+31%',
      aiPenetration: 64,
      topHubs: [
        { city: 'San Francisco', country: '🇺🇸', weight: 100 },
        { city: 'Seattle', country: '🇺🇸', weight: 94 },
        { city: 'Londres', country: '🇬🇧', weight: 86 },
        { city: 'Madrid', country: '🇪🇸', weight: 78 },
        { city: 'CDMX', country: '🇲🇽', weight: 72 },
        { city: 'Buenos Aires', country: '🇦🇷', weight: 68 },
      ],
      hotSkills: [
        { skill: 'Cloud con copilots (AWS, Azure)', demand: 94 },
        { skill: 'Ciberseguridad con IA', demand: 92 },
        { skill: 'Data platforms + IA', demand: 88 },
        { skill: 'MLOps / AIOps', demand: 82 },
        { skill: 'Gobierno de IA', demand: 74 },
        { skill: 'Arquitectura de agentes', demand: 70 },
      ],
      topHiring: ['AWS', 'Microsoft', 'Google Cloud', 'Telefónica Tech', 'NTT Data', 'IBM'],
      reportHighlight: 'El 72% de los CIOs redefine el rol de IT en torno a capacidades IA (Gartner IT Leadership 2026).',
    },
    academy: 'ia-tecnologia',
  },
  proyectos: {
    id: 'proyectos',
    name: 'Gestión de Proyectos',
    icon: '📋',
    tagline: 'Dirigir proyectos 3x más rápido con IA',
    aiImpact: 'Alto',
    impactScore: 85,
    description: 'Planificación, gestión de equipos, riesgos y comunicación potenciadas con IA. Lidera proyectos complejos con asistentes que te liberan del trabajo repetitivo.',
    todayYouShouldKnow: [
      'Copilots de gestión (ClickUp Brain, Notion AI, MS Project)',
      'Gestión de riesgos con IA predictiva',
      'Planificación automática de sprints y roadmaps',
      'Generación de minutas y seguimiento con IA',
      'Comunicación multilingüe con asistentes IA',
    ],
    trends: [
      { k: 'Project copilots', v: '+156%', color: 'orange' },
      { k: 'Risk prediction con IA', v: '+104%', color: 'orange' },
      { k: 'Agile + IA', v: '+92%', color: 'orange' },
    ],
    global: {
      demandIndex: 82,
      growthYoy: '+24%',
      aiPenetration: 50,
      topHubs: [
        { city: 'Nueva York', country: '🇺🇸', weight: 100 },
        { city: 'Londres', country: '🇬🇧', weight: 92 },
        { city: 'Singapur', country: '🇸🇬', weight: 84 },
        { city: 'Madrid', country: '🇪🇸', weight: 78 },
        { city: 'Bogotá', country: '🇨🇴', weight: 72 },
        { city: 'CDMX', country: '🇲🇽', weight: 68 },
      ],
      hotSkills: [
        { skill: 'Project copilots (ClickUp, Notion)', demand: 90 },
        { skill: 'Gestión de riesgos con IA', demand: 84 },
        { skill: 'Sprints con IA', demand: 80 },
        { skill: 'Minutas automáticas', demand: 76 },
        { skill: 'Comunicación multilingüe IA', demand: 68 },
        { skill: 'Portfolio management IA', demand: 64 },
      ],
      topHiring: ['Accenture', 'Deloitte', 'Capgemini', 'IBM Consulting', 'Everis', 'Indra'],
      reportHighlight: 'Los PMs con IA entregan 35% más rápido y con un 22% menos de sobrecostes (PMI Global 2026).',
    },
    academy: 'ia-proyectos',
  },
};

const GLOBAL_SOURCES = [
  { name: 'LinkedIn Economic Graph', desc: 'Índice global de habilidades y movilidad laboral' },
  { name: 'World Economic Forum', desc: 'Future of Jobs Report 2026' },
  { name: 'McKinsey Global Institute', desc: 'Workforce of the future + AI impact' },
  { name: 'Gartner Research', desc: 'Top trends y hype cycles por sector' },
  { name: 'Stanford HAI Index', desc: 'AI Index Report — indicadores globales' },
  { name: 'Deloitte State of AI', desc: 'Adopción corporativa de IA' },
  { name: 'GitHub Octoverse', desc: 'Tendencias globales de desarrollo' },
  { name: 'OECD Employment Outlook', desc: 'Panorama laboral OCDE' },
];

const ACADEMIES = {
  'ia-marketing': {
    id: 'ia-marketing',
    name: 'Escuela de IA Aplicada al Marketing',
    shortName: 'IA · Marketing',
    icon: '📣',
    color: '#FF6A00',
    duration: '5 meses',
    durationWeeks: 22,
    synchronous: '3 sesiones/semana en vivo',
    asynchronous: 'Biblioteca de casos + labs 24/7',
    challenge: 'Lanza una campaña completa con IA generativa para una marca real y defiende el ROI ante un panel.',
    modules: [
      'Fundamentos de IA generativa para marketers',
      'Copywriting avanzado con LLMs',
      'Creatividad visual con IA (image + video)',
      'Automatización de campañas end-to-end',
      'Analítica predictiva y atribución IA',
      'SEO/AEO/GEO — posicionar en la era de la IA',
    ],
    outcomes: [
      'Dominar 15+ herramientas de IA aplicadas',
      'Lanzar campañas 10x más rápido',
      'Reducir 40% el coste de creación de contenido',
    ],
    priceEur: '1.490 €',
    priceUsd: '1.690 USD',
    link: 'https://refactika.com/ia-marketing',
  },
  'ia-desarrollo': {
    id: 'ia-desarrollo',
    name: 'Escuela de IA Aplicada al Desarrollo Web',
    shortName: 'IA · Desarrollo',
    icon: '💻',
    color: '#FF6A00',
    duration: '6 meses',
    durationWeeks: 26,
    synchronous: 'Pair programming 2 veces/semana',
    asynchronous: 'Labs con feedback IA + code reviews',
    challenge: 'Construye un agente IA funcional con RAG, evals y despliegue productivo. Demuéstralo en Demo Day.',
    modules: [
      'AI-assisted coding (Copilot, Cursor, Claude Code)',
      'Arquitectura de agentes IA (LangChain, MCP)',
      'RAG y vectorización de conocimiento',
      'Fine-tuning y embeddings prácticos',
      'Evals, observability y guardrails',
      'Despliegue productivo (Vercel AI SDK, Bedrock)',
    ],
    outcomes: [
      'Triplicar tu velocidad de desarrollo',
      'Construir productos IA end-to-end',
      'Acceder a perfiles +25K € sobre el mercado',
    ],
    priceEur: '1.890 €',
    priceUsd: '2.090 USD',
    link: 'https://refactika.com/ia-desarrollo',
  },
  'ia-ventas': {
    id: 'ia-ventas',
    name: 'Escuela de IA Aplicada a las Ventas',
    shortName: 'IA · Ventas',
    icon: '💼',
    color: '#FF6A00',
    duration: '4 meses',
    durationWeeks: 18,
    synchronous: '2 sesiones/semana + role-plays IA',
    asynchronous: 'Simuladores de venta + transcripciones IA',
    challenge: 'Diseña y ejecuta un pipeline de prospección con IA que genere 50 leads cualificados en 30 días.',
    modules: [
      'Prospección automatizada con IA',
      'Lead scoring predictivo',
      'Asistentes de venta y transcripción',
      'Generación de propuestas con IA',
      'CRM con IA (HubSpot, Salesforce)',
      'Análisis y forecasting comercial',
    ],
    outcomes: [
      'Aumentar tu ratio de conversión 25%+',
      'Automatizar 60% de tu trabajo admin',
      'Conseguir perfiles de RevOps (+30% salario)',
    ],
    priceEur: '1.290 €',
    priceUsd: '1.490 USD',
    link: 'https://refactika.com/ia-ventas',
  },
  'ia-logistica': {
    id: 'ia-logistica',
    name: 'Escuela de IA Aplicada a la Logística',
    shortName: 'IA · Logística',
    icon: '📦',
    color: '#FF6A00',
    duration: '5 meses',
    durationWeeks: 22,
    synchronous: 'Case studies semanales + mentoría',
    asynchronous: 'Simuladores de cadena + datos reales',
    challenge: 'Optimiza una cadena de suministro real con IA y presenta el ahorro conseguido.',
    modules: [
      'Forecasting de demanda con ML',
      'Optimización de rutas con IA',
      'Digital twins de supply chain',
      'Computer vision en almacén',
      'Análisis de stocks con IA',
      'KPIs logísticos en tiempo real',
    ],
    outcomes: [
      'Reducir costes logísticos 15-25%',
      'Dominar plataformas líderes (SAP IBP, o9)',
      'Acceder a puestos de Supply Chain Analyst',
    ],
    priceEur: '1.590 €',
    priceUsd: '1.790 USD',
    link: 'https://refactika.com/ia-logistica',
  },
  'ia-gestion': {
    id: 'ia-gestion',
    name: 'Escuela de IA Aplicada a la Administración y Gestión',
    shortName: 'IA · Gestión',
    icon: '📊',
    color: '#FF6A00',
    duration: '5 meses',
    durationWeeks: 22,
    synchronous: 'Workshops ejecutivos semanales',
    asynchronous: 'Simuladores de gestión + casos reales',
    challenge: 'Diseña un sistema de BI con copilots IA que transforme la toma de decisiones en una pyme real.',
    modules: [
      'BI con IA (Power BI, Tableau Pulse)',
      'Automatización RPA + IA',
      'Análisis financiero con IA generativa',
      'Gestión de proyectos con copilots',
      'Forecasting estratégico con ML',
      'Liderazgo data-driven',
    ],
    outcomes: [
      'Automatizar 50% de tareas de gestión',
      'Dominar copilots de productividad',
      'Acceder a roles de Head of Operations IA',
    ],
    priceEur: '1.690 €',
    priceUsd: '1.890 USD',
    link: 'https://refactika.com/ia-gestion',
  },
  'ia-operaciones': {
    id: 'ia-operaciones', name: 'Escuela de IA Aplicada a Operaciones', shortName: 'IA · Operaciones',
    icon: '⚙️', color: '#FF6A00', duration: '5 meses', durationWeeks: 22,
    synchronous: '10 sesiones sincrónicas con mentor',
    asynchronous: 'Labs asíncronos + casos reales 24/7',
    challenge: 'Diseña y despliega un asistente IA para un proceso operativo real y mide su impacto en margen bruto.',
    modules: [
      'Copilots para operaciones y servicios',
      'Mantenimiento predictivo con IA',
      'Automatización con agentes IA',
      'Monitoreo en tiempo real + computer vision',
      'KPIs operativos con analítica IA',
      'Lean + IA como palanca continua',
    ],
    outcomes: ['Reducir 15% costes operativos', 'Dominar copilots operativos', 'Acceder a roles de Ops Analyst con IA'],
    priceEur: '1.590 €', priceUsd: '1.790 USD', link: 'https://refactika.com/ia-operaciones',
  },
  'ia-rrhh': {
    id: 'ia-rrhh', name: 'Escuela de IA Aplicada a RRHH', shortName: 'IA · RRHH',
    icon: '👥', color: '#FF6A00', duration: '4 meses', durationWeeks: 18,
    synchronous: '5 sesiones sincrónicas + role-plays',
    asynchronous: 'Casos de selección y desarrollo + simuladores',
    challenge: 'Construye un flujo de reclutamiento con IA end-to-end y analiza su impacto en tiempo y calidad del hire.',
    modules: [
      'Reclutamiento con IA (screening, matching)',
      'People analytics con IA generativa',
      'Learning personalizado con copilots',
      'Clima laboral con análisis de sentimiento',
      'Onboarding automatizado',
      'Compensación y carrera data-driven',
    ],
    outcomes: ['Reducir 40% tiempo de selección', 'Personalizar la carrera de cada persona', 'Acceder a roles HR Analytics'],
    priceEur: '1.290 €', priceUsd: '1.490 USD', link: 'https://refactika.com/ia-rrhh',
  },
  'ia-factoria': {
    id: 'ia-factoria', name: 'Escuela de IA Aplicada a la Factoría de Software', shortName: 'IA · Factoría Software',
    icon: '🏭', color: '#FF6A00', duration: '6 meses', durationWeeks: 26,
    synchronous: '10 sesiones sincrónicas + pair programming',
    asynchronous: 'Labs diarios + code reviews con IA',
    challenge: 'Lidera la transformación de una factoría de software: pipelines IA, code review automático, agentes e indicadores. Demuestra 3x de throughput.',
    modules: [
      'Agentic engineering (MCP, LangChain, autonomía)',
      'CI/CD con agentes IA',
      'AI code review y quality gates',
      'Test generation con IA',
      'Platform engineering + IA',
      'Observabilidad y trust en producción',
    ],
    outcomes: ['Triplicar throughput del equipo', 'Liderar factorías con 30-70 shifts', 'Acceder a roles +60K €'],
    priceEur: '1.890 €', priceUsd: '2.090 USD', link: 'https://refactika.com/ia-factoria',
  },
  'ia-innovacion': {
    id: 'ia-innovacion', name: 'Escuela de IA Aplicada a la Innovación', shortName: 'IA · Innovación',
    icon: '💡', color: '#FF6A00', duration: '5 meses', durationWeeks: 22,
    synchronous: '10 sesiones sincrónicas + pitch day',
    asynchronous: 'Prototipado con IA + casos de clientes',
    challenge: 'Identifica, prototipa y valida una oportunidad de producto con IA en 90 días. Presenta ante panel real.',
    modules: [
      'Prototipado con IA generativa (Bolt, Artifacts, Figma Make)',
      'Descubrimiento de oportunidades con IA',
      'Validación acelerada con usuarios simulados',
      'Design thinking + IA',
      'Métricas de innovación',
      'Venture building con IA',
    ],
    outcomes: ['Llegar a MVP 4x más rápido', 'Validar ideas con datos', 'Acceder a roles de Product/Innovation Lead'],
    priceEur: '1.790 €', priceUsd: '1.990 USD', link: 'https://refactika.com/ia-innovacion',
  },
  'ia-finanzas': {
    id: 'ia-finanzas', name: 'Escuela de IA Aplicada a Finanzas', shortName: 'IA · Finanzas',
    icon: '💰', color: '#FF6A00', duration: '5 meses', durationWeeks: 22,
    synchronous: '10 sesiones sincrónicas + casos financieros reales',
    asynchronous: 'Simuladores financieros + datasets reales',
    challenge: 'Implementa un sistema de forecasting y reporting financiero con IA. Demuestra ahorro en tiempo de cierre.',
    modules: [
      'FP&A con IA generativa',
      'Cierre contable automatizado',
      'Risk scoring con ML',
      'Financial copilots (Power BI, Tableau)',
      'Tesorería predictiva',
      'Análisis financiero con agentes',
    ],
    outcomes: ['Reducir 50% tiempo de cierre', 'Hacer forecasts en tiempo real', 'Acceder a FP&A leadership'],
    priceEur: '1.790 €', priceUsd: '1.990 USD', link: 'https://refactika.com/ia-finanzas',
  },
  'ia-sostenibilidad': {
    id: 'ia-sostenibilidad', name: 'Escuela de IA Aplicada a Sostenibilidad, RSC y Economía Circular', shortName: 'IA · Sostenibilidad',
    icon: '🌱', color: '#FF6A00', duration: '4 meses', durationWeeks: 14,
    synchronous: '5 sesiones sincrónicas + workshops',
    asynchronous: 'Casos ESG y circular + métricas',
    challenge: 'Diseña un sistema de cálculo de huella + reporting ESG con IA para una empresa real. Entrega el dashboard.',
    modules: [
      'Cálculo de huella con IA',
      'Reporting ESG (CSRD, GRI)',
      'Economía circular con IA',
      'Climate risk modeling',
      'Trazabilidad sostenible',
      'Gobernanza y compliance',
    ],
    outcomes: ['Automatizar reporting ESG', 'Reducir 15-20% huella organizacional', 'Acceder a ESG + IA roles'],
    priceEur: '1.490 €', priceUsd: '1.690 USD', link: 'https://refactika.com/ia-sostenibilidad',
  },
  'ia-tecnologia': {
    id: 'ia-tecnologia', name: 'Escuela de IA Aplicada a Tecnología (IT)', shortName: 'IA · Tecnología',
    icon: '🖥️', color: '#FF6A00', duration: '6 meses', durationWeeks: 26,
    synchronous: '10 sesiones sincrónicas + labs de arquitectura',
    asynchronous: 'Entornos cloud reales + retos de seguridad',
    challenge: 'Diseña la arquitectura cloud + IA de una empresa real: copilots, seguridad y gobernanza. Demuestra un ROI claro.',
    modules: [
      'Cloud con copilots (AWS, Azure, GCP)',
      'Ciberseguridad con IA (SOC + detección)',
      'Data platforms (Databricks, Snowflake) + IA',
      'MLOps y AIOps en producción',
      'Gobernanza de IA (políticas, acceso, auditoría)',
      'Agentic infra e integración MCP',
    ],
    outcomes: ['Arquitectar plataformas IA seguras', 'Reducir 30% el mean time to detect', 'Acceder a roles de Cloud/AI Architect'],
    priceEur: '1.890 €', priceUsd: '2.090 USD', link: 'https://refactika.com/ia-tecnologia',
  },
  'ia-proyectos': {
    id: 'ia-proyectos', name: 'Escuela de IA Aplicada a la Gestión de Proyectos', shortName: 'IA · Proyectos',
    icon: '📋', color: '#FF6A00', duration: '4 meses', durationWeeks: 18,
    synchronous: '5 sesiones sincrónicas + workshops de gestión',
    asynchronous: 'Simuladores de proyectos + plantillas IA',
    challenge: 'Gestiona un proyecto real usando copilots IA end-to-end. Demuestra ahorros en tiempo y coste.',
    modules: [
      'Copilots de gestión (ClickUp Brain, Notion AI)',
      'Gestión de riesgos con IA',
      'Planificación automática de sprints',
      'Minutas y seguimiento con IA',
      'Comunicación multilingüe IA',
      'Portfolio management con IA',
    ],
    outcomes: ['Gestionar proyectos 3x más rápido', 'Reducir sobrecostes 20%+', 'Acceder a roles de PMO con IA'],
    priceEur: '1.490 €', priceUsd: '1.690 USD', link: 'https://refactika.com/ia-proyectos',
  },
};

// ============================================================
// TRONCAL FORMATIVO — IA Studio · Aprender Haciendo
// Core modules present in every academy
// ============================================================

const TRONCAL = {
  name: 'IA Studio · Aprender Haciendo',
  tagline: 'Troncal común de toda Aceleradora IA. 120 horas de formación + acceso al gimnasio sincrónico.',
  description: '5 bloques transversales · 120 h totales · 24 h por bloque · acceso al gimnasio de sesiones sincrónicas. Aplicas IA a procesos reales desde la primera semana.',
  hours: 120,
  blockHours: 24,
  modules: [
    { icon: '🤖', name: 'IA aplicada a procesos · Desarrollo agéntico', desc: 'Construye y orquesta agentes IA que trabajan por ti.', hours: 24 },
    { icon: '🔀', name: 'Flujos automatizables', desc: 'Identifica qué automatizar, con qué herramienta y cómo medir el ahorro.', hours: 24 },
    { icon: '🧰', name: 'Suite de trabajo con IA', desc: 'Notion, Slack, Google, Microsoft, ClickUp: todo potenciado con IA.', hours: 24 },
    { icon: '⚡', name: 'Herramientas IA esenciales', desc: 'El kit mínimo que cualquier profesional debe dominar en 2026.', hours: 24 },
    { icon: '🚀', name: 'La IA como potenciador de tus habilidades', desc: 'Usa la IA para amplificar lo que ya haces, sin reemplazarte.', hours: 24 },
  ],
};

// SYNC SESSIONS — gimnasio model
// Multiple live sessions weekly; the student books up to 5 or 10 according to their program
const SYNC_FORMATS = [
  {
    id: 'masters',
    name: 'Masters Exponenciales',
    icon: '🎤',
    color: '#FF6A00',
    short: 'Sesión con experto · multi-recurso',
    desc: 'Sesiones en vivo con un experto, divididas en momentos que permiten crear múltiples recursos educativos: clases, cápsulas, podcasts, plantillas y casos prácticos.',
    duration: '90 min en vivo + recursos asíncronos',
  },
  {
    id: 'consultoria',
    name: 'ConsultorIA en vivo',
    icon: '🛠️',
    color: '#00B894',
    short: 'Build live · repo compartido',
    desc: 'Trabajamos con una persona que plantea un problema real. Construimos la solución durante la sesión y abrimos el repositorio del proyecto para que toda la comunidad aprenda con ella.',
    duration: '120 min · solución live + repo público para la comunidad',
  },
  {
    id: 'horaque',
    name: 'IA hora qué??',
    icon: '🎙️',
    color: '#CEBFE4',
    short: 'Conversación pública con líderes',
    desc: 'Conversación con actores relevantes sobre la implementación de IA en un sector concreto. Interactiva: el público en vivo participa con preguntas y propuestas, todo virtual.',
    duration: '60 min · conversación virtual con público en vivo',
  },
];

// Gimnasio sync-session pass per program complexity (matches skill complexity)
function syncPassForSkill(skill) {
  return skill.complexity === 'alta' ? 10 : 5;
}
function syncPassForAcademy(academyId) {
  const skills = ACADEMY_SKILLS[academyId] || [];
  // Use the highest pass available across the academy's skills
  return skills.some(s => s.complexity === 'alta') ? 10 : 5;
}

// ============================================================
// MCKINSEY THEMES — simplified for B2C messaging
// ============================================================

const MCKINSEY_THEMES = [
  { t: 'La ventaja no es la tecnología, son las capacidades.', d: 'Quien aprende a usar la IA con método gana. Quien no, queda atrás.' },
  { t: 'Cada transformación es una transformación de personas.', d: 'El 78% de los perfiles senior ya usan IA a diario. ¿Y tú?' },
  { t: 'La velocidad es la ventaja competitiva definitiva.', d: 'Las personas con IA trabajan 2.5x más rápido. Esto ya no se discute.' },
  { t: 'Reaprender, desaprender y volver a aprender.', d: 'La vida media de las skills cae cada año. Quien aprende más rápido, gana.' },
];

// ============================================================
// REGIONAL HUBS — España / LATAM cities by sector
// ============================================================

const REGIONAL_HUBS = {
  espana: {
    marketing: [['Madrid', 100], ['Barcelona', 92], ['Valencia', 58], ['Sevilla', 52], ['Bilbao', 48], ['Málaga', 44]],
    desarrollo: [['Madrid', 100], ['Barcelona', 96], ['Valencia', 64], ['Sevilla', 50], ['Bilbao', 56], ['Zaragoza', 42]],
    factoria: [['Madrid', 100], ['Barcelona', 98], ['Sevilla', 60], ['Valencia', 58], ['Bilbao', 50], ['Málaga', 46]],
    tecnologia: [['Madrid', 100], ['Barcelona', 94], ['Bilbao', 60], ['Valencia', 56], ['Sevilla', 48], ['Zaragoza', 42]],
    proyectos: [['Madrid', 100], ['Barcelona', 86], ['Bilbao', 52], ['Valencia', 50], ['Sevilla', 46], ['Zaragoza', 38]],
    ventas: [['Madrid', 100], ['Barcelona', 88], ['Valencia', 60], ['Sevilla', 56], ['Málaga', 50], ['Bilbao', 46]],
    logistica: [['Valencia', 100], ['Barcelona', 96], ['Madrid', 88], ['Algeciras', 70], ['Zaragoza', 60], ['Bilbao', 52]],
    operaciones: [['Barcelona', 100], ['Madrid', 92], ['Valencia', 70], ['Bilbao', 60], ['Zaragoza', 54], ['Sevilla', 48]],
    gestion: [['Madrid', 100], ['Barcelona', 88], ['Bilbao', 56], ['Valencia', 52], ['Sevilla', 46], ['Málaga', 40]],
    rrhh: [['Madrid', 100], ['Barcelona', 84], ['Valencia', 52], ['Bilbao', 48], ['Sevilla', 42], ['Málaga', 38]],
    innovacion: [['Barcelona', 100], ['Madrid', 96], ['Valencia', 60], ['Bilbao', 54], ['Málaga', 48], ['Zaragoza', 40]],
    finanzas: [['Madrid', 100], ['Barcelona', 86], ['Bilbao', 64], ['Valencia', 50], ['Málaga', 42], ['Sevilla', 40]],
    sostenibilidad: [['Madrid', 100], ['Barcelona', 92], ['Valencia', 60], ['Sevilla', 54], ['Bilbao', 50], ['Zaragoza', 42]],
  },
  latam: {
    marketing: [['CDMX', 100, '🇲🇽'], ['Buenos Aires', 92, '🇦🇷'], ['São Paulo', 88, '🇧🇷'], ['Bogotá', 76, '🇨🇴'], ['Santiago', 70, '🇨🇱'], ['Lima', 56, '🇵🇪']],
    desarrollo: [['Buenos Aires', 100, '🇦🇷'], ['CDMX', 92, '🇲🇽'], ['São Paulo', 90, '🇧🇷'], ['Santiago', 80, '🇨🇱'], ['Medellín', 72, '🇨🇴'], ['Lima', 60, '🇵🇪']],
    factoria: [['Buenos Aires', 100, '🇦🇷'], ['Medellín', 88, '🇨🇴'], ['São Paulo', 84, '🇧🇷'], ['CDMX', 80, '🇲🇽'], ['Santiago', 72, '🇨🇱'], ['Lima', 56, '🇵🇪']],
    tecnologia: [['Buenos Aires', 100, '🇦🇷'], ['São Paulo', 96, '🇧🇷'], ['CDMX', 88, '🇲🇽'], ['Santiago', 76, '🇨🇱'], ['Bogotá', 72, '🇨🇴'], ['Medellín', 60, '🇨🇴']],
    proyectos: [['CDMX', 100, '🇲🇽'], ['São Paulo', 92, '🇧🇷'], ['Bogotá', 84, '🇨🇴'], ['Buenos Aires', 80, '🇦🇷'], ['Santiago', 70, '🇨🇱'], ['Lima', 56, '🇵🇪']],
    ventas: [['CDMX', 100, '🇲🇽'], ['Bogotá', 90, '🇨🇴'], ['São Paulo', 86, '🇧🇷'], ['Santiago', 74, '🇨🇱'], ['Lima', 64, '🇵🇪'], ['Buenos Aires', 70, '🇦🇷']],
    logistica: [['São Paulo', 100, '🇧🇷'], ['Panamá', 88, '🇵🇦'], ['CDMX', 84, '🇲🇽'], ['Buenos Aires', 70, '🇦🇷'], ['Santiago', 64, '🇨🇱'], ['Bogotá', 56, '🇨🇴']],
    operaciones: [['Monterrey', 100, '🇲🇽'], ['São Paulo', 92, '🇧🇷'], ['Buenos Aires', 80, '🇦🇷'], ['Bogotá', 68, '🇨🇴'], ['Santiago', 60, '🇨🇱'], ['Lima', 50, '🇵🇪']],
    gestion: [['CDMX', 100, '🇲🇽'], ['São Paulo', 92, '🇧🇷'], ['Bogotá', 80, '🇨🇴'], ['Santiago', 70, '🇨🇱'], ['Buenos Aires', 76, '🇦🇷'], ['Lima', 56, '🇵🇪']],
    rrhh: [['CDMX', 100, '🇲🇽'], ['São Paulo', 90, '🇧🇷'], ['Bogotá', 78, '🇨🇴'], ['Santiago', 66, '🇨🇱'], ['Lima', 54, '🇵🇪'], ['Buenos Aires', 70, '🇦🇷']],
    innovacion: [['Santiago', 100, '🇨🇱'], ['Buenos Aires', 92, '🇦🇷'], ['CDMX', 88, '🇲🇽'], ['São Paulo', 86, '🇧🇷'], ['Medellín', 72, '🇨🇴'], ['Lima', 56, '🇵🇪']],
    finanzas: [['CDMX', 100, '🇲🇽'], ['São Paulo', 96, '🇧🇷'], ['Bogotá', 80, '🇨🇴'], ['Santiago', 76, '🇨🇱'], ['Buenos Aires', 72, '🇦🇷'], ['Lima', 60, '🇵🇪']],
    sostenibilidad: [['Santiago', 100, '🇨🇱'], ['São Paulo', 92, '🇧🇷'], ['CDMX', 80, '🇲🇽'], ['Bogotá', 72, '🇨🇴'], ['Lima', 60, '🇵🇪'], ['Buenos Aires', 56, '🇦🇷']],
  },
};

const REGIONAL_COMPANIES = {
  espana: {
    marketing: ['Telefónica', 'Inditex', 'Banco Santander', 'BBVA', 'Mahou San Miguel', 'El Corte Inglés'],
    desarrollo: ['Telefónica Tech', 'BBVA', 'Glovo', 'Cabify', 'Tuenti', 'Idealista'],
    factoria: ['NTT Data Spain', 'Indra', 'Capgemini Iberia', 'Everis', 'Globant Iberia', 'Accenture'],
    tecnologia: ['AWS Spain', 'Microsoft Iberia', 'Google Cloud España', 'Telefónica Tech', 'IBM España', 'Oracle Iberia'],
    proyectos: ['Accenture', 'Deloitte España', 'EY España', 'KPMG España', 'PwC España', 'Capgemini'],
    ventas: ['Salesforce Iberia', 'HubSpot España', 'SAP Iberia', 'Oracle', 'Microsoft', 'Cisco España'],
    logistica: ['SEUR', 'Inditex Logística', 'DHL España', 'Correos Express', 'ID Logistics', 'Maersk España'],
    operaciones: ['Repsol', 'Iberdrola', 'Ferrovial', 'Acciona', 'Naturgy', 'Mercadona'],
    gestion: ['Deloitte', 'EY España', 'KPMG España', 'BBVA', 'Banco Santander', 'Mapfre'],
    rrhh: ['Adecco España', 'Randstad España', 'Manpower España', 'Hays España', 'Page Group', 'Eurofirms'],
    innovacion: ['Telefónica Innovation', 'BBVA Next', 'Banco Santander X', 'Repsol Lab', 'Iberdrola Ventures', 'Bankinter Innov.'],
    finanzas: ['BBVA', 'Banco Santander', 'CaixaBank', 'Bankinter', 'Mapfre', 'Sabadell'],
    sostenibilidad: ['Iberdrola', 'Acciona', 'Naturgy', 'Repsol', 'Endesa', 'Ferrovial'],
  },
  latam: {
    marketing: ['Mercado Libre', 'Globant', 'Falabella', 'Bimbo', 'Natura', 'Banco Itaú'],
    desarrollo: ['Mercado Libre', 'Globant', 'Despegar', 'Rappi', 'Nubank', 'Kueski'],
    factoria: ['Globant', 'EPAM LATAM', 'Endava', 'Softtek', 'NTT Data LATAM', 'Mercado Libre'],
    tecnologia: ['AWS LATAM', 'Microsoft LATAM', 'Google Cloud LATAM', 'Globant', 'Softtek', 'IBM LATAM'],
    proyectos: ['Accenture LATAM', 'Deloitte LATAM', 'PwC LATAM', 'EY LATAM', 'KPMG LATAM', 'Capgemini'],
    ventas: ['Salesforce LATAM', 'HubSpot LATAM', 'Mercado Libre', 'Rappi', 'Despegar', 'Falabella'],
    logistica: ['Mercado Envíos', 'DHL LATAM', 'Estafeta', 'Maersk LATAM', 'Bringer', 'Cargill'],
    operaciones: ['Bimbo', 'Cemex', 'FEMSA', 'Arcor', 'Natura', 'JBS'],
    gestion: ['Itaú', 'Banco de Chile', 'BBVA México', 'Bancolombia', 'Falabella', 'Cencosud'],
    rrhh: ['Adecco LATAM', 'Manpower LATAM', 'Bumeran', 'Computrabajo', 'Trabajando.com', 'Randstad LATAM'],
    innovacion: ['Mercado Libre', 'Rappi', 'Nubank', 'Kavak', 'Bitso', 'Globant Studios'],
    finanzas: ['Itaú', 'Bancolombia', 'BBVA México', 'Banorte', 'Banco de Chile', 'Banco Macro'],
    sostenibilidad: ['Natura &Co', 'Cemex', 'Suzano', 'Enel Américas', 'Klabin', 'CMPC'],
  },
};

// ============================================================
// SKILLS & MICROCREDENTIALS per academy
// Each skill earns a Refactika microcredencial badge on completion
// ============================================================

const ACADEMY_SKILLS = {
  'ia-marketing': [
    { id: 'mk1', title: 'PRODUCCIÓN\nCON IA\nRESPONSABLE', desc: 'Generación de contenido multicanal con IA, con guardrails y brand safety.', weeks: 22, complexity: 'alta' },
    { id: 'mk2', title: 'PERSONALIZACIÓN\nA ESCALA\nCON IA', desc: 'Segmentación predictiva y campañas hipersegmentadas con IA.', weeks: 22, complexity: 'alta' },
    { id: 'mk3', title: 'AUTOMATIZACIÓN\nCON IA', desc: 'Flujos automatizados de captación, email y social con IA.', weeks: 14, complexity: 'media' },
    { id: 'mk4', title: 'SEO\nPARA IA', desc: 'AEO, GEO y posicionamiento en búsquedas con IA.', weeks: 14, complexity: 'media' },
  ],
  'ia-desarrollo': [
    { id: 'dv1', title: 'AGENTES IA\nEN PRODUCCIÓN', desc: 'Diseño, evaluación y despliegue de agentes IA reales.', weeks: 22, complexity: 'alta' },
    { id: 'dv2', title: 'COPILOT\nWORKFLOWS', desc: 'Workflow de desarrollo asistido con IA a nivel experto.', weeks: 14, complexity: 'media' },
    { id: 'dv3', title: 'RAG Y\nVECTORIZACIÓN', desc: 'Sistemas RAG productivos con bases de datos vectoriales.', weeks: 22, complexity: 'alta' },
    { id: 'dv4', title: 'EVALS Y\nOBSERVABILIDAD', desc: 'Medir y controlar la calidad de sistemas LLM.', weeks: 14, complexity: 'media' },
  ],
  'ia-ventas': [
    { id: 'vt1', title: 'PROSPECCIÓN\nAUTOMATIZADA\nCON IA', desc: 'Generar leads cualificados 10x más rápido con IA.', weeks: 14, complexity: 'media' },
    { id: 'vt2', title: 'REVENUE\nOPERATIONS\nCON IA', desc: 'Pipeline, forecasting y analytics con IA.', weeks: 22, complexity: 'alta' },
    { id: 'vt3', title: 'ASISTENTES\nDE VENTA\nCON IA', desc: 'Gong, Chorus, Fireflies y asistentes para cierres.', weeks: 14, complexity: 'media' },
  ],
  'ia-logistica': [
    { id: 'lg1', title: 'FORECASTING\nDE DEMANDA\nCON IA', desc: 'Modelos de demanda que reducen sobrestock y roturas.', weeks: 22, complexity: 'alta' },
    { id: 'lg2', title: 'OPTIMIZACIÓN\nDE RUTAS\nCON IA', desc: 'Last mile y flotas optimizadas con IA.', weeks: 14, complexity: 'media' },
    { id: 'lg3', title: 'DIGITAL TWIN\nSUPPLY\nCHAIN', desc: 'Gemelos digitales para simular la cadena.', weeks: 22, complexity: 'alta' },
  ],
  'ia-gestion': [
    { id: 'gs1', title: 'BI CON\nCOPILOTS IA', desc: 'Power BI, Tableau Pulse y Notion AI para decisiones.', weeks: 14, complexity: 'media' },
    { id: 'gs2', title: 'AUTOMATIZACIÓN\nDE PROCESOS\n(RPA + IA)', desc: 'RPA con agentes IA para tareas de gestión.', weeks: 22, complexity: 'alta' },
    { id: 'gs3', title: 'ESTRATEGIA\nDATA-DRIVEN', desc: 'Dirección con datos y modelos de previsión.', weeks: 22, complexity: 'alta' },
  ],
  'ia-operaciones': [
    { id: 'op1', title: 'COPILOTS\nOPERATIVOS', desc: 'Asistentes IA para equipos de ops y servicios.', weeks: 14, complexity: 'media' },
    { id: 'op2', title: 'MANTENIMIENTO\nPREDICTIVO\nCON IA', desc: 'Sensor data + ML para predecir fallos.', weeks: 22, complexity: 'alta' },
    { id: 'op3', title: 'AGENTES IA\nEN OPERACIONES', desc: 'Automatización de procesos con agentes autónomos.', weeks: 22, complexity: 'alta' },
  ],
  'ia-rrhh': [
    { id: 'rh1', title: 'RECLUTAMIENTO\nCON IA', desc: 'Screening, matching y entrevistas con IA.', weeks: 14, complexity: 'media' },
    { id: 'rh2', title: 'PEOPLE\nANALYTICS', desc: 'Datos de personas para decisiones reales.', weeks: 14, complexity: 'media' },
    { id: 'rh3', title: 'LEARNING\nPERSONALIZADO\nCON IA', desc: 'Formación adaptativa con copilots.', weeks: 22, complexity: 'alta' },
  ],
  'ia-factoria': [
    { id: 'fs1', title: 'AGENTIC\nENGINEERING', desc: 'Construye agentes que escriben y prueban código.', weeks: 22, complexity: 'alta' },
    { id: 'fs2', title: 'AI CODE\nREVIEW', desc: 'Quality gates automatizados con IA.', weeks: 14, complexity: 'media' },
    { id: 'fs3', title: 'PLATFORM\nENGINEERING\nCON IA', desc: 'Plataformas internas con agentes.', weeks: 22, complexity: 'alta' },
    { id: 'fs4', title: 'OBSERVABILIDAD\nAI', desc: 'Monitoriza sistemas LLM en producción.', weeks: 14, complexity: 'media' },
  ],
  'ia-innovacion': [
    { id: 'in1', title: 'PROTOTIPADO\nGENERATIVO', desc: 'De idea a MVP en horas con IA.', weeks: 14, complexity: 'media' },
    { id: 'in2', title: 'PRODUCT\nDISCOVERY\nCON IA', desc: 'Descubrir oportunidades a escala con IA.', weeks: 22, complexity: 'alta' },
    { id: 'in3', title: 'VALIDACIÓN\nACELERADA', desc: 'Usuarios sintéticos y tests rápidos.', weeks: 14, complexity: 'media' },
  ],
  'ia-finanzas': [
    { id: 'fz1', title: 'FP&A\nCON IA', desc: 'Forecasts automáticos y reporting en tiempo real.', weeks: 22, complexity: 'alta' },
    { id: 'fz2', title: 'CIERRE CONTABLE\nAUTOMATIZADO', desc: 'Reduce el cierre de 10 días a 2.', weeks: 14, complexity: 'media' },
    { id: 'fz3', title: 'RISK SCORING\nCON ML', desc: 'Modelos de riesgo explicables.', weeks: 22, complexity: 'alta' },
  ],
  'ia-sostenibilidad': [
    { id: 'st1', title: 'ESG REPORTING\nCON IA', desc: 'Reporting automatizado CSRD y GRI.', weeks: 14, complexity: 'media' },
    { id: 'st2', title: 'HUELLA CARBONO\nCON IA', desc: 'Cálculo y reducción con IA.', weeks: 14, complexity: 'media' },
    { id: 'st3', title: 'ECONOMÍA\nCIRCULAR\nCON IA', desc: 'Trazabilidad y optimización circular.', weeks: 22, complexity: 'alta' },
  ],
  'ia-tecnologia': [
    { id: 'tc1', title: 'ARQUITECTURA\nCLOUD CON IA', desc: 'AWS, Azure y GCP potenciados con copilots IA.', weeks: 22, complexity: 'alta' },
    { id: 'tc2', title: 'CIBERSEGURIDAD\nCON IA', desc: 'Detección de amenazas y SOC copilots.', weeks: 22, complexity: 'alta' },
    { id: 'tc3', title: 'MLOPS Y\nAIOPS', desc: 'Producción IA segura y escalable.', weeks: 14, complexity: 'media' },
    { id: 'tc4', title: 'GOBIERNO\nDE IA', desc: 'Políticas, acceso y auditoría de sistemas IA.', weeks: 14, complexity: 'media' },
  ],
  'ia-proyectos': [
    { id: 'pr1', title: 'COPILOTS\nDE GESTIÓN', desc: 'ClickUp Brain, Notion AI, MS Project con IA.', weeks: 14, complexity: 'media' },
    { id: 'pr2', title: 'GESTIÓN\nDE RIESGOS\nCON IA', desc: 'Predicción y mitigación con ML.', weeks: 22, complexity: 'alta' },
    { id: 'pr3', title: 'SPRINTS\nCON IA', desc: 'Planificación automática y retrospectivas IA.', weeks: 14, complexity: 'media' },
  ],
};

// Price rules based on complexity
function priceForSkill(skill, region) {
  const eur = skill.complexity === 'alta' ? 1890 : skill.complexity === 'media' ? 1690 : 1490;
  const usd = Math.round(eur * 1.12);
  return region === 'latam' ? `${usd} USD` : `${eur} €`;
}

// Total formative hours by skill complexity
// 5 sesiones sincrónicas → 300 h (skills "media", 14 semanas)
// 10 sesiones sincrónicas → 450 h (skills "alta", 22 semanas)
function hoursForSkill(skill) {
  return skill.complexity === 'alta' ? 450 : 300;
}
function syncSessionsForSkill(skill) {
  return skill.complexity === 'alta' ? 10 : 5;
}

// IA School pedagogical model — ABR
const ABR_MODEL = {
  brand: 'IA School',
  parent: 'Aceleradora IA · REFACTIKA',
  methodology: 'ABR — Aprendizaje Basado en Retos',
  description: 'Cada vertical de IA School es una Aceleradora. Todas comparten un troncal común de IA aplicada (120 h) y se especializan con retos reales por área. El sincrónico funciona en modalidad gimnasio.',
  trunk: {
    name: 'IA Studio · Troncal común de IA aplicada',
    purpose: 'Plan común desde una perspectiva metodológica aplicada. 120 h de formación + acceso al gimnasio sincrónico para aprender usando IA en tu día a día.',
    hours: 120,
    devices: [
      { id: 'ind', name: 'Reto individual', desc: 'Resuelves el reto en solitario, con feedback IA y mentor.' },
      { id: 'col', name: 'Reto colaborativo', desc: 'Trabajas en grupo de 3-5 personas en un caso real con entrega conjunta.' },
    ],
    passCriteria: 'Superas el troncal cuando completas al menos el 75 % de los retos propuestos, y al menos 2 de ellos en formato colaborativo.',
  },
  vertical: {
    name: 'Retos específicos por vertical',
    desc: 'Una vez superado el troncal, se desbloquean retos del área (Marketing, Desarrollo, Ventas, etc.) que mantienen la metodología ABR.',
  },
  gym: {
    name: 'Gimnasio sincrónico',
    desc: 'Catálogo abierto de sesiones sincrónicas. Cada estudiante reserva las plazas según el pase de su programa: 5 sesiones (programa medio) o 10 sesiones (programa avanzado).',
    formats: SYNC_FORMATS,
  },
  resources: ['Textos curados', 'Vídeos', 'Cápsulas SCORM', 'Templates aplicables', 'Comunidad colaborativa'],
  evaluation: [
    { f: 'Resolución de retos', w: '60 %', d: 'Porcentaje de retos completados sobre el total del programa.' },
    { f: 'Calidad de retos', w: '20 %', d: 'Evaluación cualitativa (rúbrica) de cada reto entregado.' },
    { f: 'Proyecto final', w: '20 %', d: 'Defensa de un proyecto integrador que demuestra la habilidad.' },
  ],
  recognition: 'Microcredenciales Refactika por habilidad superada + Certificado IA School de la vertical correspondiente.',
};

// EFFECTIVE academy — merges base ACADEMIES with admin overrides from localStorage
function getEffectiveAcademy(id) {
  const base = ACADEMIES[id];
  if (!base) return null;
  try {
    const state = adminStore.getState();
    const override = (state.academyOverrides || {})[id];
    if (override) return { ...base, ...override };
  } catch(e) {}
  return base;
}
function getEffectiveAcademies() {
  return Object.keys(ACADEMIES).map(id => getEffectiveAcademy(id));
}

// ============================================================
// ADMIN STORE — localStorage-backed persistence
// Superadmin + admin roles · offerings · user leads
// ============================================================

const ADMIN_KEY = 'orientadoria_admin_v1';
const SUPERADMIN = { email: 'superadmin@refactika.com', password: 'refactika2026', name: 'Super Admin' };

function AdminStore() {
  const load = () => {
    try {
      const raw = localStorage.getItem(ADMIN_KEY);
      if (raw) return JSON.parse(raw);
    } catch(e) {}
    return { admins: [], offerings: [], leads: [], sessions: [] };
  };
  const save = (s) => localStorage.setItem(ADMIN_KEY, JSON.stringify(s));

  return {
    getState: load,
    setState: save,
    addAdmin: (admin) => { const s = load(); s.admins.push({ ...admin, createdAt: new Date().toISOString() }); save(s); },
    removeAdmin: (email) => { const s = load(); s.admins = s.admins.filter(a => a.email !== email); save(s); },
    addOffering: (o) => { const s = load(); s.offerings.push({ ...o, id: 'off_' + Date.now(), createdAt: new Date().toISOString() }); save(s); },
    removeOffering: (id) => { const s = load(); s.offerings = s.offerings.filter(o => o.id !== id); save(s); },
    addLead: (lead) => { const s = load(); s.leads.push({ ...lead, id: 'lead_' + Date.now(), createdAt: new Date().toISOString() }); save(s); },
    saveAcademyOverride: (id, patch) => {
      const s = load();
      s.academyOverrides = s.academyOverrides || {};
      s.academyOverrides[id] = { ...(s.academyOverrides[id] || {}), ...patch, updatedAt: new Date().toISOString() };
      save(s);
    },
    resetAcademyOverride: (id) => {
      const s = load();
      if (s.academyOverrides) { delete s.academyOverrides[id]; save(s); }
    },
    currentUser: () => {
      try { return JSON.parse(sessionStorage.getItem('oia_user') || 'null'); } catch(e) { return null; }
    },
    login: (email, password) => {
      if (email === SUPERADMIN.email && password === SUPERADMIN.password) {
        const u = { email, name: SUPERADMIN.name, role: 'superadmin' };
        sessionStorage.setItem('oia_user', JSON.stringify(u));
        return u;
      }
      const s = load();
      const admin = s.admins.find(a => a.email === email && a.password === password);
      if (admin) {
        const u = { email: admin.email, name: admin.name, role: 'admin' };
        sessionStorage.setItem('oia_user', JSON.stringify(u));
        return u;
      }
      return null;
    },
    logout: () => sessionStorage.removeItem('oia_user'),
  };
}

const adminStore = AdminStore();

// ============================================================
// 2. MARKET DATA — Simulated real-time sources
// ============================================================

const DATA_SOURCES = {
  espana: {
    region: 'España',
    flag: '🇪🇸',
    currency: '€',
    publicSources: [
      { name: 'SEPE', desc: 'Servicio Público de Empleo Estatal' },
      { name: 'Empléate', desc: 'Portal oficial de empleo público' },
      { name: 'Lanbide', desc: 'País Vasco' },
      { name: 'Labora', desc: 'Comunitat Valenciana' },
      { name: 'SOC', desc: 'Cataluña' },
      { name: 'SAE', desc: 'Andalucía' },
      { name: 'Empleacyl', desc: 'Castilla y León' },
      { name: 'INAEM', desc: 'Aragón' },
      { name: 'Empleo Canarias', desc: 'Canarias' },
    ],
    privateSources: [
      { name: 'LinkedIn', desc: 'Red profesional global' },
      { name: 'InfoJobs', desc: 'Portal líder en España' },
      { name: 'Indeed', desc: 'Agregador global' },
      { name: 'Glassdoor', desc: 'Salarios y empresas' },
      { name: 'Jobted', desc: 'Agregador España' },
      { name: 'Tecnoempleo', desc: 'Tecnología' },
      { name: 'Talent.com', desc: 'Global' },
    ],
    consultancies: [
      { name: 'Adecco Group', desc: 'Monitor de empleo' },
      { name: 'Randstad', desc: 'Informes tendencias' },
      { name: 'Hays', desc: 'Salary Guide' },
      { name: 'Page Personnel', desc: 'Estudios salariales' },
      { name: 'LHH', desc: 'Mercado laboral' },
    ],
  },
  latam: {
    region: 'Latinoamérica',
    flag: '🌎',
    currency: 'USD',
    publicSources: [
      { name: 'BNE', desc: 'Bolsa Nacional de Empleo (Chile)' },
      { name: 'Empleos.gob', desc: 'México' },
      { name: 'Trabajando Gobierno', desc: 'Argentina' },
      { name: 'SENA', desc: 'Colombia' },
      { name: 'Portales municipales', desc: 'LATAM' },
    ],
    privateSources: [
      { name: 'LinkedIn LATAM', desc: 'Red profesional' },
      { name: 'GetOnBoard', desc: 'Tech líder LATAM' },
      { name: 'Computrabajo', desc: 'Regional' },
      { name: 'Trabajando.com', desc: 'Regional' },
      { name: 'Laborum', desc: 'Regional' },
      { name: 'Torre.ai', desc: 'IA + empleo' },
      { name: 'Bumeran', desc: 'Argentina / México' },
      { name: 'OCC Mundial', desc: 'México' },
    ],
    consultancies: [
      { name: 'Adecco LATAM', desc: 'Monitor regional' },
      { name: 'Manpower LATAM', desc: 'Talent Outlook' },
      { name: 'PageGroup LATAM', desc: 'Estudios salariales' },
      { name: 'Michael Page', desc: 'Salary Survey' },
    ],
  },
};

// Simulated live market data by sector (updated daily 6 AM)
function getMarketData(region, sectorId) {
  const base = {
    marketing: {
      espana: { offers: 8420, avgSalary: 38500, growth: 18, topCity: 'Madrid', aiOffers: 3240 },
      latam: { offers: 12800, avgSalary: 28500, growth: 26, topCity: 'CDMX', aiOffers: 5120 },
    },
    desarrollo: {
      espana: { offers: 15280, avgSalary: 48900, growth: 32, topCity: 'Madrid', aiOffers: 7100 },
      latam: { offers: 22400, avgSalary: 42000, growth: 41, topCity: 'Santiago', aiOffers: 11200 },
    },
    ventas: {
      espana: { offers: 9840, avgSalary: 35200, growth: 14, topCity: 'Barcelona', aiOffers: 2100 },
      latam: { offers: 18600, avgSalary: 26000, growth: 22, topCity: 'Bogotá', aiOffers: 4200 },
    },
    logistica: {
      espana: { offers: 6210, avgSalary: 32800, growth: 11, topCity: 'Valencia', aiOffers: 980 },
      latam: { offers: 11400, avgSalary: 22500, growth: 19, topCity: 'São Paulo', aiOffers: 1850 },
    },
    gestion: {
      espana: { offers: 7180, avgSalary: 42400, growth: 21, topCity: 'Madrid', aiOffers: 2460 },
      latam: { offers: 13200, avgSalary: 30800, growth: 28, topCity: 'CDMX', aiOffers: 3980 },
    },
    operaciones: {
      espana: { offers: 5920, avgSalary: 38200, growth: 17, topCity: 'Barcelona', aiOffers: 1460 },
      latam: { offers: 9640, avgSalary: 25200, growth: 22, topCity: 'Monterrey', aiOffers: 1980 },
    },
    rrhh: {
      espana: { offers: 4820, avgSalary: 36800, growth: 19, topCity: 'Madrid', aiOffers: 1280 },
      latam: { offers: 8420, avgSalary: 24400, growth: 25, topCity: 'CDMX', aiOffers: 1640 },
    },
    factoria: {
      espana: { offers: 11240, avgSalary: 52600, growth: 36, topCity: 'Madrid', aiOffers: 5620 },
      latam: { offers: 17800, avgSalary: 44200, growth: 42, topCity: 'Buenos Aires', aiOffers: 9200 },
    },
    innovacion: {
      espana: { offers: 3920, avgSalary: 48400, growth: 28, topCity: 'Barcelona', aiOffers: 1820 },
      latam: { offers: 6400, avgSalary: 34200, growth: 32, topCity: 'Santiago', aiOffers: 2820 },
    },
    finanzas: {
      espana: { offers: 8640, avgSalary: 49200, growth: 24, topCity: 'Madrid', aiOffers: 2980 },
      latam: { offers: 12200, avgSalary: 33200, growth: 29, topCity: 'CDMX', aiOffers: 3840 },
    },
    sostenibilidad: {
      espana: { offers: 2840, avgSalary: 40800, growth: 26, topCity: 'Madrid', aiOffers: 780 },
      latam: { offers: 4680, avgSalary: 28200, growth: 30, topCity: 'Santiago', aiOffers: 1080 },
    },
    tecnologia: {
      espana: { offers: 13200, avgSalary: 50600, growth: 31, topCity: 'Madrid', aiOffers: 6240 },
      latam: { offers: 19400, avgSalary: 43800, growth: 36, topCity: 'Buenos Aires', aiOffers: 9420 },
    },
    proyectos: {
      espana: { offers: 6420, avgSalary: 44200, growth: 22, topCity: 'Madrid', aiOffers: 2140 },
      latam: { offers: 10200, avgSalary: 32400, growth: 27, topCity: 'CDMX', aiOffers: 3120 },
    },
  };
  return base[sectorId]?.[region] || null;
}

// ============================================================
// 3. BRAND COMPONENTS
// ============================================================

function BrandMark({ size = 'md', className = '' }) {
  const sizes = {
    xs: 'text-xs',
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-xl',
    xl: 'text-3xl',
    '2xl': 'text-5xl',
  };
  return (
    <span className={`brand-mark ${sizes[size]} ${className}`}>
      REFACT<span className="ia">I</span>K<span className="ia">A</span>
    </span>
  );
}

function OrientadorMark({ size = 'md', className = '' }) {
  const sizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-3xl',
    xl: 'text-5xl',
  };
  return (
    <span className={`brand-mark ${sizes[size]} ${className}`}>
      Orientador<span className="ia">IA</span>
    </span>
  );
}

// Refactika microcredencial badge — SVG circle badge (orange + dark ribbon)
function RefactikaBadge({ title, size = 140, showLabel = true }) {
  const s = size;
  const cx = s / 2;
  const cy = s / 2;
  const r = s * 0.44;
  const ribbonH = s * 0.28;
  const ribbonY = cy - ribbonH / 2;

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} className="inline-block">
      {/* Outer ring */}
      <circle cx={cx} cy={cy} r={r + s * 0.03} fill="#FF6A00" />
      <circle cx={cx} cy={cy} r={r} fill="#FF8C33" />
      {/* Inner circle */}
      <circle cx={cx} cy={cy} r={r - 1} fill="#FF6A00" />
      {/* Refactika header */}
      <text x={cx} y={cy - r * 0.5} textAnchor="middle"
        fontFamily="Inter, system-ui, sans-serif" fontWeight="900" fontSize={s * 0.07} fill="#000A1A">
        REFACT<tspan fill="#000A1A">I</tspan>KA
      </text>
      {/* Dark ribbon with title */}
      <rect x={cx - r * 0.95} y={ribbonY} width={r * 1.9} height={ribbonH} rx={s * 0.015} fill="#000A1A" />
      {/* Ribbon edges */}
      <polygon points={`${cx - r * 0.95},${ribbonY} ${cx - r * 1.02},${ribbonY + ribbonH / 2} ${cx - r * 0.95},${ribbonY + ribbonH}`} fill="#000A1A" />
      <polygon points={`${cx + r * 0.95},${ribbonY} ${cx + r * 1.02},${ribbonY + ribbonH / 2} ${cx + r * 0.95},${ribbonY + ribbonH}`} fill="#000A1A" />
      {/* Title text */}
      {showLabel && title.split('\n').map((line, i, arr) => (
        <text key={i} x={cx} y={cy - ribbonH * 0.05 + (i - (arr.length - 1) / 2) * s * 0.07} textAnchor="middle"
          fontFamily="Inter, system-ui, sans-serif" fontWeight="800" fontSize={s * 0.062} fill="#ffffff"
          style={{ textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          {line}
        </text>
      ))}
      {/* MICROCREDENCIAL */}
      <text x={cx} y={cy + r * 0.6} textAnchor="middle"
        fontFamily="Inter, system-ui, sans-serif" fontWeight="700" fontSize={s * 0.05} fill="#000A1A"
        style={{ textTransform: 'uppercase', letterSpacing: '0.15em' }}>
        MICROCREDENCIAL
      </text>
      {/* Subtle pixel "refactika" square */}
      <g transform={`translate(${cx - s * 0.05}, ${cy - r * 0.72})`}>
        <rect x="0" y="0" width={s * 0.06} height={s * 0.06} fill="#000A1A" />
        <rect x="0" y={s * 0.06} width={s * 0.02} height={s * 0.02} fill="#000A1A" />
        <rect x={s * 0.04} y={s * 0.06} width={s * 0.02} height={s * 0.02} fill="#000A1A" />
        <rect x={s * 0.02} y="0" width={s * 0.02} height={s * 0.02} fill="#FF6A00" />
      </g>
    </svg>
  );
}

// ============================================================
// 4. TOP BAR
// ============================================================

function TopBar({ region, onRegionChange, onRestart, onMarket, onAdmin, currentView }) {
  return (
    <div className="w-full border-b border-ink-900/5 bg-paper/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-5 py-3 flex items-center justify-between gap-3">
        <button onClick={onRestart} className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-ink-900 flex items-center justify-center">
            <span className="text-orange-500 font-black text-sm">IA</span>
          </div>
          <div className="flex flex-col items-start leading-none">
            <OrientadorMark size="md" className="text-ink-900" />
            <span className="text-[10px] text-ink-500 mt-0.5">by <BrandMark size="xs" className="text-ink-500" /></span>
          </div>
        </button>

        <div className="flex items-center gap-2 sm:gap-3">
          <button onClick={onMarket}
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${currentView === 'market' ? 'bg-ink-900 text-white' : 'text-ink-500 hover:text-ink-900 hover:bg-ink-900/5'}`}>
            <span>📊</span> Inteligencia de mercado
          </button>
          <button onClick={onMarket}
            className="sm:hidden p-2 rounded-lg text-ink-500 hover:bg-ink-900/5" title="Inteligencia de mercado">
            📊
          </button>

          {onAdmin && (
            <button onClick={onAdmin}
              className={`hidden md:inline-flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs font-medium transition ${currentView === 'admin' ? 'bg-ink-900 text-white' : 'text-ink-500 hover:text-ink-900 hover:bg-ink-900/5'}`}
              title="Panel admin">
              🔐
            </button>
          )}

          <div className="hidden md:flex items-center gap-1.5 text-xs text-ink-500">
            <div className="w-2 h-2 rounded-full bg-green-500 live-dot" />
            <span>6:00 AM</span>
          </div>

          <div className="flex items-center gap-1 bg-ink-900/5 rounded-full p-1">
            <button onClick={() => onRegionChange('espana')}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition ${region === 'espana' ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500'}`}>
              🇪🇸 <span className="hidden sm:inline">España</span>
            </button>
            <button onClick={() => onRegionChange('latam')}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition ${region === 'latam' ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500'}`}>
              🌎 <span className="hidden sm:inline">LATAM</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// 5. LANDING — First impression
// ============================================================

function Landing({ onStart, onMarket, region }) {
  return (
    <div className="relative">
      <div className="absolute inset-0 bg-grid opacity-60 pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-5 pt-16 pb-20">
        <div className="fade-up" style={{ animationDelay: '0s' }}>
          <div className="inline-flex items-center gap-2 bg-orange-50 border border-orange-100 rounded-full px-3 py-1.5 text-xs text-orange-600 font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500 pulse-soft" />
            Encuentra tu camino en la era de la <b className="ml-0.5">IA</b>
          </div>
        </div>

        <h1 className="fade-up text-4xl sm:text-5xl md:text-6xl font-black text-ink-900 leading-[1.05] tracking-tight mb-6" style={{ animationDelay: '0.1s' }}>
          ¿Hacia dónde quieres<br/>
          llevar tu carrera?
        </h1>

        <p className="fade-up text-lg text-ink-500 max-w-xl mb-10" style={{ animationDelay: '0.2s' }}>
          Te orientamos con <b className="text-ink-900">IA</b>. Cuéntanos tu proyecto, tus referencias o tu sector. En minutos sabrás qué aprender hoy y cómo llegar.
        </p>

        <div className="fade-up flex flex-col sm:flex-row gap-3 mb-4" style={{ animationDelay: '0.3s' }}>
          <button
            onClick={onStart}
            className="bg-ink-900 text-white px-6 py-3.5 rounded-xl font-semibold hover:bg-ink-800 transition lift flex items-center justify-center gap-2">
            Empezar la entrevista
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-6-6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          </button>
          <button
            onClick={onMarket}
            className="bg-white border border-ink-900/10 text-ink-900 px-6 py-3.5 rounded-xl font-semibold hover:border-orange-500 transition lift flex items-center justify-center gap-2">
            📊 Inteligencia de mercado
          </button>
        </div>
        <div className="fade-up flex items-center gap-2 text-sm text-ink-500 mb-12" style={{ animationDelay: '0.35s' }}>
          <span className="inline-flex items-center gap-1">⏱ 3 min</span>
          <span>·</span>
          <span>Entrevista con consentimiento</span>
          <span>·</span>
          <span>Inteligencia de mercado libre</span>
        </div>

        {/* How it works: 3 steps */}
        <div className="fade-up grid grid-cols-1 md:grid-cols-3 gap-4 mt-12" style={{ animationDelay: '0.4s' }}>
          {[
            { n: '01', t: '¿Qué quieres hacer?', d: 'Una conversación breve. La IA detecta tu sector de impacto.', icon: '💬' },
            { n: '02', t: '¿Qué haces hoy?', d: 'Tu historia, LinkedIn o CV. Tú decides qué compartes.', icon: '📄' },
            { n: '03', t: 'Tu plan de IA', d: 'Escuela recomendada + timeline 4-6 meses con datos reales.', icon: '🚀' },
          ].map((s, i) => (
            <div key={i} className="relative bg-white border border-ink-900/8 rounded-2xl p-5 lift">
              <div className="text-[10px] font-mono text-orange-500 mb-2">{s.n}</div>
              <div className="text-2xl mb-3">{s.icon}</div>
              <h3 className="font-bold text-ink-900 mb-1.5">{s.t}</h3>
              <p className="text-sm text-ink-500 leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>

        {/* AI impact badge */}
        <div className="fade-up mt-10 bg-ink-900 rounded-2xl p-5 text-white relative overflow-hidden" style={{ animationDelay: '0.5s' }}>
          <div className="absolute inset-0 dot-pattern opacity-30" />
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-orange-500 flex items-center justify-center">
              <span className="text-white text-xs font-black">IA</span>
            </div>
            <div className="flex-1">
              <div className="font-bold">El conocimiento de <span className="text-orange-500">IA</span> acelera tu carrera.</div>
              <div className="text-sm text-ink-300 mt-0.5">Los perfiles con IA acceden a +30% de salario y 2.5x más ofertas en {region === 'latam' ? 'Latinoamérica' : 'España'}.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// 6. GOAL INPUT — Chat / LinkedIn / CV / Sector-only
// ============================================================

function GoalInput({ onComplete, region }) {
  const [mode, setMode] = useState('chat'); // 'chat' | 'linkedin' | 'cv' | 'sector'
  const [goalText, setGoalText] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [cvFile, setCvFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [fallbackToSector, setFallbackToSector] = useState(false);
  const fileInputRef = useRef(null);

  const tabs = [
    { id: 'chat', label: 'Cuéntame', icon: '💬' },
    { id: 'linkedin', label: 'LinkedIn', icon: '🔗' },
    { id: 'cv', label: 'CV (PDF)', icon: '📄' },
    { id: 'sector', label: 'Solo mi sector', icon: '🎯' },
  ];

  const goalExamples = [
    'Quiero pasar de community manager a especialista en IA generativa en una agencia.',
    'Soy contable y quiero liderar el área de automatización IA de mi empresa.',
    'Quiero cambiar a desarrollo web con IA y ganar 45K€/año.',
    'Tengo experiencia en ventas y quiero especializarme en RevOps con IA.',
  ];

  // Naive sector inference from text
  function inferSector(text) {
    const t = text.toLowerCase();
    if (/market|community|seo|contenido|campa|publicidad|redes socia|brand|copy/.test(t)) return 'marketing';
    if (/desarroll|program|code|software|front|back|full.?stack|devops|web|app/.test(t)) return 'desarrollo';
    if (/vent|comercia|sales|bdr|sdr|account|rev.?ops/.test(t)) return 'ventas';
    if (/log[ií]stic|supply|cadena|almac[eé]n|transport|flota|ruta/.test(t)) return 'logistica';
    if (/gesti[oó]n|admin|direcci[oó]n|financ|contab|bi|analyst|operaciones/.test(t)) return 'gestion';
    return null;
  }

  async function handleChatSubmit() {
    if (goalText.trim().length < 15) return;
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 1200));
    const sector = inferSector(goalText);
    if (!sector) {
      setIsProcessing(false);
      setFallbackToSector(true);
      return;
    }
    setIsProcessing(false);
    onComplete({ sector, source: 'chat', goal: goalText });
  }

  async function handleLinkedinSubmit() {
    if (!linkedinUrl.includes('linkedin.com')) return;
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 1600));
    setIsProcessing(false);
    // Default to desarrollo for demo — real impl would parse
    onComplete({ sector: 'desarrollo', source: 'linkedin', linkedin: linkedinUrl });
  }

  async function handleCvSubmit() {
    if (!cvFile) return;
    setIsProcessing(true);
    try {
      let extracted = '';
      if (window.pdfjsLib && cvFile.type === 'application/pdf') {
        const buf = await cvFile.arrayBuffer();
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        const pdf = await pdfjsLib.getDocument(new Uint8Array(buf)).promise;
        for (let i = 1; i <= Math.min(pdf.numPages, 5); i++) {
          const page = await pdf.getPage(i);
          const c = await page.getTextContent();
          extracted += c.items.map(it => it.str).join(' ') + ' ';
        }
      }
      const sector = inferSector(extracted) || 'desarrollo';
      setIsProcessing(false);
      onComplete({ sector, source: 'cv', cvText: extracted.slice(0, 2000) });
    } catch (e) {
      setIsProcessing(false);
      alert('No pudimos leer el CV. Prueba con el modo Cuéntame.');
    }
  }

  function handleSectorSelect(sectorId) {
    onComplete({ sector: sectorId, source: 'sector' });
  }

  if (fallbackToSector) {
    return <SectorPick onPick={handleSectorSelect} subtitle="No pasa nada. Elige el sector que más te llama y te orientamos desde ahí." />;
  }

  return (
    <div className="max-w-3xl mx-auto px-5 pt-10 pb-16">
      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">PASO 1 DE 3</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          ¿Qué quieres hacer?
        </h2>
        <p className="text-ink-500 mb-8">
          Cuéntanos tu meta, sube tu perfil o escoge tu sector de interés. Todo queda entre tú y la <b className="text-ink-900">IA</b>.
        </p>
      </div>

      {/* Tabs */}
      <div className="fade-up flex gap-1 bg-ink-900/5 p-1 rounded-xl mb-6 overflow-x-auto" style={{ animationDelay: '0.1s' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setMode(t.id)}
            className={`flex-1 min-w-[100px] px-3 py-2.5 rounded-lg text-sm font-medium transition flex items-center justify-center gap-2 ${mode === t.id ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-800'}`}>
            <span>{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Chat mode */}
      {mode === 'chat' && (
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.2s' }}>
          <label className="text-sm font-bold text-ink-900 mb-2 block">Tu meta profesional</label>
          <textarea
            value={goalText}
            onChange={(e) => setGoalText(e.target.value)}
            placeholder="Ej: Quiero pasar de marketing tradicional a especialista en IA generativa para agencias..."
            className="w-full min-h-[140px] p-4 border border-ink-900/10 rounded-xl bg-paper text-ink-900 resize-none focus:border-orange-500 transition"
          />
          <div className="flex flex-wrap gap-2 mt-3">
            {goalExamples.map((ex, i) => (
              <button key={i} onClick={() => setGoalText(ex)}
                className="text-xs px-3 py-1.5 bg-ink-900/5 hover:bg-ink-900/10 rounded-full text-ink-500 transition">
                {ex.slice(0, 45)}…
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between mt-5">
            <div className="text-xs text-ink-500">{goalText.length} caracteres</div>
            <button onClick={handleChatSubmit} disabled={goalText.trim().length < 15 || isProcessing}
              className="bg-ink-900 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2">
              {isProcessing ? <>Analizando con IA…<span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /></> : <>Continuar →</>}
            </button>
          </div>
          <button onClick={() => setFallbackToSector(true)} className="mt-3 text-xs text-ink-500 hover:text-orange-500">
            No tengo claro mi camino. Ayúdame a elegir el sector.
          </button>
        </div>
      )}

      {/* LinkedIn mode */}
      {mode === 'linkedin' && (
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.2s' }}>
          <label className="text-sm font-bold text-ink-900 mb-2 block">URL de tu perfil de LinkedIn</label>
          <input
            value={linkedinUrl}
            onChange={(e) => setLinkedinUrl(e.target.value)}
            type="url"
            placeholder="https://www.linkedin.com/in/tu-perfil"
            className="w-full p-4 border border-ink-900/10 rounded-xl bg-paper text-ink-900 focus:border-orange-500 transition"
          />
          <div className="text-xs text-ink-500 mt-2">Leeremos tu perfil público. Nada se guarda.</div>
          <div className="flex items-center justify-end mt-5">
            <button onClick={handleLinkedinSubmit} disabled={!linkedinUrl.includes('linkedin.com') || isProcessing}
              className="bg-ink-900 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2">
              {isProcessing ? <>Leyendo perfil…<span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /></> : <>Analizar perfil →</>}
            </button>
          </div>
        </div>
      )}

      {/* CV mode */}
      {mode === 'cv' && (
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.2s' }}>
          <label className="text-sm font-bold text-ink-900 mb-2 block">Sube tu CV en PDF</label>
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-ink-900/15 rounded-xl p-8 text-center cursor-pointer hover:border-orange-500 transition">
            <div className="text-3xl mb-2">📄</div>
            <div className="font-medium text-ink-900">{cvFile ? cvFile.name : 'Haz clic para subir tu CV'}</div>
            <div className="text-xs text-ink-500 mt-1">PDF · máx 5MB</div>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            onChange={(e) => setCvFile(e.target.files[0])}
            className="hidden"
          />
          <div className="flex items-center justify-end mt-5">
            <button onClick={handleCvSubmit} disabled={!cvFile || isProcessing}
              className="bg-ink-900 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2">
              {isProcessing ? <>Leyendo CV…<span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /></> : <>Analizar CV →</>}
            </button>
          </div>
        </div>
      )}

      {/* Sector-only */}
      {mode === 'sector' && (
        <SectorPick onPick={handleSectorSelect} subtitle="Perfecto. Escoge el sector donde quieres crecer y te orientamos desde ahí." />
      )}
    </div>
  );
}

// ============================================================
// 7. SECTOR PICKER
// ============================================================

function SectorPick({ onPick, subtitle }) {
  return (
    <div className="fade-up" style={{ animationDelay: '0.1s' }}>
      {subtitle && <p className="text-ink-500 mb-5">{subtitle}</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {Object.values(SECTORS).map((s, i) => (
          <button key={s.id} onClick={() => onPick(s.id)}
            className="text-left bg-white border border-ink-900/8 rounded-2xl p-5 lift hover:border-orange-500 transition group">
            <div className="flex items-start justify-between mb-3">
              <span className="text-3xl">{s.icon}</span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-500">Impacto IA {s.impactScore}</span>
            </div>
            <h3 className="font-bold text-ink-900 mb-1">{s.name}</h3>
            <p className="text-sm text-ink-500 leading-snug mb-3">{s.tagline}</p>
            <div className="flex items-center gap-1 text-xs text-ink-500 group-hover:text-orange-500 transition">
              Elegir sector <span>→</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// 8. SECTOR INSIGHT — AI impact, what you should know, trends
// ============================================================

function SectorInsight({ sector, region, onContinue, onBack }) {
  const s = SECTORS[sector];
  const market = getMarketData(region, sector);
  const currency = region === 'latam' ? 'USD' : '€';

  return (
    <div className="max-w-5xl mx-auto px-5 pt-10 pb-16">
      <button onClick={onBack} className="text-xs text-ink-500 hover:text-orange-500 mb-4 flex items-center gap-1">
        ← Cambiar sector
      </button>

      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">PASO 3 DE 3 · {s.name.toUpperCase()}</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight flex items-center gap-3">
          <span>{s.icon}</span>
          <span>¿Qué deberías saber hoy en <span className="text-orange-500">{s.name}</span>?</span>
        </h2>
        <p className="text-ink-500 mb-8 max-w-2xl">{s.description}</p>
      </div>

      {/* Live market stats */}
      <div className="fade-up grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8" style={{ animationDelay: '0.1s' }}>
        <StatCard label="Ofertas activas" value={market.offers.toLocaleString('es-ES')} sub={`Top: ${market.topCity}`} />
        <StatCard label="Ofertas con IA" value={market.aiOffers.toLocaleString('es-ES')} sub={`${Math.round((market.aiOffers/market.offers)*100)}% del total`} accent />
        <StatCard label="Salario medio" value={`${(market.avgSalary/1000).toFixed(0)}K ${currency}`} sub="Anual" />
        <StatCard label="Crecimiento YoY" value={`+${market.growth}%`} sub="Demanda" accent />
      </div>

      {/* What you should know today */}
      <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-6 mb-8" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center">
            <span className="text-orange-500 text-xs font-black">IA</span>
          </div>
          <h3 className="font-bold text-ink-900">Lo que deberías dominar hoy</h3>
        </div>
        <ul className="space-y-2.5">
          {s.todayYouShouldKnow.map((item, i) => (
            <li key={i} className="flex items-start gap-3 text-sm">
              <span className="flex-shrink-0 w-5 h-5 rounded-md bg-orange-50 flex items-center justify-center text-orange-500 font-bold text-[10px]">{i + 1}</span>
              <span className="text-ink-800 leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Trends */}
      <div className="fade-up bg-ink-900 rounded-2xl p-6 mb-8 text-white relative overflow-hidden" style={{ animationDelay: '0.3s' }}>
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs uppercase tracking-wider text-orange-500 font-bold">Tendencias ahora</span>
            <span className="text-[10px] text-ink-300">{DATA_SOURCES[region].region} · 6:00 AM hoy</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {s.trends.map((t, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="text-2xl font-black text-orange-500 mb-1">{t.v}</div>
                <div className="text-sm text-ink-300">{t.k}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="fade-up flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.4s' }}>
        <div>
          <div className="font-bold text-ink-900">¿Quieres el plan para llegar allí?</div>
          <div className="text-sm text-ink-500 mt-0.5">Te mostramos la escuela de <b className="text-orange-500">IA</b> aplicada a {s.name.toLowerCase()} y el timeline real.</div>
        </div>
        <button onClick={onContinue}
          className="bg-ink-900 text-white px-6 py-3 rounded-xl font-semibold hover:bg-ink-800 transition lift flex items-center gap-2">
          Ver mi plan <span>→</span>
        </button>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div className={`rounded-2xl p-4 border ${accent ? 'bg-orange-50 border-orange-100' : 'bg-white border-ink-900/8'}`}>
      <div className="text-xs text-ink-500 mb-1">{label}</div>
      <div className={`text-2xl font-black ${accent ? 'text-orange-600' : 'text-ink-900'}`}>{value}</div>
      {sub && <div className="text-[10px] text-ink-500 mt-1">{sub}</div>}
    </div>
  );
}

// B2C-friendly card with plain-language explanation
function ExplainCard({ icon, big, title, plain, warning, accent }) {
  return (
    <div className={`rounded-2xl p-4 border relative overflow-hidden ${accent ? 'bg-orange-50 border-orange-100' : 'bg-white border-ink-900/8'}`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xl">{icon}</span>
        <div className={`text-2xl font-black ${accent ? 'text-orange-600' : 'text-ink-900'}`}>{big}</div>
      </div>
      <div className="text-sm font-bold text-ink-900">{title}</div>
      <div className="text-xs text-ink-500 leading-relaxed mt-1">{plain}</div>
      {warning && (
        <div className="text-[11px] text-orange-600 font-bold mt-2 border-t border-ink-900/5 pt-2">
          ⚠️ {warning}
        </div>
      )}
    </div>
  );
}

// ============================================================
// 9. PLAN — Academy + Timeline
// ============================================================

// ============================================================
// ANALYZING — 5s analysis screen between Profile and Plan
// ============================================================

function Analyzing({ sector, userData, region, onDone }) {
  const [step, setStep] = useState(0);
  const sectorName = SECTORS[sector]?.name || 'tu sector';
  const stepsList = [
    { label: `Leyendo tu perfil…`, desc: 'Procesamos tu historia, CV o LinkedIn.' },
    { label: `Cruzando con ${DATA_SOURCES[region].region}…`, desc: 'Comparamos con ofertas reales del mercado.' },
    { label: `Detectando habilidades clave en ${sectorName}…`, desc: 'Identificamos lo que necesitas dominar hoy.' },
    { label: `Calculando tu itinerario IA…`, desc: 'Personalizamos retos y microcredenciales.' },
    { label: `Listo`, desc: 'Tu plan está preparado.' },
  ];

  useEffect(() => {
    const totalMs = 5000;
    const perStep = totalMs / stepsList.length;
    const timer = setInterval(() => {
      setStep(s => {
        if (s >= stepsList.length - 1) {
          clearInterval(timer);
          setTimeout(() => onDone(), 400);
          return s;
        }
        return s + 1;
      });
    }, perStep);
    return () => clearInterval(timer);
  }, []);

  const progress = ((step + 1) / stepsList.length) * 100;

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-5">
      <div className="max-w-md w-full">
        <div className="fade-up text-center mb-8">
          <div className="text-xs text-orange-500 font-bold tracking-wide mb-2">ANALIZANDO TU PERFIL</div>
          <h2 className="text-3xl md:text-4xl font-black text-ink-900 leading-tight mb-2">
            Trabajando con <span className="text-orange-500">IA</span>…
          </h2>
          <p className="text-sm text-ink-500">{userData?.name?.split(' ')[0]}, en unos segundos tendrás tu itinerario.</p>
        </div>

        {/* Animated radar / orbit */}
        <div className="fade-up flex items-center justify-center mb-10" style={{ animationDelay: '0.1s' }}>
          <div className="relative w-32 h-32">
            <div className="absolute inset-0 rounded-full border border-orange-500/20" />
            <div className="absolute inset-3 rounded-full border border-orange-500/15" />
            <div className="absolute inset-6 rounded-full border border-orange-500/10" />
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-orange-500" style={{ animation: 'spin 1.6s linear infinite' }} />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-12 h-12 rounded-2xl bg-ink-900 flex items-center justify-center">
                <span className="text-orange-500 font-black text-lg">IA</span>
              </div>
            </div>
            <style>{`@keyframes spin { from { transform: rotate(0); } to { transform: rotate(360deg); } }`}</style>
          </div>
        </div>

        {/* Progress bar */}
        <div className="fade-up bg-ink-900/5 rounded-full h-1.5 overflow-hidden mb-5" style={{ animationDelay: '0.15s' }}>
          <div className="h-full bg-orange-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>

        {/* Steps */}
        <div className="fade-up space-y-2.5" style={{ animationDelay: '0.2s' }}>
          {stepsList.map((st, i) => (
            <div key={i} className={`flex items-center gap-3 transition-opacity ${i > step ? 'opacity-30' : 'opacity-100'}`}>
              <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i < step ? 'bg-orange-500 text-white' : i === step ? 'bg-orange-500 text-white' : 'bg-ink-900/5 text-ink-500'}`}>
                {i < step ? '✓' : i === step ? <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> : i + 1}
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium text-ink-900">{st.label}</div>
                {i === step && <div className="text-xs text-ink-500">{st.desc}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Plan({ sector, region, userData, onRestart }) {
  // Support multi-sector
  const sectors = userData?.sectors?.length ? userData.sectors : [sector];
  const [activeSector, setActiveSector] = useState(sectors[0]);
  const s = SECTORS[activeSector];
  const academy = getEffectiveAcademy(s.academy);
  const skills = ACADEMY_SKILLS[s.academy] || [];
  const [view, setView] = useState('timeline');

  // Record lead in admin store
  useEffect(() => {
    if (userData?.email) {
      adminStore.addLead({
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        sectors: sectors,
        level: userData.level,
        goal: userData.goalText,
        marketing: userData.marketing,
      });
    }
  }, []);

  const handleDownload = () => generateItineraryPDF({ academy, sector: s, skills, userData, region });

  return (
    <div className="max-w-5xl mx-auto px-5 pt-10 pb-20">
      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">TU ITINERARIO · ACELERADORA IA</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          Tu camino en <span className="text-orange-500">{academy.shortName}</span>
        </h2>
        <p className="text-ink-500 mb-6">
          Aceleradora con <b className="text-orange-500">IA</b> para empleos del presente. {academy.duration} · {academy.synchronous}. Este itinerario se genera a medida con {DATA_SOURCES[region].region} + observatorio global.
        </p>

        {sectors.length > 1 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {sectors.map(sid => (
              <button key={sid} onClick={() => setActiveSector(sid)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition flex items-center gap-1 ${activeSector === sid ? 'bg-ink-900 text-white' : 'bg-white border border-ink-900/10 text-ink-800'}`}>
                <span>{SECTORS[sid].icon}</span>{SECTORS[sid].name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-ink-900/5 p-1 rounded-xl mb-6 max-w-xl overflow-x-auto">
        {[
          { id: 'plan', label: 'Plan' },
          { id: 'troncal', label: 'IA Studio · Troncal' },
          { id: 'retos', label: 'Retos + Badges' },
          { id: 'timeline', label: 'Timeline' },
        ].map(t => (
          <button key={t.id} onClick={() => setView(t.id)}
            className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${view === t.id ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {view === 'plan' && <AcademyOverview academy={academy} region={region} />}
      {view === 'troncal' && <TroncalView academyId={academy.id} />}
      {view === 'retos' && <RetosView skills={skills} level={userData?.level} region={region} />}
      {view === 'timeline' && <Timeline academy={academy} />}

      {/* CTAs */}
      <div className="fade-up mt-8 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button onClick={handleDownload}
          className="bg-orange-500 text-white px-5 py-3.5 rounded-xl font-semibold hover:bg-orange-600 transition lift flex items-center justify-center gap-2">
          📄 Descargar itinerario PDF
        </button>
        <a href={`mailto:admisiones@refactika.com?subject=Quiero información sobre ${academy.shortName}&body=Hola, soy ${userData?.name || ''} y quiero información sobre la Aceleradora ${academy.shortName}.`}
          className="bg-ink-900 text-white px-5 py-3.5 rounded-xl font-semibold hover:bg-ink-800 transition lift text-center flex items-center justify-center gap-2">
          💬 Que me contacten
        </a>
        <a href={academy.link} target="_blank" rel="noopener"
          className="bg-white border border-ink-900/10 text-ink-900 px-5 py-3.5 rounded-xl font-semibold hover:border-orange-500 transition text-center flex items-center justify-center gap-2">
          🛒 Comprar online
        </a>
      </div>

      <div className="mt-4 text-center">
        <button onClick={onRestart} className="text-xs text-ink-500 hover:text-orange-500">Volver a empezar</button>
      </div>
    </div>
  );
}

function TroncalView({ academyId }) {
  const gymPass = academyId ? syncPassForAcademy(academyId) : 10;
  return (
    <div className="fade-up space-y-4">
      {/* Hero */}
      <div className="bg-ink-900 text-white rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-500">Troncal común · Aprender haciendo</span>
            <span className="text-[10px] bg-orange-500 text-white px-2 py-0.5 rounded-full font-bold">120 h</span>
          </div>
          <h3 className="text-2xl font-black mb-2">{TRONCAL.name}</h3>
          <p className="text-sm text-ink-300 leading-relaxed">{TRONCAL.tagline}</p>
        </div>
      </div>

      {/* Modules */}
      <div className="bg-white border border-ink-900/8 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-ink-500">{TRONCAL.description}</div>
        </div>
        <div className="space-y-3">
          {TRONCAL.modules.map((m, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-lg">{m.icon}</div>
              <div className="flex-1">
                <div className="font-bold text-ink-900 flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-mono text-orange-500">T{i+1}</span>
                  <span>{m.name}</span>
                  <span className="text-[10px] bg-ink-900/5 text-ink-500 px-2 py-0.5 rounded-full">{m.hours} h</span>
                </div>
                <div className="text-sm text-ink-500 mt-0.5">{m.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gimnasio sincrónico */}
      <div className="bg-gradient-to-br from-orange-50 to-white border border-orange-100 rounded-2xl p-5">
        <div className="flex items-start justify-between mb-3 flex-wrap gap-2">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-orange-500">Gimnasio sincrónico</div>
            <h4 className="text-lg font-black text-ink-900 mt-0.5">Modalidad gimnasio · catálogo abierto</h4>
          </div>
          <div className="bg-ink-900 text-white px-3 py-1.5 rounded-xl text-xs font-bold">
            Tu pase: <span className="text-orange-500">{gymPass} sesiones</span>
          </div>
        </div>
        <p className="text-sm text-ink-500 mb-4">
          Hay <b className="text-ink-900">muchas sesiones sincrónicas en vivo</b> cada semana. Reservas las que quieras del catálogo, hasta el máximo del pase de tu programa (5 o 10).
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {SYNC_FORMATS.map((f, i) => (
            <div key={f.id} className="bg-white border border-ink-900/8 rounded-xl p-4 lift">
              <div className="flex items-center gap-2 mb-2">
                <div className="text-2xl">{f.icon}</div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-orange-500">Formato {i+1}</span>
              </div>
              <div className="font-bold text-ink-900 leading-tight">{f.name}</div>
              <div className="text-xs text-ink-500 mt-0.5 mb-2">{f.short}</div>
              <div className="text-xs text-ink-800 leading-relaxed mb-2">{f.desc}</div>
              <div className="text-[11px] text-orange-600 font-bold border-t border-ink-900/5 pt-2 mt-2">⏱ {f.duration}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Pass criteria */}
      <div className="bg-ink-900 text-white rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center flex-shrink-0">
            <span className="text-white font-black text-sm">75%</span>
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider text-orange-500 font-bold mb-1">Criterio de superación del troncal</div>
            <div className="text-sm leading-relaxed">Completas al menos el 75 % de los retos propuestos · al menos 2 en formato colaborativo. Solo con el troncal superado se desbloquean los retos específicos de tu vertical.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RetosView({ skills, level, region }) {
  // Adjust by level
  const levelFilter = level === 'inicial' ? 'media' : level === 'experto' ? 'alta' : null;
  const showSkills = levelFilter ? skills.filter(s => s.complexity === levelFilter).concat(skills.filter(s => s.complexity !== levelFilter)).slice(0, 4) : skills;

  return (
    <div className="fade-up space-y-4">
      <div className="bg-orange-50 border border-orange-100 rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-orange-500 text-white flex items-center justify-center font-black">R</div>
          <div>
            <div className="font-bold text-ink-900">Metodología basada en retos</div>
            <div className="text-sm text-ink-500">Cada reto completado desbloquea conocimiento y aporta al gran proyecto evolutivo de tu habilidad.</div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
          {[
            { n: '1', t: 'Contexto real', d: 'Cada reto nace de un caso de empresa real.' },
            { n: '2', t: 'Acompañamiento', d: 'Mentor + grupo colaborativo sincrónico.' },
            { n: '3', t: 'Entregable', d: 'Tu reto se integra en el proyecto evolutivo.' },
            { n: '4', t: 'Microcredencial', d: 'Al superar la habilidad recibes tu badge Refactika.' },
          ].map((step, i) => (
            <div key={i} className="bg-white rounded-xl p-3">
              <div className="text-xs text-orange-500 font-mono">PASO {step.n}</div>
              <div className="font-bold text-ink-900 text-sm mt-1">{step.t}</div>
              <div className="text-[11px] text-ink-500 leading-snug">{step.d}</div>
            </div>
          ))}
        </div>
      </div>

      <h4 className="text-sm font-bold text-ink-900 mt-2">Habilidades que desbloqueas · cada una genera una microcredencial</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {showSkills.map((sk, i) => (
          <div key={sk.id} className="bg-white border border-ink-900/8 rounded-2xl p-5 flex gap-4 items-center">
            <RefactikaBadge title={sk.title} size={110} />
            <div className="flex-1">
              <div className="text-[10px] font-bold uppercase tracking-wider text-ink-500">Habilidad {i+1} · {sk.complexity === 'alta' ? '22 semanas' : '14 semanas'}</div>
              <div className="font-bold text-ink-900 mt-0.5 leading-tight">{sk.title.replace(/\n/g, ' ')}</div>
              <div className="text-xs text-ink-500 mt-1 leading-snug">{sk.desc}</div>
              <div className="text-xs text-orange-500 font-bold mt-2">
                {sk.complexity === 'alta' ? '10 sesiones sincrónicas · 450 h · reto semanal' : '5 sesiones sincrónicas · 300 h · reto semanal'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// PDF — Itinerario formativo (downloadable)
// ============================================================

// Distinctive PDF bullet marker — orange rounded chevron with number and pixel tail
function drawBulletPDF(doc, x, y, n, label) {
  // Orange rounded square with white number (tab-style chevron)
  doc.setFillColor(255, 106, 0);
  doc.roundedRect(x, y - 4.5, 9, 9, 1.2, 1.2, 'F');
  // Arrow-like tail triangle pointing right (chevron feel)
  doc.triangle(x + 9, y - 4.5, x + 12, y, x + 9, y + 4.5, 'F');
  // Pixel marker above (tech accent) — 3 little squares
  doc.setFillColor(0, 10, 26);
  doc.rect(x - 0.5, y - 6, 1.2, 1.2, 'F');
  doc.rect(x + 1.5, y - 6, 1.2, 1.2, 'F');
  doc.rect(x + 3.5, y - 6, 1.2, 1.2, 'F');
  // Number inside
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text(String(label !== undefined ? label : n), x + 4.5, y + 1.5, { align: 'center' });
}

// Step/check bullet — circle with check for outcomes/completed items
function drawCheckBulletPDF(doc, x, y) {
  doc.setFillColor(255, 106, 0);
  doc.circle(x + 3, y, 3, 'F');
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.5);
  doc.line(x + 1.6, y + 0.2, x + 2.6, y + 1.4);
  doc.line(x + 2.6, y + 1.4, x + 4.6, y - 1.4);
}

function drawBadgePDF(doc, cx, cy, r, title) {
  // Outer orange
  doc.setFillColor(255, 106, 0);
  doc.circle(cx, cy, r + 1.2, 'F');
  doc.setFillColor(255, 140, 51);
  doc.circle(cx, cy, r, 'F');
  doc.setFillColor(255, 106, 0);
  doc.circle(cx, cy, r - 0.4, 'F');
  // Dark ribbon
  const ribbonH = r * 0.55;
  doc.setFillColor(0, 10, 26);
  doc.rect(cx - r * 0.95, cy - ribbonH / 2, r * 1.9, ribbonH, 'F');
  // Ribbon text
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  const lines = title.split('\n');
  const baseSize = Math.max(4, r / 4.5);
  doc.setFontSize(baseSize);
  lines.forEach((line, i) => {
    doc.text(line, cx, cy - (lines.length - 1) / 2 * (baseSize * 0.4) + i * (baseSize * 0.4), { align: 'center' });
  });
  // REFACTIKA header
  doc.setTextColor(0, 10, 26);
  doc.setFontSize(r / 4);
  doc.text('REFACTIKA', cx, cy - r * 0.55, { align: 'center' });
  // MICROCREDENCIAL footer
  doc.setFontSize(r / 5.5);
  doc.text('MICROCREDENCIAL', cx, cy + r * 0.72, { align: 'center' });
}

// Light/clean editorial-style PDF · magazine cover feel · zero overlapping
function generateItineraryPDF({ academy, sector, skills, userData, region }) {
  userData = userData || { name: '', email: '' };
  region = region || 'espana';
  if (!skills || skills.length === 0) skills = ACADEMY_SKILLS[academy.id] || [];

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageW = 210, pageH = 297, M = 18;
  const cw = pageW - M * 2;
  // Palette
  const C = {
    paper: [253, 251, 248],   // soft cream
    ink:   [16, 23, 41],      // deep navy
    inkSoft: [60, 70, 95],
    gray:  [120, 125, 145],
    border:[226, 226, 232],
    orange:[255, 106, 0],
    orangeSoft: [255, 240, 225],
    green: [0, 184, 148],
  };
  const setFill = c => doc.setFillColor(c[0], c[1], c[2]);
  const setText = c => doc.setTextColor(c[0], c[1], c[2]);
  const setDraw = c => doc.setDrawColor(c[0], c[1], c[2]);

  // Page chrome (lightweight header strip + footer brand)
  function drawChrome(eyebrow) {
    setFill(C.paper); doc.rect(0, 0, pageW, pageH, 'F');
    // Top hairline strip with brand
    setFill(C.ink); doc.rect(0, 0, pageW, 14, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.text('ORIENTADOR', M, 9);
    setText(C.orange); doc.text('IA', M + doc.getTextWidth('ORIENTADOR'), 9);
    setText([180, 180, 200]); doc.setFont('helvetica', 'normal'); doc.setFontSize(7);
    doc.text('by REFACTIKA · Grupo Aspasia', M + doc.getTextWidth('ORIENTADOR') + doc.getTextWidth('IA') + 4, 9);
    if (eyebrow) {
      setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(7);
      doc.text(eyebrow.toUpperCase(), pageW - M, 9, { align: 'right' });
    }
    // Hairline accent
    setFill(C.orange); doc.rect(0, 14, pageW, 0.6, 'F');
    // Footer
    setText(C.gray); doc.setFont('helvetica', 'normal'); doc.setFontSize(7);
    doc.text('refactika.com · Aceleradora IA · 2026', M, pageH - 9);
    doc.text(academy.shortName, pageW - M, pageH - 9, { align: 'right' });
  }

  // Numbered chip (clean square w/ number, no chevron)
  function chip(x, y, n, color) {
    color = color || C.orange;
    setFill(color);
    doc.roundedRect(x, y, 8, 8, 1.4, 1.4, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.text(String(n).padStart(2, '0'), x + 4, y + 5.2, { align: 'center' });
  }

  // Plain dot bullet (orange filled circle)
  function dot(x, y, color) {
    setFill(color || C.orange);
    doc.circle(x, y, 1.2, 'F');
  }

  // Inline icon (vector, no emoji)
  function icon(type, cx, cy, color) {
    color = color || C.orange;
    setFill(color);
    if (type === 'mail') {
      doc.roundedRect(cx - 5, cy - 3.5, 10, 7, 1, 1, 'F');
      setDraw([255, 255, 255]); doc.setLineWidth(0.4);
      doc.line(cx - 5, cy - 3.5, cx, cy + 0.5);
      doc.line(cx, cy + 0.5, cx + 5, cy - 3.5);
    } else if (type === 'cart') {
      doc.roundedRect(cx - 5, cy - 3, 9, 5, 0.8, 0.8, 'F');
      doc.circle(cx - 3, cy + 3, 0.9, 'F');
      doc.circle(cx + 3, cy + 3, 0.9, 'F');
      doc.line(cx - 5.5, cy - 4, cx - 4.2, cy - 3);
    } else if (type === 'phone') {
      // Phone outline (rounded)
      doc.roundedRect(cx - 3.2, cy - 5, 6.4, 10, 1.5, 1.5, 'F');
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(cx - 2.4, cy - 3.8, 4.8, 7.2, 0.6, 0.6, 'F');
      setFill(color);
      doc.circle(cx, cy + 4, 0.5, 'F');
    }
  }

  // ============================================================
  // PAGE 1 — COVER (editorial · light · no overlapping)
  // ============================================================
  drawChrome('Itinerario formativo');

  // Date · top right
  setText(C.gray); doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
  const today = new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  doc.text(today, pageW - M, 24, { align: 'right' });

  // Eyebrow
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('ACELERADORA IA · ITINERARIO FORMATIVO', M, 36);

  // Big editorial title (no overlapping line) — 3 stack
  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(36);
  doc.text('Tu itinerario', M, 60);
  doc.text('con', M, 75);
  setText(C.orange);
  doc.text('IA aplicada.', M + doc.getTextWidth('con ') + 1, 75);

  // Big school name — own block, comfortable spacing
  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(20);
  const schoolLines = doc.splitTextToSize(academy.name, cw - 6);
  schoolLines.forEach((line, i) => doc.text(line, M, 95 + i * 9));
  const schoolBlockEnd = 95 + schoolLines.length * 9;

  // Decorative thin line UNDER the school name (not over it)
  setFill(C.orange);
  doc.rect(M, schoolBlockEnd + 4, 30, 1.2, 'F');

  // Tagline under
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  const taglineY = schoolBlockEnd + 14;
  doc.text(`Aceleradora con IA para empleos del presente.`, M, taglineY);
  doc.text(`${academy.duration} · aprende haciendo · microcredenciales Refactika.`, M, taglineY + 6);

  // User card — bottom-left, light
  if (userData?.name) {
    const cardY = 168;
    setFill([255, 255, 255]);
    doc.roundedRect(M, cardY, cw * 0.55, 24, 3, 3, 'F');
    setDraw(C.border); doc.setLineWidth(0.3);
    doc.roundedRect(M, cardY, cw * 0.55, 24, 3, 3, 'S');
    setText(C.gray); doc.setFontSize(7); doc.setFont('helvetica', 'bold');
    doc.text('PREPARADO PARA', M + 5, cardY + 7);
    setText(C.ink); doc.setFontSize(13);
    doc.text(userData.name, M + 5, cardY + 14);
    if (userData.email) {
      setText(C.inkSoft); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
      doc.text(userData.email, M + 5, cardY + 20);
    }
  }

  // Quick numbers — 4 small stat cards
  const statY = 200;
  const stats = [
    { l: 'Duración', v: academy.duration },
    { l: 'Habilidades', v: `${skills.length}` },
    { l: 'Sincrónico', v: academy.synchronous.split(' ')[0] + ' sesiones' },
    { l: 'Inversión', v: 'desde ' + (region === 'latam' ? academy.priceUsd : academy.priceEur) },
  ];
  const statW = (cw - 9) / 4;
  stats.forEach((st, i) => {
    const sx = M + i * (statW + 3);
    setFill([255, 255, 255]); doc.roundedRect(sx, statY, statW, 22, 2, 2, 'F');
    setDraw(C.border); doc.roundedRect(sx, statY, statW, 22, 2, 2, 'S');
    setText(C.gray); doc.setFontSize(7); doc.setFont('helvetica', 'bold');
    doc.text(st.l.toUpperCase(), sx + 4, statY + 7);
    setText(C.ink); doc.setFontSize(11); doc.setFont('helvetica', 'bold');
    doc.text(st.v, sx + 4, statY + 16);
  });

  // Pixel art tech motif (top-right corner — discreet)
  for (let i = 0; i < 8; i++) {
    setFill(i % 3 === 0 ? C.orange : C.border);
    doc.rect(pageW - M - 18 + (i % 4) * 4, 24 + Math.floor(i / 4) * 4, 2.4, 2.4, 'F');
  }

  // Bottom call-out — pull quote
  setFill(C.ink);
  doc.roundedRect(M, 240, cw, 28, 3, 3, 'F');
  setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
  doc.text('Si no te formas en IA, alguien te reemplazará.', M + 8, 252);
  setText(C.orange); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
  doc.text('Es por eso que diseñamos un itinerario hecho a medida para ti.', M + 8, 260);

  // ============================================================
  // PAGE 2 — METODOLOGÍA (light, magazine spread)
  // ============================================================
  doc.addPage();
  drawChrome('Metodología');

  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('IA STUDIO · APRENDER HACIENDO', M, 30);

  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(26);
  doc.text('El troncal común', M, 46);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  let y = 56;
  const trDesc = doc.splitTextToSize(TRONCAL.description, cw);
  doc.text(trDesc, M, y); y += trDesc.length * 5 + 8;

  // Modules — light cards · 2 cols where possible
  TRONCAL.modules.forEach((m, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, y, cw, 18, 2.5, 2.5, 'F');
    setDraw(C.border); doc.roundedRect(M, y, cw, 18, 2.5, 2.5, 'S');
    chip(M + 5, y + 5, i + 1);
    setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(10);
    doc.text(m.name, M + 18, y + 7.5);
    setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
    doc.text(doc.splitTextToSize(m.desc, cw - 26), M + 18, y + 13);
    y += 21;
  });

  y += 4;
  // Retos call-out — light cream with orange edge
  setFill(C.orangeSoft);
  doc.roundedRect(M, y, cw, 36, 3, 3, 'F');
  setFill(C.orange); doc.rect(M, y, 2.5, 36, 'F');
  setText(C.orange); doc.setFontSize(8); doc.setFont('helvetica', 'bold');
  doc.text('METODOLOGÍA BASADA EN RETOS', M + 7, y + 9);
  setText(C.ink); doc.setFontSize(10); doc.setFont('helvetica', 'normal');
  const retoText = 'Cada habilidad se desbloquea a través de retos semanales reales. Los retos alimentan un proyecto evolutivo por habilidad. Al superarlo recibes una microcredencial Refactika que puedes compartir en LinkedIn.';
  doc.text(doc.splitTextToSize(retoText, cw - 14), M + 7, y + 17);

  // ============================================================
  // PAGE 3+ — SKILLS & MICROCREDENCIALES (light)
  // ============================================================
  doc.addPage();
  drawChrome('Habilidades · ' + academy.shortName);

  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('TUS MICROCREDENCIALES', M, 30);
  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(26);
  doc.text('Las habilidades que', M, 46);
  doc.text('vas a dominar', M, 58);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
  doc.text(`Cada habilidad superada te da una microcredencial Refactika que puedes`, M, 68);
  doc.text(`compartir en LinkedIn. Las complejas: 22 semanas. Las medias: 14 semanas.`, M, 73);

  y = 84;
  skills.forEach((sk, i) => {
    if (y > pageH - 60) {
      doc.addPage();
      drawChrome('Habilidades · ' + academy.shortName);
      y = 30;
    }
    // Card
    setFill([255, 255, 255]); doc.roundedRect(M, y, cw, 50, 3, 3, 'F');
    setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(M, y, cw, 50, 3, 3, 'S');
    // Badge
    drawBadgePDF(doc, M + 18, y + 25, 14, sk.title);
    // Number chip top-left
    chip(M + 5, y + 5, i + 1);
    // Title
    setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(12);
    doc.text(sk.title.replace(/\n/g, ' '), M + 40, y + 12);
    // Pills · complexity + price (right side)
    const isComplex = sk.complexity === 'alta';
    setFill(isComplex ? C.ink : C.orange);
    const pillTxt = isComplex ? '22 SEMANAS' : '14 SEMANAS';
    const pillW = doc.getTextWidth(pillTxt) + 6;
    doc.roundedRect(pageW - M - pillW - 5, y + 6, pillW, 6, 1.5, 1.5, 'F');
    setText([255, 255, 255]); doc.setFontSize(6.5);
    doc.text(pillTxt, pageW - M - 5 - pillW / 2, y + 10, { align: 'center' });
    // Description
    setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    doc.text(doc.splitTextToSize(sk.desc, cw - 50), M + 40, y + 19);
    // Meta row · plain dots (clear, no chevron)
    const metaY = y + 36;
    const metas = [
      isComplex ? '10 sesiones · 450 h' : '5 sesiones · 300 h',
      'Reto semanal',
      'Microcredencial',
    ];
    let mx = M + 40;
    metas.forEach(t => {
      dot(mx, metaY);
      setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
      doc.text(t, mx + 3, metaY + 1.2);
      mx += doc.getTextWidth(t) + 9;
    });
    // Price
    setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text(`Desde ${priceForSkill(sk, region)}`, pageW - M - 5, y + 45, { align: 'right' });
    y += 54;
  });

  // ============================================================
  // LAST PAGE — CTA (light, clean, fixed bullets)
  // ============================================================
  doc.addPage();
  drawChrome('Siguientes pasos');

  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('SIGUIENTES PASOS', M, 30);

  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(26);
  doc.text('¿Quieres que te', M, 50);
  doc.text('acompañemos en', M, 62);
  doc.text('tu itinerario?', M, 74);

  setText(C.inkSoft); doc.setFontSize(11); doc.setFont('helvetica', 'normal');
  doc.text(`Estás a un paso. Elige cómo quieres seguir y arrancamos contigo${userData?.name ? ', ' + userData.name.split(' ')[0] : ''}.`, M, 86);

  // 3 CTA cards · big, clean, with vector icons (no emoji)
  const ctas = [
    { type: 'mail',  t: 'Habla con nosotros', d: 'Resuelve dudas con un asesor en menos de 24h.', a: 'admisiones@refactika.com', color: C.orange },
    { type: 'cart',  t: 'Compra online',      d: 'Accede hoy mismo a tu Aceleradora.',            a: academy.link.replace('https://', ''), color: C.ink },
    { type: 'phone', t: 'WhatsApp',           d: 'Respuesta inmediata en horario laboral.',       a: '+34 900 000 000', color: C.green },
  ];
  let cy = 100;
  ctas.forEach((c, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, cy, cw, 28, 3, 3, 'F');
    setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(M, cy, cw, 28, 3, 3, 'S');
    // Vector icon on left
    icon(c.type, M + 12, cy + 14, c.color);
    // Title
    setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(13);
    doc.text(c.t, M + 26, cy + 12);
    // Description
    setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    doc.text(c.d, M + 26, cy + 19);
    // Contact data — own line, gray, clean
    setText(C.gray); doc.setFontSize(8);
    doc.text(c.a, M + 26, cy + 24);
    // Right-side action chip
    setFill(c.color);
    const cta = '→';
    doc.roundedRect(pageW - M - 14, cy + 9, 9, 9, 1.5, 1.5, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
    doc.text(cta, pageW - M - 9.5, cy + 15.5, { align: 'center' });
    cy += 32;
  });

  // Bottom strong message
  cy += 8;
  setFill(C.ink); doc.roundedRect(M, cy, cw, 30, 3, 3, 'F');
  setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(13);
  doc.text('La IA no reemplaza profesionales.', pageW / 2, cy + 12, { align: 'center' });
  setText(C.orange); doc.setFontSize(13);
  doc.text('Reemplaza a quienes no la usan.', pageW / 2, cy + 21, { align: 'center' });
  setText([180, 180, 200]); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
  doc.text('REFACTIKA · Aceleradora IA · Grupo Aspasia · Metodología Awakelab', pageW / 2, cy + 27, { align: 'center' });

  doc.save(`Itinerario_${academy.shortName.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
}

function AcademyOverview({ academy, region }) {
  const priceLabel = region === 'latam' ? academy.priceUsd : academy.priceEur;
  return (
    <div className="fade-up space-y-4">
      <div className="bg-white border border-ink-900/8 rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 dot-pattern opacity-40" />
        <div className="relative">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-orange-500 mb-2">Escuela recomendada</div>
              <h3 className="text-2xl font-black text-ink-900 mb-1">{academy.name}</h3>
              <div className="text-sm text-ink-500">{academy.duration} · {academy.synchronous}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-ink-500">Desde</div>
              <div className="text-xl font-black text-ink-900">{priceLabel}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 my-5">
            <div className="bg-orange-50 rounded-xl p-4">
              <div className="text-xs text-orange-600 font-bold mb-1">🎥 Sincrónico</div>
              <div className="text-sm text-ink-900">{academy.synchronous}</div>
            </div>
            <div className="bg-ink-900/5 rounded-xl p-4">
              <div className="text-xs text-ink-500 font-bold mb-1">📚 Asincrónico</div>
              <div className="text-sm text-ink-900">{academy.asynchronous}</div>
            </div>
          </div>

          <div className="bg-ink-900 rounded-xl p-4 text-white mt-4">
            <div className="text-xs uppercase tracking-wider text-orange-500 font-bold mb-1.5">Reto real</div>
            <div className="text-sm text-ink-300 leading-relaxed">{academy.challenge}</div>
          </div>
        </div>
      </div>

      {/* Modules */}
      <div className="bg-white border border-ink-900/8 rounded-2xl p-6">
        <h4 className="font-bold text-ink-900 mb-4 flex items-center gap-2">
          <span className="w-8 h-8 rounded-lg bg-ink-900 flex items-center justify-center text-orange-500 font-black text-xs">IA</span>
          Qué aprenderás
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {academy.modules.map((m, i) => (
            <div key={i} className="flex items-start gap-2.5 py-1.5">
              <span className="flex-shrink-0 w-5 h-5 rounded-md bg-orange-50 flex items-center justify-center text-orange-500 font-bold text-[10px]">{i + 1}</span>
              <span className="text-sm text-ink-800">{m}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Outcomes */}
      <div className="bg-white border border-ink-900/8 rounded-2xl p-6">
        <h4 className="font-bold text-ink-900 mb-4">Al terminar podrás…</h4>
        <div className="space-y-2.5">
          {academy.outcomes.map((o, i) => (
            <div key={i} className="flex items-start gap-3">
              <span className="flex-shrink-0 w-5 h-5 rounded-md bg-green-50 flex items-center justify-center text-green-600">✓</span>
              <span className="text-sm text-ink-800">{o}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Timeline({ academy }) {
  const milestones = [
    { month: 'Mes 1', label: 'Fundamentos IA', detail: 'Herramientas base y mindset IA-first.' },
    { month: 'Mes 2', label: 'Práctica intensiva', detail: 'Labs diarios y feedback IA.' },
    { month: 'Mes 3', label: 'Proyectos reales', detail: 'Casos de clientes y retos semanales.' },
    { month: 'Mes 4', label: 'Especialización', detail: 'Módulos avanzados y mentoría 1:1.' },
    ...(academy.durationWeeks > 18 ? [{ month: 'Mes 5', label: 'Reto real', detail: 'Proyecto final con empresa.' }] : []),
    ...(academy.durationWeeks > 22 ? [{ month: 'Mes 6', label: 'Demo Day & empleo', detail: 'Presenta al panel y entra al mercado.' }] : []),
  ];

  return (
    <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-6">
      <h4 className="font-bold text-ink-900 mb-5">Tu timeline de {academy.duration}</h4>
      <div className="relative">
        <div className="absolute left-4 top-3 bottom-3 w-0.5 bg-ink-900/10" />
        <div className="space-y-5">
          {milestones.map((m, i) => (
            <div key={i} className="flex gap-4 items-start">
              <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold z-10 ${i === 0 ? 'bg-orange-500 text-white' : 'bg-white border-2 border-ink-900/10 text-ink-900'}`}>
                {i + 1}
              </div>
              <div className="flex-1 bg-paper rounded-xl p-3.5 border border-ink-900/5">
                <div className="text-xs font-bold text-orange-500">{m.month}</div>
                <div className="font-semibold text-ink-900 mb-0.5">{m.label}</div>
                <div className="text-sm text-ink-500">{m.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Sources({ region }) {
  const data = DATA_SOURCES[region];
  return (
    <div className="fade-up space-y-4">
      <div className="bg-white border border-ink-900/8 rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center">
            <span className="text-orange-500 text-xs font-black">IA</span>
          </div>
          <h4 className="font-bold text-ink-900">Cómo sabemos todo esto</h4>
        </div>
        <p className="text-sm text-ink-500 mb-4">
          Cruzamos a diario datos de empleo, salarios y tendencias con IA. Actualización automática cada día a las 6:00 AM ({data.region}).
        </p>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 rounded-full bg-green-500 live-dot" />
          <span className="text-ink-500">Última actualización: hoy a las 6:00 AM</span>
        </div>
      </div>

      <SourceGroup title="🏛 Fuentes públicas" items={data.publicSources} />
      <SourceGroup title="🔷 Portales privados" items={data.privateSources} />
      <SourceGroup title="📊 Grandes consultoras" items={data.consultancies} />

      <div className="bg-ink-900 text-white rounded-2xl p-5 text-sm leading-relaxed relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative">
          <div className="text-xs uppercase tracking-wider text-orange-500 font-bold mb-2">Pipeline de datos</div>
          <ol className="space-y-1.5 text-ink-300">
            <li>1. Scraping diario de ofertas activas (últimas 24h)</li>
            <li>2. Extracción de habilidades con NLP + clasificación por sector</li>
            <li>3. Normalización semántica vía ESCO · O*NET · DigComp 2.2</li>
            <li>4. Cálculo de demanda, salario y tendencia con IA</li>
            <li>5. Publicación a las 6:00 AM en España y LATAM</li>
          </ol>
        </div>
      </div>
    </div>
  );
}

function SourceGroup({ title, items }) {
  return (
    <div className="bg-white border border-ink-900/8 rounded-2xl p-5">
      <div className="text-sm font-bold text-ink-900 mb-3">{title}</div>
      <div className="flex flex-wrap gap-2">
        {items.map((it, i) => (
          <div key={i} className="group relative">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-ink-900/5 hover:bg-orange-50 rounded-full text-xs text-ink-800 transition cursor-help">
              {it.name}
            </span>
            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none bg-ink-900 text-white text-[10px] px-2 py-1 rounded whitespace-nowrap z-10 transition">
              {it.desc}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// 10. CONSENT GATE — personal data + authorization before interview
// ============================================================

function ConsentGate({ onAccept, onCancel }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [consent, setConsent] = useState(false);
  const [marketing, setMarketing] = useState(false);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const canSubmit = name.trim().length >= 3 && emailValid && consent;

  function handleSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    onAccept({ name: name.trim(), email: email.trim(), phone: phone.trim(), marketing, consentedAt: new Date().toISOString() });
  }

  return (
    <div className="max-w-2xl mx-auto px-5 pt-10 pb-16">
      <button onClick={onCancel} className="text-xs text-ink-500 hover:text-orange-500 mb-4 flex items-center gap-1">
        ← Volver
      </button>

      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">ANTES DE EMPEZAR</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          Tus datos, tu decisión.
        </h2>
        <p className="text-ink-500 mb-8">
          Para arrancar la entrevista necesitamos tus datos de contacto y tu autorización. La <b className="text-ink-900">IA</b> analizará solo lo que tú decidas compartir.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="fade-up bg-white border border-ink-900/8 rounded-2xl p-6 space-y-4" style={{ animationDelay: '0.1s' }}>
        <div>
          <label className="text-sm font-bold text-ink-900 mb-1.5 block">Nombre completo <span className="text-orange-500">*</span></label>
          <input value={name} onChange={(e) => setName(e.target.value)}
            placeholder="Ej: María García López"
            className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper text-ink-900 focus:border-orange-500 transition" />
        </div>
        <div>
          <label className="text-sm font-bold text-ink-900 mb-1.5 block">Email <span className="text-orange-500">*</span></label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email"
            placeholder="maria@ejemplo.com"
            className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper text-ink-900 focus:border-orange-500 transition" />
          {email.length > 0 && !emailValid && (
            <div className="text-xs text-red-500 mt-1">Email no válido</div>
          )}
        </div>
        <div>
          <label className="text-sm font-bold text-ink-900 mb-1.5 block">Teléfono <span className="text-ink-500 font-normal">(opcional)</span></label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel"
            placeholder="+34 600 000 000"
            className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper text-ink-900 focus:border-orange-500 transition" />
        </div>

        <div className="bg-paper rounded-xl p-4 space-y-3">
          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)}
              className="mt-1 w-4 h-4 accent-orange-500 flex-shrink-0" />
            <div className="text-sm text-ink-800">
              <b>Autorizo el tratamiento de mis datos</b> por <BrandMark size="xs" className="text-ink-800" /> (Grupo Aspasia) con fines de orientación profesional y análisis con <span className="text-orange-500 font-bold">IA</span>. Puedo revocarlo cuando quiera.
              <span className="text-orange-500"> *</span>
              <div className="text-xs text-ink-500 mt-1">Base legal: consentimiento del interesado (RGPD Art. 6.1.a).</div>
            </div>
          </label>
          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={marketing} onChange={(e) => setMarketing(e.target.checked)}
              className="mt-1 w-4 h-4 accent-orange-500 flex-shrink-0" />
            <div className="text-sm text-ink-800">
              Quiero recibir informes de mercado y novedades de las escuelas de <span className="text-orange-500 font-bold">IA</span>. <span className="text-ink-500">(opcional)</span>
            </div>
          </label>
        </div>

        <div className="text-[11px] text-ink-500 leading-relaxed bg-ink-900/5 rounded-xl p-3">
          🔒 No vendemos tus datos. Solo se usan para generar tu orientación personalizada. Puedes acceder, rectificar o eliminar tus datos escribiendo a <a href="mailto:privacidad@refactika.com" className="text-orange-500">privacidad@refactika.com</a>.
        </div>

        <button type="submit" disabled={!canSubmit}
          className="w-full bg-ink-900 text-white px-6 py-3.5 rounded-xl font-semibold hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2">
          Empezar entrevista →
        </button>
      </form>
    </div>
  );
}

// ============================================================
// 11. INTRO CHAT — minimal "what do you want to do?" (sector detection)
// ============================================================

// Inference engine — returns array of matching sector IDs (supports multi-sector)
function inferSectors(text) {
  const t = text.toLowerCase();
  const hits = [];
  if (/market|community|seo|contenido|campa|publicidad|redes socia|brand|copywr/.test(t)) hits.push('marketing');
  if (/desarroll|program|code|front|back|full.?stack|app movil|web dev/.test(t)) hits.push('desarrollo');
  if (/factor[ií]a|ci\/cd|pipeline|equipo de software|tech.?lead/.test(t)) hits.push('factoria');
  if (/tecnolog[ií]a|it\b|sistemas|cloud|aws|azure|gcp|ciber|seguridad|devops|infra|sre\b|arquitect/.test(t)) hits.push('tecnologia');
  if (/proyecto|pmo|pm\b|scrum|agile|kanban|project manager|jira|sprint|roadmap/.test(t)) hits.push('proyectos');
  if (/vent|comercia|sales|bdr|sdr|account|rev.?ops|prospect/.test(t)) hits.push('ventas');
  if (/log[ií]stic|supply|cadena|almac[eé]n|transport|flota|ruta|distribuci/.test(t)) hits.push('logistica');
  if (/gesti[oó]n\b|admin|direcci[oó]n|bi\b|power.?bi|tableau|estrateg/.test(t)) hits.push('gestion');
  if (/operaci[oó]n|planta|producci[oó]n|manteni|servicios? t[eé]cnic|calidad/.test(t)) hits.push('operaciones');
  if (/rrhh|recursos humanos|talento|reclut|seleccion|people|hr\b|compensaci/.test(t)) hits.push('rrhh');
  if (/innovac|product manager|descubri|prototip|research|venture/.test(t)) hits.push('innovacion');
  if (/financ|contab|cfo|fp&a|tesorer[ií]a|riesgo financ|presupuest/.test(t)) hits.push('finanzas');
  if (/sosteni|esg|rsc|circular|carbono|medio ?ambient|climate/.test(t)) hits.push('sostenibilidad');
  return [...new Set(hits)]; // dedup
}

function IntroChat({ onComplete, userContact, onBack }) {
  const [messages, setMessages] = useState([
    { role: 'bot', text: `Hola ${userContact.name.split(' ')[0]} 👋 Cuéntame en una frase: ¿qué te gustaría hacer o dónde quieres crecer con IA?` },
  ]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [selectedSectors, setSelectedSectors] = useState([]);
  const [isListening, setIsListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [phase, setPhase] = useState('chat'); // 'chat' | 'confirm' | 'pick'
  const scrollRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isThinking]);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      setVoiceSupported(true);
      const rec = new SR();
      rec.lang = 'es-ES';
      rec.continuous = false;
      rec.interimResults = false;
      rec.onresult = (e) => {
        const transcript = Array.from(e.results).map(r => r[0].transcript).join(' ');
        setInput(prev => (prev ? prev + ' ' : '') + transcript);
        setIsListening(false);
      };
      rec.onerror = () => setIsListening(false);
      rec.onend = () => setIsListening(false);
      recognitionRef.current = rec;
    }
  }, []);

  function toggleVoice() {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try { recognitionRef.current.start(); setIsListening(true); } catch(e) {}
    }
  }

  async function handleSend() {
    if (input.trim().length < 6) return;
    const userMsg = input.trim();
    setMessages(m => [...m, { role: 'user', text: userMsg }]);
    setInput('');
    setIsThinking(true);
    await new Promise(r => setTimeout(r, 900));

    const hits = inferSectors(userMsg);
    if (hits.length > 0) {
      setSelectedSectors(hits);
      setPhase('confirm');
      const names = hits.map(id => `${SECTORS[id].icon} ${SECTORS[id].name}`).join(', ');
      setMessages(m => [...m, {
        role: 'bot',
        text: hits.length > 1
          ? `Detecto varios sectores: ${names}. Puedes quitar o añadir los que quieras. Cuando listo, dale a "Continuar".`
          : `Perfecto. Veo que te interesa ${names}. ¿Confirmas? Puedes añadir otro sector si lo ves.`,
      }]);
    } else {
      setPhase('pick');
      setMessages(m => [...m, {
        role: 'bot',
        text: 'No tengo claro aún el sector. Marca los que te interesen (puedes elegir varios):',
      }]);
    }
    setIsThinking(false);
  }

  function toggleSector(id) {
    setSelectedSectors(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  function confirmSelection() {
    if (selectedSectors.length === 0) return;
    onComplete({
      sectors: selectedSectors,
      sector: selectedSectors[0], // primary
      goalText: messages.filter(m => m.role === 'user').map(m => m.text).join(' · '),
    });
  }

  return (
    <div className="max-w-2xl mx-auto px-5 pt-10 pb-16">
      <button onClick={onBack} className="text-xs text-ink-500 hover:text-orange-500 mb-4 flex items-center gap-1">
        ← Volver
      </button>

      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">PASO 1 DE 3 · ¿QUÉ QUIERES HACER?</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          Cuéntame tu meta.
        </h2>
        <p className="text-ink-500 mb-6">
          Preguntas mínimas. La <b className="text-ink-900">IA</b> detecta tu sector de impacto y pasamos al siguiente paso.
        </p>
      </div>

      <div className="fade-up bg-white border border-ink-900/8 rounded-2xl overflow-hidden" style={{ animationDelay: '0.1s' }}>
        {/* Chat header */}
        <div className="flex items-center gap-2 p-4 border-b border-ink-900/5 bg-paper">
          <div className="w-8 h-8 rounded-lg bg-ink-900 flex items-center justify-center">
            <span className="text-orange-500 text-xs font-black">IA</span>
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-ink-900"><OrientadorMark size="sm" /></div>
            <div className="text-[10px] text-green-600 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500" /> En línea</div>
          </div>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="p-4 space-y-3 max-h-[360px] overflow-y-auto">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] px-3.5 py-2 rounded-2xl text-sm ${m.role === 'user' ? 'bg-ink-900 text-white' : 'bg-paper text-ink-900 border border-ink-900/5'}`}>
                {m.text}
              </div>
            </div>
          ))}
          {isThinking && (
            <div className="flex justify-start">
              <div className="px-3.5 py-2 rounded-2xl bg-paper border border-ink-900/5 text-ink-500 text-sm flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" style={{ animationDelay: '0.2s' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
        </div>

        {/* Sector chips selector (multi-select) */}
        {(phase === 'confirm' || phase === 'pick') && (
          <div className="p-4 border-t border-ink-900/5 bg-orange-50">
            <div className="text-xs font-bold text-ink-900 mb-2">Sectores elegidos ({selectedSectors.length})</div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {Object.values(SECTORS).map(s => {
                const on = selectedSectors.includes(s.id);
                return (
                  <button key={s.id} onClick={() => toggleSector(s.id)}
                    className={`px-2.5 py-1.5 rounded-full text-xs font-medium transition flex items-center gap-1 ${on ? 'bg-ink-900 text-white' : 'bg-white border border-ink-900/10 text-ink-800 hover:border-orange-500'}`}>
                    <span>{s.icon}</span>
                    <span>{s.name}</span>
                    {on && <span className="ml-1 text-orange-500">✓</span>}
                  </button>
                );
              })}
            </div>
            <button onClick={confirmSelection} disabled={selectedSectors.length === 0}
              className="w-full bg-orange-500 text-white px-4 py-2.5 rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-30">
              Continuar con {selectedSectors.length} sector{selectedSectors.length !== 1 ? 'es' : ''} →
            </button>
          </div>
        )}

        {/* Input */}
        {phase === 'chat' && (
          <div className="p-3 border-t border-ink-900/5 flex items-center gap-2">
            {voiceSupported && (
              <button onClick={toggleVoice}
                className={`w-10 h-10 flex-shrink-0 rounded-xl flex items-center justify-center transition ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-ink-900/5 text-ink-500 hover:bg-ink-900/10'}`}
                title={isListening ? 'Detener' : 'Hablar'}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" fill="currentColor"/><path d="M19 10v2a7 7 0 11-14 0v-2M12 19v4m-4 0h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
              </button>
            )}
            <input value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={isListening ? 'Escuchando…' : 'Escribe o habla tu meta…'}
              className="flex-1 px-3 py-2.5 bg-paper rounded-xl text-sm text-ink-900 focus:outline-none" />
            <button onClick={handleSend} disabled={input.trim().length < 6}
              className="bg-orange-500 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-orange-600 transition disabled:opacity-30">
              Enviar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// 12. PROFILE — what you do (CV / LinkedIn / Your story)
// ============================================================

function Profile({ onComplete, onBack, sector }) {
  const [mode, setMode] = useState('story');
  const [story, setStory] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [cvFile, setCvFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [level, setLevel] = useState('');
  const fileInputRef = useRef(null);
  const LEVELS = [
    { id: 'inicial', label: 'Empiezo con IA', desc: 'Quiero saber por dónde arrancar.', icon: '🌱' },
    { id: 'aplicada', label: 'Uso IA en mi día a día', desc: 'Conozco las herramientas pero quiero profundizar.', icon: '⚡' },
    { id: 'experto', label: 'Lidero proyectos con IA', desc: 'Quiero especializarme o liderar transformación.', icon: '🚀' },
  ];

  const tabs = [
    { id: 'story', label: 'Tu historia', icon: '✍️' },
    { id: 'linkedin', label: 'LinkedIn', icon: '🔗' },
    { id: 'cv', label: 'CV (PDF)', icon: '📄' },
  ];

  async function handleSubmit() {
    setIsProcessing(true);
    let extracted = '';
    if (mode === 'story') extracted = story;
    if (mode === 'linkedin') extracted = `LinkedIn: ${linkedinUrl}`;
    if (mode === 'cv' && cvFile) {
      try {
        if (window.pdfjsLib && cvFile.type === 'application/pdf') {
          const buf = await cvFile.arrayBuffer();
          pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
          const pdf = await pdfjsLib.getDocument(new Uint8Array(buf)).promise;
          for (let i = 1; i <= Math.min(pdf.numPages, 5); i++) {
            const page = await pdf.getPage(i);
            const c = await page.getTextContent();
            extracted += c.items.map(it => it.str).join(' ') + ' ';
          }
        }
      } catch (e) {
        alert('Error leyendo PDF. Intenta con Tu historia.');
        setIsProcessing(false);
        return;
      }
    }
    await new Promise(r => setTimeout(r, 900));
    setIsProcessing(false);
    onComplete({ profileSource: mode, profileData: extracted.slice(0, 2000), level });
  }

  const canSubmit = level && (
    (mode === 'story' && story.trim().length >= 20) ||
    (mode === 'linkedin' && linkedinUrl.includes('linkedin.com')) ||
    (mode === 'cv' && cvFile)
  );

  return (
    <div className="max-w-2xl mx-auto px-5 pt-10 pb-16">
      <button onClick={onBack} className="text-xs text-ink-500 hover:text-orange-500 mb-4 flex items-center gap-1">
        ← Volver
      </button>

      <div className="fade-up">
        <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">PASO 2 DE 3 · ¿QUÉ HACES?</div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          Cuéntame qué haces hoy.
        </h2>
        <p className="text-ink-500 mb-6">
          Elige cómo compartes tu experiencia. Cuanto más específico, mejor será tu plan de <span className="text-orange-500 font-bold">IA</span>.
        </p>
      </div>

      <div className="fade-up flex gap-1 bg-ink-900/5 p-1 rounded-xl mb-6" style={{ animationDelay: '0.1s' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setMode(t.id)}
            className={`flex-1 px-3 py-2.5 rounded-lg text-sm font-medium transition flex items-center justify-center gap-2 ${mode === t.id ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-800'}`}>
            <span>{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.2s' }}>
        {mode === 'story' && (
          <>
            <label className="text-sm font-bold text-ink-900 mb-2 block">Tu experiencia en una historia breve</label>
            <textarea value={story} onChange={(e) => setStory(e.target.value)}
              placeholder="Ej: Trabajo hace 5 años en marketing en una agencia. He llevado campañas de Meta Ads y Google Ads. Sé un poco de SEO y de contenidos, pero nunca he usado IA generativa en serio…"
              className="w-full min-h-[160px] p-4 border border-ink-900/10 rounded-xl bg-paper text-ink-900 resize-none focus:border-orange-500 transition" />
            <div className="text-xs text-ink-500 mt-2">{story.length} caracteres · menciona herramientas, cargos y años.</div>
          </>
        )}
        {mode === 'linkedin' && (
          <>
            <label className="text-sm font-bold text-ink-900 mb-2 block">URL de tu perfil de LinkedIn</label>
            <input value={linkedinUrl} onChange={(e) => setLinkedinUrl(e.target.value)} type="url"
              placeholder="https://www.linkedin.com/in/tu-perfil"
              className="w-full p-4 border border-ink-900/10 rounded-xl bg-paper text-ink-900 focus:border-orange-500 transition" />
            <div className="text-xs text-ink-500 mt-2">Leeremos tu perfil público. Nada se guarda.</div>
          </>
        )}
        {mode === 'cv' && (
          <>
            <label className="text-sm font-bold text-ink-900 mb-2 block">Sube tu CV en PDF</label>
            <div onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-ink-900/15 rounded-xl p-8 text-center cursor-pointer hover:border-orange-500 transition">
              <div className="text-3xl mb-2">📄</div>
              <div className="font-medium text-ink-900">{cvFile ? cvFile.name : 'Haz clic para subir tu CV'}</div>
              <div className="text-xs text-ink-500 mt-1">PDF · máx 5MB</div>
            </div>
            <input ref={fileInputRef} type="file" accept="application/pdf"
              onChange={(e) => setCvFile(e.target.files[0])} className="hidden" />
          </>
        )}

      </div>

      {/* Level detection */}
      <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5 mt-4" style={{ animationDelay: '0.25s' }}>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center">
            <span className="text-orange-500 text-xs font-black">IA</span>
          </div>
          <h4 className="text-sm font-bold text-ink-900">¿Dónde estás hoy con la IA?</h4>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {LEVELS.map(l => (
            <button key={l.id} onClick={() => setLevel(l.id)}
              className={`text-left p-3 rounded-xl border transition ${level === l.id ? 'border-orange-500 bg-orange-50' : 'border-ink-900/10 hover:border-orange-500/50'}`}>
              <div className="text-xl mb-1">{l.icon}</div>
              <div className="text-sm font-bold text-ink-900">{l.label}</div>
              <div className="text-xs text-ink-500">{l.desc}</div>
            </button>
          ))}
        </div>
      </div>

      <button onClick={handleSubmit} disabled={!canSubmit || isProcessing}
        className="mt-5 w-full bg-ink-900 text-white px-5 py-3 rounded-xl font-semibold hover:bg-ink-800 transition disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2">
        {isProcessing ? <>Analizando con IA…<span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /></> : <>Generar mi itinerario →</>}
      </button>
    </div>
  );
}

// ============================================================
// 13. MARKET INTELLIGENCE — global trends by sector (open)
// ============================================================

function MarketIntel({ onBack, region }) {
  const [activeSector, setActiveSector] = useState('desarrollo');
  const s = SECTORS[activeSector];
  const g = s.global;
  const m = getMarketData(region, activeSector);
  const regionData = DATA_SOURCES[region];
  const regionalCities = (REGIONAL_HUBS[region] || {})[activeSector] || [];
  const regionalCompanies = (REGIONAL_COMPANIES[region] || {})[activeSector] || g.topHiring || [];
  const currency = region === 'latam' ? 'USD' : '€';
  const aiPct = m ? Math.round((m.aiOffers / m.offers) * 100) : g.aiPenetration;
  const salaryBoost = Math.round((s.impactScore - 50) * 0.6);

  return (
    <div className="max-w-6xl mx-auto px-5 pt-10 pb-20">
      <div className="fade-up">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs text-orange-500 font-bold tracking-wide">INTELIGENCIA DE MERCADO</span>
          <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500" /> Actualizado hoy
          </span>
        </div>
        <h2 className="text-3xl md:text-4xl font-black text-ink-900 mb-3 leading-tight">
          Formarse en <span className="text-orange-500">IA</span> hoy es una obligación, no una opción.
        </h2>
        <p className="text-ink-500 mb-3 max-w-3xl">
          Mira cómo la <b className="text-ink-900">IA</b> está transformando tu sector en <b className="text-ink-900">{regionData.region}</b>. Datos en lenguaje simple — sin jerga, sin humo. Empleo real, salarios y empresas que están contratando hoy.
        </p>
      </div>

      {/* McKinsey-style quick intro */}
      <div className="fade-up mb-6 grid grid-cols-1 md:grid-cols-2 gap-3" style={{ animationDelay: '0.05s' }}>
        {MCKINSEY_THEMES.slice(0, 2).map((mck, i) => (
          <div key={i} className="bg-white border border-ink-900/8 rounded-2xl p-4">
            <div className="text-xs font-bold text-orange-500 mb-1">LO QUE DICE EL MERCADO · McKinsey 2026</div>
            <div className="font-bold text-ink-900 text-sm">{mck.t}</div>
            <div className="text-xs text-ink-500 mt-1">{mck.d}</div>
          </div>
        ))}
      </div>

      {/* Sector tabs */}
      <div className="fade-up flex gap-2 mb-6 overflow-x-auto pb-2" style={{ animationDelay: '0.1s' }}>
        {Object.values(SECTORS).map(sec => (
          <button key={sec.id} onClick={() => setActiveSector(sec.id)}
            className={`flex-shrink-0 px-4 py-2.5 rounded-xl text-sm font-semibold transition flex items-center gap-2 ${activeSector === sec.id ? 'bg-ink-900 text-white' : 'bg-white border border-ink-900/10 text-ink-800 hover:border-orange-500'}`}>
            <span>{sec.icon}</span>
            <span>{sec.name}</span>
          </button>
        ))}
      </div>

      {/* Hero metrics — regional · B2C friendly */}
      <div className="fade-up grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6" style={{ animationDelay: '0.2s' }}>
        <ExplainCard
          icon="💼"
          big={m ? m.offers.toLocaleString('es-ES') : '—'}
          title="Ofertas activas hoy"
          plain={`Trabajos abiertos para ${s.name.toLowerCase()} en ${regionData.region} en este momento.`}
          accent
        />
        <ExplainCard
          icon="🤖"
          big={`${aiPct}%`}
          title="Piden saber de IA"
          plain={`De cada 100 ofertas, ${aiPct} mencionan habilidades de IA. Las demás también lo necesitarán pronto.`}
          warning={aiPct >= 40 ? 'Sin IA estás compitiendo solo por la mitad de las ofertas.' : null}
        />
        <ExplainCard
          icon="💰"
          big={`${m ? (m.avgSalary/1000).toFixed(0) : '—'}K ${currency}`}
          title="Salario medio"
          plain={`Salario bruto anual típico para ${s.name.toLowerCase()} en ${regionData.region}.`}
        />
        <ExplainCard
          icon="⚡"
          big={`+${salaryBoost}%`}
          title="Ganan los que saben IA"
          plain={`Los perfiles con IA ganan en promedio ${salaryBoost}% más que el resto del sector.`}
          accent
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {/* Regional cities */}
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.4s' }}>
          <h3 className="font-bold text-ink-900 mb-1">{regionData.flag} Dónde hay más trabajo en {regionData.region}</h3>
          <div className="text-xs text-ink-500 mb-4">Ciudades con más ofertas activas para {s.name.toLowerCase()}. La barra muestra el peso relativo.</div>
          <div className="space-y-2.5">
            {regionalCities.map(([city, weight, flag], i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="text-xs text-ink-500 w-4">{i + 1}</div>
                {flag && <div className="text-base">{flag}</div>}
                <div className="text-sm font-medium text-ink-900 w-28 truncate">{city}</div>
                <div className="flex-1 bg-ink-900/5 rounded-full h-1.5 overflow-hidden">
                  <div className="h-full bg-orange-500 rounded-full" style={{ width: `${weight}%` }} />
                </div>
                <div className="text-xs text-ink-500 w-7 text-right tabular-nums">{weight}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hot skills */}
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.5s' }}>
          <h3 className="font-bold text-ink-900 mb-1">Lo que piden las ofertas</h3>
          <div className="text-xs text-ink-500 mb-4">De cada 100 ofertas activas, qué porcentaje pide cada habilidad.</div>
          <div className="space-y-2.5">
            {g.hotSkills.map((sk, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="text-xs text-ink-500 w-4">{i + 1}</div>
                <div className="flex-1 text-sm text-ink-900 truncate">{sk.skill}</div>
                <div className="w-20 bg-ink-900/5 rounded-full h-1.5 overflow-hidden">
                  <div className="h-full bg-orange-500 rounded-full" style={{ width: `${sk.demand}%` }} />
                </div>
                <div className="text-xs text-orange-500 font-bold w-9 text-right tabular-nums">{sk.demand}%</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Regional companies + trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <div className="fade-up bg-white border border-ink-900/8 rounded-2xl p-5" style={{ animationDelay: '0.6s' }}>
          <h3 className="font-bold text-ink-900 mb-1">Empresas que contratan en {regionData.region}</h3>
          <div className="text-xs text-ink-500 mb-3">Compañías que buscan profesionales con IA en este sector.</div>
          <div className="flex flex-wrap gap-2">
            {regionalCompanies.map((c, i) => (
              <span key={i} className="px-3 py-1.5 bg-ink-900/5 rounded-full text-sm text-ink-900 font-medium">{c}</span>
            ))}
          </div>
        </div>
        <div className="fade-up bg-orange-50 border border-orange-100 rounded-2xl p-5" style={{ animationDelay: '0.7s' }}>
          <h3 className="font-bold text-ink-900 mb-1">Lo que más está creciendo</h3>
          <div className="text-xs text-ink-500 mb-3">Tendencias que se disparan en este sector. Fórmate aquí y vas por delante.</div>
          <div className="space-y-2">
            {s.trends.map((t, i) => (
              <div key={i} className="flex items-center justify-between bg-white rounded-xl px-3 py-2">
                <span className="text-sm text-ink-900">{t.k}</span>
                <span className="text-sm font-black text-orange-500">{t.v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sources footer · regional + global, focused */}
      <div className="fade-up bg-ink-900 rounded-2xl p-5 text-white relative overflow-hidden" style={{ animationDelay: '0.9s' }}>
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative">
          <div className="text-xs uppercase tracking-wider text-orange-500 font-bold mb-3">De dónde vienen estos datos</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[...regionData.privateSources.slice(0, 3), ...regionData.publicSources.slice(0, 2), ...GLOBAL_SOURCES.slice(0, 3)].map((src, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                <div className="text-xs font-bold text-white">{src.name}</div>
                <div className="text-[10px] text-ink-300 mt-0.5">{src.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA to interview */}
      <div className="fade-up mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border-2 border-orange-500 rounded-2xl p-5" style={{ animationDelay: '1s' }}>
        <div>
          <div className="font-bold text-ink-900">¿Quieres un plan personal en este sector?</div>
          <div className="text-sm text-ink-500 mt-0.5">Haz la entrevista y te damos tu camino en <span className="text-orange-500 font-bold">IA</span> aplicada a {s.name.toLowerCase()}.</div>
        </div>
        <button onClick={onBack}
          className="bg-ink-900 text-white px-6 py-3 rounded-xl font-semibold hover:bg-ink-800 transition lift flex items-center gap-2 whitespace-nowrap">
          Hacer la entrevista →
        </button>
      </div>
    </div>
  );
}

function RegionalSnapshot({ sector, region }) {
  const m = getMarketData(region, sector);
  const currency = region === 'latam' ? 'USD' : '€';
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      <div className="bg-paper rounded-xl p-3">
        <div className="text-xs text-ink-500">Ofertas activas</div>
        <div className="text-xl font-black text-ink-900">{m.offers.toLocaleString('es-ES')}</div>
      </div>
      <div className="bg-orange-50 rounded-xl p-3">
        <div className="text-xs text-ink-500">Ofertas con IA</div>
        <div className="text-xl font-black text-orange-600">{m.aiOffers.toLocaleString('es-ES')}</div>
      </div>
      <div className="bg-paper rounded-xl p-3">
        <div className="text-xs text-ink-500">Salario medio</div>
        <div className="text-xl font-black text-ink-900">{(m.avgSalary/1000).toFixed(0)}K {currency}</div>
      </div>
      <div className="bg-orange-50 rounded-xl p-3">
        <div className="text-xs text-ink-500">Crecimiento YoY</div>
        <div className="text-xl font-black text-orange-600">+{m.growth}%</div>
      </div>
    </div>
  );
}

// ============================================================
// 14. MAIN APP
// ============================================================

// ============================================================
// ADMIN PANEL — superadmin/admin · offerings · users · comms
// ============================================================

function AdminPanel({ onExit }) {
  const [user, setUser] = useState(adminStore.currentUser());
  const [tab, setTab] = useState('leads');

  if (!user) return <AdminLogin onLogin={(u) => setUser(u)} onExit={onExit} />;

  return (
    <div className="max-w-6xl mx-auto px-5 pt-10 pb-20">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="text-xs text-orange-500 font-bold tracking-wide">PANEL DE ADMINISTRACIÓN</div>
          <h2 className="text-2xl font-black text-ink-900">Hola, {user.name}</h2>
          <div className="text-xs text-ink-500">Rol: <b>{user.role === 'superadmin' ? 'Superadmin' : 'Admin'}</b> · {user.email}</div>
        </div>
        <button onClick={() => { adminStore.logout(); setUser(null); }} className="text-xs text-ink-500 hover:text-orange-500">Cerrar sesión</button>
      </div>

      <div className="flex gap-1 bg-ink-900/5 p-1 rounded-xl mb-6 overflow-x-auto">
        {[
          { id: 'leads', label: '👤 Usuarios' },
          { id: 'offerings', label: '🎓 Ofertas formativas' },
          ...(user.role === 'superadmin' ? [{ id: 'admins', label: '🔐 Admins' }] : []),
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex-1 min-w-[140px] px-3 py-2 rounded-lg text-sm font-medium transition ${tab === t.id ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'leads' && <AdminLeads />}
      {tab === 'offerings' && <AdminOfferings />}
      {tab === 'admins' && user.role === 'superadmin' && <AdminManage />}
    </div>
  );
}

function AdminLogin({ onLogin, onExit }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    const u = adminStore.login(email, password);
    if (u) onLogin(u);
    else setErr('Credenciales incorrectas.');
  }

  return (
    <div className="max-w-md mx-auto px-5 pt-10 pb-16">
      <button onClick={onExit} className="text-xs text-ink-500 hover:text-orange-500 mb-4 flex items-center gap-1">← Volver</button>
      <div className="text-xs text-orange-500 font-bold mb-2 tracking-wide">ADMIN</div>
      <h2 className="text-3xl font-black text-ink-900 mb-4">Acceso panel</h2>
      <form onSubmit={handleSubmit} className="bg-white border border-ink-900/8 rounded-2xl p-5 space-y-3">
        <div>
          <label className="text-xs font-bold text-ink-900">Email</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required
            className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
        </div>
        <div>
          <label className="text-xs font-bold text-ink-900">Contraseña</label>
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required
            className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
        </div>
        {err && <div className="text-xs text-red-500">{err}</div>}
        <button type="submit" className="w-full bg-ink-900 text-white py-3 rounded-xl font-semibold hover:bg-ink-800 transition">Entrar</button>
        <div className="text-[11px] text-ink-500 pt-2 border-t border-ink-900/5">
          <b>Superadmin demo:</b> superadmin@refactika.com / refactika2026
        </div>
      </form>
    </div>
  );
}

function AdminLeads() {
  const [state, setState] = useState(adminStore.getState());
  const leads = state.leads || [];

  function refresh() { setState(adminStore.getState()); }

  if (leads.length === 0) {
    return (
      <div className="bg-white border border-ink-900/8 rounded-2xl p-8 text-center">
        <div className="text-3xl mb-2">👤</div>
        <div className="font-bold text-ink-900">No hay usuarios todavía</div>
        <div className="text-sm text-ink-500 mt-1">Aparecerán aquí las personas que completen la entrevista.</div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="text-xs text-ink-500 mb-2">{leads.length} usuarios con consentimiento</div>
      {leads.slice().reverse().map(l => (
        <div key={l.id} className="bg-white border border-ink-900/8 rounded-2xl p-4 flex flex-col sm:flex-row gap-4 items-start">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <div className="font-bold text-ink-900">{l.name}</div>
              <span className="text-[10px] bg-ink-900/5 px-2 py-0.5 rounded-full text-ink-500">
                {new Date(l.createdAt).toLocaleDateString('es-ES')}
              </span>
            </div>
            <div className="text-xs text-ink-500">{l.email} · {l.phone || 'sin teléfono'}</div>
            <div className="flex flex-wrap gap-1 mt-2">
              {(l.sectors || []).map(sid => SECTORS[sid] ? (
                <span key={sid} className="text-[10px] bg-orange-50 text-orange-600 px-2 py-0.5 rounded-full">
                  {SECTORS[sid].icon} {SECTORS[sid].name}
                </span>
              ) : null)}
              {l.level && <span className="text-[10px] bg-ink-900/5 px-2 py-0.5 rounded-full text-ink-700">Nivel: {l.level}</span>}
              {l.marketing && <span className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full">✓ acepta marketing</span>}
            </div>
            {l.goal && <div className="text-xs text-ink-500 italic mt-2 line-clamp-2">"{l.goal}"</div>}
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <a href={`mailto:${l.email}?subject=Tu itinerario en REFACTIKA&body=Hola ${l.name},%0A%0AGracias por hacer tu orientación con nosotros.`}
              className="bg-ink-900 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-ink-800 transition">📧 Email</a>
            {l.phone && (
              <a href={`https://wa.me/${l.phone.replace(/\D/g, '')}?text=Hola ${l.name}, te escribo de REFACTIKA sobre tu orientación con IA.`}
                target="_blank" rel="noopener"
                className="bg-green-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-green-600 transition">📱 WA</a>
            )}
          </div>
        </div>
      ))}
      <button onClick={refresh} className="text-xs text-ink-500 hover:text-orange-500 mt-4">↻ Refrescar</button>
    </div>
  );
}

// CSV/Excel export — full training detail (incl. troncal 120h + gym pass)
function exportTrainingExcel() {
  const rows = [];
  // Header
  rows.push([
    'Aceleradora', 'Vertical IA School', 'Habilidad', 'Microcredencial',
    'Complejidad', 'Semanas', 'Pase sincrónico (gimnasio)', 'Horas habilidad', 'Horas troncal', 'Horas totales programa',
    'Modalidad sincrónica', 'Modalidad asincrónica',
    'Precio EUR', 'Precio USD',
    'Reto general', 'Outcomes', 'Formatos sincrónicos disponibles',
  ]);
  // Troncal row (1 fila explicativa)
  rows.push([
    'TRONCAL COMÚN · IA Studio', 'Aplica a las 13 verticales', '5 bloques transversales', 'No genera microcredencial individual',
    'Común', 'Inicio del programa', 'Pase del programa', 120, 120, 'Variable según habilidad +',
    'Acceso al gimnasio sincrónico', 'Recursos asíncronos · SCORM · vídeos',
    'Incluido', 'Incluido',
    'Demostrar mindset IA-first sobre 5 bloques (24h c/u)',
    'Resolver el 75 % de los retos con al menos 2 colaborativos',
    SYNC_FORMATS.map(f => f.name).join(' · '),
  ]);
  // Skills rows
  Object.keys(ACADEMIES).forEach(id => {
    const a = getEffectiveAcademy(id);
    const skills = ACADEMY_SKILLS[id] || [];
    skills.forEach(sk => {
      const skHours = hoursForSkill(sk);
      const totalProgram = TRONCAL.hours + skHours;
      rows.push([
        a.name, a.shortName, sk.title.replace(/\n/g, ' '), `Refactika · ${sk.title.replace(/\n/g, ' ')}`,
        sk.complexity, sk.complexity === 'alta' ? 22 : 14, syncPassForSkill(sk), skHours, TRONCAL.hours, totalProgram,
        a.synchronous, a.asynchronous,
        sk.complexity === 'alta' ? '1.890' : '1.690', sk.complexity === 'alta' ? '2.090' : '1.890',
        a.challenge, (a.outcomes || []).join(' · '),
        SYNC_FORMATS.map(f => f.name).join(' · '),
      ]);
    });
  });
  const csv = rows.map(r => r.map(cell => {
    const s = String(cell ?? '').replace(/"/g, '""');
    return /[",;\n]/.test(s) ? `"${s}"` : s;
  }).join(';')).join('\n');
  // BOM for Excel UTF-8
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `IAschool_oferta_formativa_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// Methodology document — explains ABR, troncal, retos, evaluation, recognition
function generateMethodologyPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageW = 210, pageH = 297, M = 18;
  const cw = pageW - M * 2;
  const C = {
    paper: [253, 251, 248], ink: [16, 23, 41], inkSoft: [60, 70, 95],
    gray: [120, 125, 145], border: [226, 226, 232],
    orange: [255, 106, 0], orangeSoft: [255, 240, 225],
  };
  const setFill = c => doc.setFillColor(c[0], c[1], c[2]);
  const setText = c => doc.setTextColor(c[0], c[1], c[2]);
  const setDraw = c => doc.setDrawColor(c[0], c[1], c[2]);

  function chrome(eyebrow) {
    setFill(C.paper); doc.rect(0, 0, pageW, pageH, 'F');
    setFill(C.ink); doc.rect(0, 0, pageW, 14, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.text('IA SCHOOL', M, 9);
    setText(C.orange); doc.text(' · ' + ABR_MODEL.parent, M + doc.getTextWidth('IA SCHOOL'), 9);
    setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(7);
    doc.text(eyebrow.toUpperCase(), pageW - M, 9, { align: 'right' });
    setFill(C.orange); doc.rect(0, 14, pageW, 0.6, 'F');
    setText(C.gray); doc.setFont('helvetica', 'normal'); doc.setFontSize(7);
    doc.text('refactika.com · Modelo pedagógico IA School · 2026', M, pageH - 9);
  }

  // PAGE 1 — Cover
  chrome('Modelo pedagógico');
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('MODELO PEDAGÓGICO · IA SCHOOL', M, 30);
  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(36);
  doc.text('IA School', M, 60);
  setText(C.orange); doc.text('· ABR.', M + doc.getTextWidth('IA School '), 60);
  setText(C.ink); doc.setFontSize(20);
  doc.text('Aprendizaje Basado en Retos', M, 75);

  setFill(C.orange); doc.rect(M, 86, 30, 1.2, 'F');
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  doc.text(doc.splitTextToSize('Cómo aprenden las personas en cualquier vertical de IA School: troncal común, retos individuales y colaborativos, recursos de apoyo y un modelo de evaluación que combina cantidad, calidad y proyecto final.', cw), M, 96);

  // 4 stat cards (overview)
  const sy = 130;
  const stats = [
    { l: 'Vertical', v: 'IA School' },
    { l: 'Metodología', v: 'ABR' },
    { l: 'Troncal', v: '5 módulos' },
    { l: 'Reconocimiento', v: 'Microcredenciales' },
  ];
  const sw = (cw - 9) / 4;
  stats.forEach((st, i) => {
    const x = M + i * (sw + 3);
    setFill([255, 255, 255]); doc.roundedRect(x, sy, sw, 22, 2, 2, 'F');
    setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(x, sy, sw, 22, 2, 2, 'S');
    setText(C.gray); doc.setFontSize(7); doc.setFont('helvetica', 'bold');
    doc.text(st.l.toUpperCase(), x + 4, sy + 7);
    setText(C.ink); doc.setFontSize(11); doc.text(st.v, x + 4, sy + 16);
  });

  // Quote box
  setFill(C.ink); doc.roundedRect(M, 165, cw, 32, 3, 3, 'F');
  setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(13);
  doc.text('Cada IA School es una vertical de la Aceleradora.', M + 8, 178);
  setText(C.orange); doc.setFontSize(10); doc.setFont('helvetica', 'normal');
  doc.text('Marketing · Desarrollo · Ventas · Logística · Operaciones · RRHH · Finanzas · Tecnología · Proyectos · Innovación · Sostenibilidad · Gestión · Factoría', M + 8, 188);

  // PAGE 2 — Troncal
  doc.addPage();
  chrome('Troncal · IA Studio');

  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('TRONCAL COMÚN · 120 H', M, 30);
  setText(C.ink); doc.setFontSize(26);
  doc.text(ABR_MODEL.trunk.name.split(' · ')[0], M, 46);
  setText(C.orange); doc.text(' · ' + ABR_MODEL.trunk.name.split(' · ')[1], M + doc.getTextWidth(ABR_MODEL.trunk.name.split(' · ')[0]), 46);

  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  doc.text(doc.splitTextToSize(ABR_MODEL.trunk.purpose, cw), M, 58);

  // Hours pill
  setFill(C.orange); doc.roundedRect(M, 70, 28, 7, 1.5, 1.5, 'F');
  setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('120 HORAS', M + 14, 75, { align: 'center' });
  setFill(C.ink); doc.roundedRect(M + 30, 70, 32, 7, 1.5, 1.5, 'F');
  setText(C.orange); doc.text('5 BLOQUES × 24 H', M + 46, 75, { align: 'center' });

  let y = 84;
  TRONCAL.modules.forEach((m, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, y, cw, 18, 2.5, 2.5, 'F');
    setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(M, y, cw, 18, 2.5, 2.5, 'S');
    setFill(C.orange); doc.roundedRect(M + 4, y + 5, 8, 8, 1.4, 1.4, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(7);
    doc.text(String(i + 1).padStart(2, '0'), M + 8, y + 10.2, { align: 'center' });
    setText(C.ink); doc.setFontSize(10);
    doc.text(m.name, M + 18, y + 7.5);
    setText(C.inkSoft); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
    doc.text(doc.splitTextToSize(m.desc, cw - 40), M + 18, y + 13);
    // Hours pill on right
    setFill(C.orangeSoft); doc.roundedRect(pageW - M - 18, y + 5, 13, 6, 1.5, 1.5, 'F');
    setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(7);
    doc.text(`${m.hours} h`, pageW - M - 11.5, y + 9, { align: 'center' });
    y += 21;
  });

  // 2 dispositivos
  y += 4;
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('2 DISPOSITIVOS DE APRENDIZAJE INDEPENDIENTES', M, y); y += 8;
  ABR_MODEL.trunk.devices.forEach((d, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, y, cw, 22, 2.5, 2.5, 'F');
    setDraw(C.border); doc.roundedRect(M, y, cw, 22, 2.5, 2.5, 'S');
    setFill(C.ink); doc.roundedRect(M + 4, y + 6, 10, 10, 1.5, 1.5, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.text(d.id === 'ind' ? '1×' : '3-5', M + 9, y + 12.5, { align: 'center' });
    setText(C.ink); doc.setFontSize(11);
    doc.text(d.name, M + 18, y + 9);
    setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    doc.text(d.desc, M + 18, y + 16);
    y += 25;
  });

  // Pass criteria callout
  y += 4;
  setFill(C.orangeSoft); doc.roundedRect(M, y, cw, 22, 3, 3, 'F');
  setFill(C.orange); doc.rect(M, y, 2.5, 22, 'F');
  setText(C.orange); doc.setFontSize(8); doc.setFont('helvetica', 'bold');
  doc.text('CRITERIO DE SUPERACIÓN DEL TRONCAL', M + 7, y + 7);
  setText(C.ink); doc.setFontSize(10); doc.setFont('helvetica', 'normal');
  doc.text(doc.splitTextToSize(ABR_MODEL.trunk.passCriteria, cw - 14), M + 7, y + 14);

  // PAGE 3 — Verticals + Resources + Evaluation
  doc.addPage();
  chrome('Verticales · Recursos · Evaluación');

  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('TRAS EL TRONCAL', M, 30);
  setText(C.ink); doc.setFontSize(22);
  doc.text('Retos específicos por vertical', M, 44);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
  doc.text(doc.splitTextToSize(ABR_MODEL.vertical.desc, cw), M, 54);

  // Verticals grid
  let yy = 66;
  const acads = Object.values(ACADEMIES);
  acads.forEach((a, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = M + col * (cw / 2 + 2);
    const yRow = yy + row * 14;
    if (yRow + 14 > pageH - 80) return;
    setFill([255, 255, 255]); doc.roundedRect(x, yRow, cw / 2 - 2, 11, 1.5, 1.5, 'F');
    setDraw(C.border); doc.roundedRect(x, yRow, cw / 2 - 2, 11, 1.5, 1.5, 'S');
    setFill(C.orange); doc.circle(x + 4, yRow + 5.5, 1.5, 'F');
    setText(C.ink); doc.setFontSize(8); doc.setFont('helvetica', 'bold');
    doc.text(a.shortName, x + 8, yRow + 7);
  });
  const rows = Math.ceil(acads.length / 2);
  yy += rows * 14 + 4;

  // Resources
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('RECURSOS DE APOYO', M, yy + 6); yy += 12;
  ABR_MODEL.resources.forEach((r, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, yy, cw, 9, 1.5, 1.5, 'F');
    setDraw(C.border); doc.roundedRect(M, yy, cw, 9, 1.5, 1.5, 'S');
    setFill(C.orange); doc.circle(M + 5, yy + 4.5, 1.4, 'F');
    setText(C.ink); doc.setFontSize(9); doc.setFont('helvetica', 'normal');
    doc.text(r, M + 10, yy + 5.8);
    yy += 11;
  });

  // Evaluation model
  yy += 6;
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('MODELO DE EVALUACIÓN', M, yy); yy += 6;
  ABR_MODEL.evaluation.forEach(ev => {
    setFill([255, 255, 255]); doc.roundedRect(M, yy, cw, 16, 2, 2, 'F');
    setDraw(C.border); doc.roundedRect(M, yy, cw, 16, 2, 2, 'S');
    setFill(C.ink); doc.roundedRect(M + 4, yy + 3, 18, 10, 1.5, 1.5, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text(ev.w, M + 13, yy + 9.5, { align: 'center' });
    setText(C.ink); doc.setFontSize(10); doc.text(ev.f, M + 26, yy + 7);
    setText(C.inkSoft); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
    doc.text(ev.d, M + 26, yy + 12);
    yy += 18;
  });

  // PAGE 4 — Gimnasio sincrónico + 3 formatos
  doc.addPage();
  chrome('Gimnasio sincrónico');
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('GIMNASIO SINCRÓNICO · MODALIDAD ABIERTA', M, 30);
  setText(C.ink); doc.setFontSize(26);
  doc.text('Sesiones en vivo', M, 46);
  setText(C.orange); doc.text('por suscripción', M, 60);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  const gymIntro = 'Cada semana hay múltiples sesiones sincrónicas en vivo. Funcionan en modalidad gimnasio: las personas reservan las sesiones que quieren del catálogo, hasta el máximo de su pase (5 o 10 sesiones según el programa contratado).';
  doc.text(doc.splitTextToSize(gymIntro, cw), M, 72);

  // Sync passes
  let py = 92;
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('PASE SINCRÓNICO POR PROGRAMA', M, py); py += 7;
  // Two pass cards side-by-side
  const halfW = (cw - 4) / 2;
  setFill([255, 255, 255]); doc.roundedRect(M, py, halfW, 26, 3, 3, 'F');
  setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(M, py, halfW, 26, 3, 3, 'S');
  setFill(C.orange); doc.roundedRect(M + 5, py + 5, 16, 16, 2, 2, 'F');
  setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
  doc.text('5×', M + 13, py + 15, { align: 'center' });
  setText(C.ink); doc.setFontSize(11);
  doc.text('Pase Esencial', M + 25, py + 11);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
  doc.text('Programa medio · 14 semanas', M + 25, py + 17);
  doc.text('5 reservas en el gimnasio', M + 25, py + 22);

  setFill([255, 255, 255]); doc.roundedRect(M + halfW + 4, py, halfW, 26, 3, 3, 'F');
  setDraw(C.border); doc.roundedRect(M + halfW + 4, py, halfW, 26, 3, 3, 'S');
  setFill(C.ink); doc.roundedRect(M + halfW + 9, py + 5, 16, 16, 2, 2, 'F');
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
  doc.text('10×', M + halfW + 17, py + 15, { align: 'center' });
  setText(C.ink); doc.setFontSize(11);
  doc.text('Pase Avanzado', M + halfW + 29, py + 11);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
  doc.text('Programa alto · 22 semanas', M + halfW + 29, py + 17);
  doc.text('10 reservas en el gimnasio', M + halfW + 29, py + 22);
  py += 32;

  // 3 sync formats
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('3 FORMATOS DE SESIÓN SINCRÓNICA', M, py); py += 6;
  SYNC_FORMATS.forEach((f, i) => {
    setFill([255, 255, 255]); doc.roundedRect(M, py, cw, 28, 3, 3, 'F');
    setDraw(C.border); doc.setLineWidth(0.3); doc.roundedRect(M, py, cw, 28, 3, 3, 'S');
    // Color strip
    const fc = f.id === 'masters' ? C.orange : f.id === 'consultoria' ? [0, 184, 148] : [206, 191, 228];
    setFill(fc); doc.rect(M, py, 3, 28, 'F');
    // Number badge
    setFill(fc); doc.roundedRect(M + 7, py + 5, 9, 9, 1.5, 1.5, 'F');
    setText([255, 255, 255]); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.text('0' + (i + 1), M + 11.5, py + 11, { align: 'center' });
    // Title
    setText(C.ink); doc.setFontSize(12);
    doc.text(f.name, M + 22, py + 9);
    // Short
    setText(C.gray); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
    doc.text(f.short, M + 22, py + 14);
    // Desc
    setText(C.inkSoft); doc.setFontSize(8.5);
    doc.text(doc.splitTextToSize(f.desc, cw - 30), M + 22, py + 19);
    // Duration
    setText(fc); doc.setFont('helvetica', 'bold'); doc.setFontSize(7.5);
    doc.text(f.duration, pageW - M - 5, py + 25, { align: 'right' });
    py += 32;
  });

  // PAGE 5 — Recognition + Closing
  doc.addPage();
  chrome('Reconocimiento');
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('RECONOCIMIENTO', M, 30);
  setText(C.ink); doc.setFontSize(26);
  doc.text('Microcredenciales', M, 46);
  setText(C.orange); doc.text('Refactika', M, 60);
  setText(C.inkSoft); doc.setFont('helvetica', 'normal'); doc.setFontSize(11);
  doc.text(doc.splitTextToSize(ABR_MODEL.recognition, cw), M, 72);

  // Hours table summary — now includes troncal 120h
  const hy = 92;
  setFill(C.ink); doc.roundedRect(M, hy, cw, 70, 3, 3, 'F');
  setText(C.orange); doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
  doc.text('CARGA HORARIA POR PROGRAMA', M + 8, hy + 10);
  // Troncal row
  setText([255, 255, 255]); doc.setFontSize(11); doc.setFont('helvetica', 'normal');
  doc.text('Troncal común · 5 bloques de 24 h', M + 8, hy + 22);
  setText(C.orange); doc.setFontSize(15); doc.setFont('helvetica', 'bold');
  doc.text('120 horas', pageW - M - 8, hy + 22, { align: 'right' });
  // Skill medium
  setText([255, 255, 255]); doc.setFontSize(11); doc.setFont('helvetica', 'normal');
  doc.text('Habilidad media · 14 semanas · 5 reservas gym', M + 8, hy + 36);
  setText([255, 255, 255]); doc.setFontSize(15); doc.setFont('helvetica', 'bold');
  doc.text('300 horas', pageW - M - 8, hy + 36, { align: 'right' });
  // Skill alta
  setText([255, 255, 255]); doc.setFontSize(11); doc.setFont('helvetica', 'normal');
  doc.text('Habilidad alta · 22 semanas · 10 reservas gym', M + 8, hy + 50);
  setText(C.orange); doc.setFontSize(15); doc.setFont('helvetica', 'bold');
  doc.text('450 horas', pageW - M - 8, hy + 50, { align: 'right' });
  // Note
  setText([180, 180, 200]); doc.setFontSize(8); doc.setFont('helvetica', 'normal');
  doc.text('Total por programa = troncal (120 h) + habilidades específicas. El gimnasio sincrónico es transversal y se reserva con tu pase.', M + 8, hy + 62, { maxWidth: cw - 16 });

  // Closing
  setText(C.ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(15);
  doc.text('La IA no reemplaza profesionales.', pageW / 2, 200, { align: 'center' });
  setText(C.orange);
  doc.text('Reemplaza a quienes no la usan.', pageW / 2, 211, { align: 'center' });
  setText(C.gray); doc.setFontSize(9); doc.setFont('helvetica', 'normal');
  doc.text('REFACTIKA · IA School · Aceleradora IA · Grupo Aspasia', pageW / 2, 222, { align: 'center' });

  doc.save(`IAschool_modelo_pedagogico_ABR_${new Date().toISOString().slice(0, 10)}.pdf`);
}

function AdminOfferings() {
  const [state, setState] = useState(adminStore.getState());
  const [editingId, setEditingId] = useState(null);
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [form, setForm] = useState({ name: '', sector: 'marketing', duration: '5 meses', price: '1490 €', desc: '' });
  const offerings = state.offerings || [];

  function refresh() { setState(adminStore.getState()); }
  function saveCustom() {
    if (!form.name) return;
    adminStore.addOffering(form);
    refresh();
    setForm({ name: '', sector: 'marketing', duration: '5 meses', price: '1490 €', desc: '' });
    setShowCustomForm(false);
  }
  function removeCustom(id) { adminStore.removeOffering(id); refresh(); }

  const totalSkills = Object.values(ACADEMY_SKILLS).flat().length;

  return (
    <div className="space-y-4">
      {/* Header — IA School framing + downloads */}
      <div className="bg-ink-900 rounded-2xl p-5 text-white relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <div className="text-xs text-orange-500 font-bold tracking-wide">IA SCHOOL · OFERTA FORMATIVA</div>
            <div className="text-lg font-black mt-1">{Object.keys(ACADEMIES).length} verticales · {totalSkills} habilidades</div>
            <div className="text-xs text-ink-300 mt-1">Troncal común {TRONCAL.hours} h + habilidades específicas por vertical</div>
            <div className="text-[10px] text-ink-300 mt-0.5">Metodología ABR · Gimnasio sincrónico · Microcredenciales Refactika</div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={exportTrainingExcel}
              className="bg-orange-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-orange-600 transition flex items-center gap-1.5">
              <span>📊</span> Exportar Excel
            </button>
            <button onClick={generateMethodologyPDF}
              className="bg-white text-ink-900 px-3 py-2 rounded-xl text-xs font-semibold hover:bg-paper transition flex items-center gap-1.5">
              <span>📘</span> Modelo pedagógico ABR
            </button>
            <button onClick={() => Object.values(ACADEMIES).forEach(a => generateItineraryPDF({ academy: getEffectiveAcademy(a.id), region: 'espana' }))}
              className="bg-white/10 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-white/20 transition border border-white/20 flex items-center gap-1.5">
              <span>⬇</span> Todos los PDF
            </button>
          </div>
        </div>
      </div>

      {/* Verticales / Aceleradoras (editable) */}
      <div>
        <h4 className="text-sm font-bold text-ink-900 mb-3">Verticales IA School · {Object.keys(ACADEMIES).length} programas</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {Object.values(ACADEMIES).map(base => {
            const a = getEffectiveAcademy(base.id);
            const skills = ACADEMY_SKILLS[a.id] || [];
            const overridden = !!(state.academyOverrides || {})[a.id];
            return (
              <div key={a.id} className="bg-white border border-ink-900/8 rounded-2xl p-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-lg flex-shrink-0">{a.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-ink-900 text-sm leading-tight">{a.shortName}</div>
                    <div className="text-[11px] text-ink-500 mt-0.5">{a.duration} · {skills.length} habilidades · {skills.reduce((s, sk) => s + hoursForSkill(sk), 0)} h</div>
                  </div>
                  {overridden && <span className="text-[10px] bg-orange-50 text-orange-600 px-2 py-0.5 rounded-full whitespace-nowrap">Editado</span>}
                </div>
                <div className="text-xs text-ink-500 mb-3">
                  Desde <b className="text-ink-900">{a.priceEur}</b> · pase gimnasio: <b className="text-orange-500">{syncPassForAcademy(a.id)} sesiones</b>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <button onClick={() => setEditingId(a.id)}
                    className="text-xs px-3 py-1.5 bg-ink-900 text-white rounded-lg font-semibold hover:bg-ink-800 transition flex items-center gap-1">
                    ✏ Editar
                  </button>
                  <button onClick={() => generateItineraryPDF({ academy: a, region: 'espana' })}
                    className="text-xs px-3 py-1.5 bg-orange-50 text-orange-600 rounded-lg font-semibold hover:bg-orange-100 transition flex items-center gap-1">
                    📄 PDF
                  </button>
                  {overridden && (
                    <button onClick={() => { adminStore.resetAcademyOverride(a.id); refresh(); }}
                      className="text-xs text-ink-500 hover:text-red-500 ml-auto">Restablecer</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Edit modal */}
      {editingId && (
        <AcademyEditModal
          academyId={editingId}
          onClose={() => setEditingId(null)}
          onSaved={() => { refresh(); setEditingId(null); }}
        />
      )}

      {/* Custom offerings */}
      <div className="border-t border-ink-900/5 pt-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h4 className="text-sm font-bold text-ink-900">Ofertas personalizadas</h4>
            <div className="text-xs text-ink-500">Programas a medida fuera del catálogo base</div>
          </div>
          <button onClick={() => setShowCustomForm(!showCustomForm)}
            className="bg-orange-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-orange-600 transition">
            {showCustomForm ? 'Cancelar' : '+ Nueva oferta'}
          </button>
        </div>

        {showCustomForm && (
          <div className="bg-white border border-ink-900/8 rounded-2xl p-4 space-y-3 mb-3">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nombre (ej: Aceleradora IA Healthcare)"
              className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <select value={form.sector} onChange={(e) => setForm({ ...form, sector: e.target.value })}
                className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition">
                {Object.values(SECTORS).map(s => <option key={s.id} value={s.id}>{s.icon} {s.name}</option>)}
              </select>
              <input value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} placeholder="Duración"
                className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
              <input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Precio"
                className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            </div>
            <textarea value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} placeholder="Descripción breve" rows="2"
              className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition resize-none" />
            <button onClick={saveCustom}
              className="bg-ink-900 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-ink-800 transition">Guardar oferta</button>
          </div>
        )}

        {offerings.length > 0 && (
          <div className="space-y-2">
            {offerings.map(o => (
              <div key={o.id} className="bg-white border border-ink-900/8 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="font-bold text-ink-900 text-sm">{o.name}</div>
                  <div className="text-xs text-ink-500">{o.sector} · {o.duration} · {o.price}</div>
                </div>
                <button onClick={() => removeCustom(o.id)} className="text-xs text-red-500 hover:underline">Eliminar</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Edit modal — name, prices, modules, color, challenge
function AcademyEditModal({ academyId, onClose, onSaved }) {
  const base = ACADEMIES[academyId];
  const eff = getEffectiveAcademy(academyId);
  const [form, setForm] = useState({
    name: eff.name,
    shortName: eff.shortName,
    duration: eff.duration,
    synchronous: eff.synchronous,
    asynchronous: eff.asynchronous,
    challenge: eff.challenge,
    priceEur: eff.priceEur,
    priceUsd: eff.priceUsd,
    color: eff.color,
    modules: (eff.modules || []).join('\n'),
    outcomes: (eff.outcomes || []).join('\n'),
    icon: eff.icon,
    link: eff.link,
  });

  function save() {
    const patch = {
      ...form,
      modules: form.modules.split('\n').map(s => s.trim()).filter(Boolean),
      outcomes: form.outcomes.split('\n').map(s => s.trim()).filter(Boolean),
    };
    adminStore.saveAcademyOverride(academyId, patch);
    onSaved();
  }

  return (
    <div className="fixed inset-0 bg-ink-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[88vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-ink-900/5 p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-orange-500 font-bold">EDITAR ACELERADORA</div>
            <h3 className="text-lg font-black text-ink-900">{base.shortName}</h3>
          </div>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-900 text-xl">×</button>
        </div>
        <div className="p-5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} placeholder="Icono"
              className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            <input value={form.shortName} onChange={(e) => setForm({ ...form, shortName: e.target.value })} placeholder="Nombre corto"
              className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition sm:col-span-2" />
          </div>
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nombre completo"
            className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} placeholder="Duración"
              className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            <input value={form.priceEur} onChange={(e) => setForm({ ...form, priceEur: e.target.value })} placeholder="Precio EUR"
              className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            <input value={form.priceUsd} onChange={(e) => setForm({ ...form, priceUsd: e.target.value })} placeholder="Precio USD"
              className="p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
          </div>
          <div>
            <label className="text-xs font-bold text-ink-900">Modalidad sincrónica</label>
            <input value={form.synchronous} onChange={(e) => setForm({ ...form, synchronous: e.target.value })}
              className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
          </div>
          <div>
            <label className="text-xs font-bold text-ink-900">Modalidad asincrónica</label>
            <input value={form.asynchronous} onChange={(e) => setForm({ ...form, asynchronous: e.target.value })}
              className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
          </div>
          <div>
            <label className="text-xs font-bold text-ink-900">Reto general</label>
            <textarea value={form.challenge} onChange={(e) => setForm({ ...form, challenge: e.target.value })} rows="2"
              className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition resize-none" />
          </div>
          <div>
            <label className="text-xs font-bold text-ink-900">Temario · módulos (un módulo por línea)</label>
            <textarea value={form.modules} onChange={(e) => setForm({ ...form, modules: e.target.value })} rows="6"
              className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition resize-none font-mono text-xs" />
          </div>
          <div>
            <label className="text-xs font-bold text-ink-900">Outcomes (uno por línea)</label>
            <textarea value={form.outcomes} onChange={(e) => setForm({ ...form, outcomes: e.target.value })} rows="3"
              className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition resize-none font-mono text-xs" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-ink-900">Color (hex) · diseño</label>
              <input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} placeholder="#FF6A00"
                className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            </div>
            <div>
              <label className="text-xs font-bold text-ink-900">Link público</label>
              <input value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })}
                className="w-full mt-1 p-3 border border-ink-900/10 rounded-xl bg-paper focus:border-orange-500 transition" />
            </div>
          </div>
        </div>
        <div className="sticky bottom-0 bg-white border-t border-ink-900/5 p-5 flex items-center justify-between gap-3">
          <button onClick={() => generateItineraryPDF({ academy: { ...ACADEMIES[academyId], ...form, modules: form.modules.split('\n').filter(Boolean), outcomes: form.outcomes.split('\n').filter(Boolean) }, region: 'espana' })}
            className="text-xs text-ink-500 hover:text-orange-500 flex items-center gap-1">
            👁 Previsualizar PDF
          </button>
          <div className="flex gap-2">
            <button onClick={onClose} className="px-4 py-2 text-sm text-ink-500 hover:text-ink-900">Cancelar</button>
            <button onClick={save} className="bg-ink-900 text-white px-5 py-2 rounded-xl text-sm font-semibold hover:bg-ink-800 transition">Guardar cambios</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminManage() {
  const [state, setState] = useState(adminStore.getState());
  const [form, setForm] = useState({ name: '', email: '', password: '' });

  function addAdmin() {
    if (!form.email || !form.password || !form.name) return;
    adminStore.addAdmin(form);
    setState(adminStore.getState());
    setForm({ name: '', email: '', password: '' });
  }
  function remove(email) {
    if (!confirm(`¿Eliminar admin ${email}?`)) return;
    adminStore.removeAdmin(email);
    setState(adminStore.getState());
  }

  return (
    <div className="space-y-4">
      <div className="bg-white border border-ink-900/8 rounded-2xl p-5 space-y-3">
        <div className="font-bold text-ink-900 text-sm">Añadir nuevo admin</div>
        <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nombre"
          className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper" />
        <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" type="email"
          className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper" />
        <input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Contraseña inicial" type="text"
          className="w-full p-3 border border-ink-900/10 rounded-xl bg-paper" />
        <button onClick={addAdmin}
          className="bg-ink-900 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-ink-800 transition">Añadir admin</button>
      </div>

      <h4 className="text-sm font-bold text-ink-900 mt-4">Admins activos ({state.admins.length})</h4>
      <div className="space-y-2">
        {state.admins.length === 0 && (
          <div className="bg-white border border-ink-900/8 rounded-2xl p-4 text-sm text-ink-500">
            No hay admins creados aún. Crea uno arriba.
          </div>
        )}
        {state.admins.map(a => (
          <div key={a.email} className="bg-white border border-ink-900/8 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <div className="font-bold text-ink-900 text-sm">{a.name}</div>
              <div className="text-xs text-ink-500">{a.email}</div>
            </div>
            <button onClick={() => remove(a.email)} className="text-xs text-red-500 hover:underline">Eliminar</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  // views: 'landing' | 'market' | 'consent' | 'intro' | 'profile' | 'insight' | 'plan' | 'admin'
  const [view, setView] = useState('landing');
  const [region, setRegion] = useState('espana');
  const [contact, setContact] = useState(null);
  const [goal, setGoal] = useState(null);
  const [profile, setProfile] = useState(null);

  // Allow /#admin hash to deep-link
  useEffect(() => {
    const check = () => {
      if (location.hash === '#admin') setView('admin');
    };
    check();
    window.addEventListener('hashchange', check);
    return () => window.removeEventListener('hashchange', check);
  }, []);

  function handleStart() { setView('consent'); }
  function handleMarket() { setView('market'); }
  function handleConsent(c) { setContact(c); setView('intro'); }
  function handleIntroDone(g) { setGoal(g); setView('profile'); }
  function handleProfileDone(p) { setProfile(p); setView('analyzing'); }
  function handleAnalyzingDone() { setView('plan'); }
  function handleRestart() { setView('landing'); setContact(null); setGoal(null); setProfile(null); location.hash = ''; }
  function handleAdmin() { location.hash = '#admin'; setView('admin'); }

  return (
    <div className="min-h-screen bg-paper">
      <TopBar region={region} onRegionChange={setRegion} onRestart={handleRestart} onMarket={handleMarket} onAdmin={handleAdmin} currentView={view} />

      {view === 'landing' && <Landing onStart={handleStart} onMarket={handleMarket} region={region} />}

      {view === 'market' && <MarketIntel onBack={handleStart} region={region} />}

      {view === 'consent' && <ConsentGate onAccept={handleConsent} onCancel={() => setView('landing')} />}

      {view === 'intro' && contact && (
        <IntroChat onComplete={handleIntroDone} onBack={() => setView('consent')} userContact={contact} />
      )}

      {view === 'profile' && goal && (
        <Profile onComplete={handleProfileDone} onBack={() => setView('intro')} sector={goal.sector} />
      )}

      {view === 'analyzing' && goal && (
        <Analyzing sector={goal.sector} userData={{ ...contact, ...goal, ...profile }} region={region} onDone={handleAnalyzingDone} />
      )}

      {view === 'insight' && goal && (
        <SectorInsight
          sector={goal.sector}
          region={region}
          onContinue={() => setView('plan')}
          onBack={() => setView('profile')}
        />
      )}

      {view === 'plan' && goal && (
        <Plan
          sector={goal.sector}
          region={region}
          userData={{ ...contact, ...goal, ...profile }}
          onRestart={handleRestart}
        />
      )}

      {view === 'admin' && <AdminPanel onExit={handleRestart} />}

      {/* Footer */}
      <footer className="border-t border-ink-900/5 py-8 text-center">
        <div className="max-w-5xl mx-auto px-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-ink-500">
            <div className="flex items-center gap-2">
              <OrientadorMark size="sm" />
              <span>·</span>
              <span>by <BrandMark size="xs" /></span>
            </div>
            <div>© 2026 Grupo Aspasia · Todas las decisiones las tomas tú.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
