# OrientadorIA · Producción · Guía paso a paso

Esta guía te lleva desde el repo local a una URL pública lista para compartir, en orden de menor a mayor esfuerzo.

---

## 0. Lo que tienes hoy

```
/Users/rodrigopoblete/Desktop/Claude/orientadorIA/
├── orientadorIA.html   ← APP COMPLETA en un único archivo (~215 KB)
├── index.html          ← shell con CDNs (carga app.js)
├── app.js              ← código React (~4.300 líneas)
└── DEPLOY.md           ← este archivo
```

- **Stack actual:** React 18 (UMD) + Babel standalone + Tailwind CDN + jsPDF + pdf.js
- **Persistencia:** `localStorage` (admin, leads, overrides de aceleradoras)
- **Sin backend** — todo corre en el navegador
- **Credenciales superadmin:** `superadmin@refactika.com` / `refactika2026`

---

## 1. Compartir hoy mismo (5 min · cero configuración)

El archivo `orientadorIA.html` es **100% standalone**: lo abres en cualquier navegador moderno y funciona.

### Opciones para distribuirlo:

| Opción | Cómo | Coste | Tiempo |
|---|---|---|---|
| **Email / WhatsApp / Drive** | Adjunta `orientadorIA.html` directo | 0 € | 1 min |
| **GitHub Pages** | Sube a un repo público + activa Pages | 0 € | 10 min |
| **Vercel / Netlify drop** | Drag & drop del HTML en su panel | 0 € | 3 min |
| **Cloudflare Pages** | `wrangler pages deploy orientadorIA.html` | 0 € | 5 min |
| **Tu hosting propio** | Sube por FTP a un subdominio | depende | 10 min |

**Recomendación rápida → Vercel drop:**
1. Entra a https://vercel.com/new
2. Arrastra `orientadorIA.html` (renómbralo a `index.html` antes)
3. Listo. Te dan una URL `https://orientadorIA.vercel.app`

---

## 2. Paso a paso · GitHub Pages (recomendado para versión "demo pública")

```bash
cd /Users/rodrigopoblete/Desktop/Claude/orientadorIA

# 1) Crear repo (si aún no existe)
git init
git add orientadorIA.html index.html app.js DEPLOY.md
git commit -m "OrientadorIA — initial production release"

# 2) Crear repo remoto en github.com (UI o gh CLI)
gh repo create orientadorIA --public --source=. --push

# 3) Renombrar para Pages (Pages sirve index.html)
cp orientadorIA.html index-standalone.html
# o usa el index.html + app.js con tu propio servidor

# 4) Activar Pages
# Settings → Pages → Branch: main, /(root) → Save
```

URL pública: `https://<tu-usuario>.github.io/orientadorIA/`

---

## 3. Paso a paso · Vercel (recomendado para producción seria)

```bash
cd /Users/rodrigopoblete/Desktop/Claude/orientadorIA

# 1) Asegúrate de tener un index.html sirviendo el standalone
cp orientadorIA.html index.html

# 2) Deploy
npx vercel --prod
```

Vercel te dará una URL tipo `https://orientadoria.vercel.app` y un **dominio personalizado** (ej. `orientador.refactika.com`) configurable en su panel.

**Configura el dominio:**
1. Vercel → Settings → Domains → Add `orientador.refactika.com`
2. En tu DNS añade un registro `CNAME` apuntando a `cname.vercel-dns.com`
3. Espera 5-30 min — HTTPS automático

---

## 4. Antes de "lanzar de verdad" — checklist pre-producción

> El standalone funciona perfecto para demo / piloto. Para una versión profesional con tráfico real, considera estos puntos:

### 4.1 Branding y dominio
- [ ] Sustituir el isotipo (`https://refactika.com/images/isotipo.svg`) por el final
- [ ] Verificar links de cada Aceleradora (`https://refactika.com/ia-marketing` etc.) que apunten al sistema de pagos real
- [ ] Configurar el email `admisiones@refactika.com` (lo usa el CTA del PDF)
- [ ] Revisar el WhatsApp `+34 900 000 000` y reemplazarlo en `app.js` (search "900000000")

### 4.2 Datos personales (RGPD)
- [ ] Tener una **política de privacidad** publicada en `refactika.com/privacidad`
- [ ] Configurar el email `privacidad@refactika.com` (visible en el ConsentGate)
- [ ] Inscribir el tratamiento de datos ante la AEPD si vas a almacenar leads

### 4.3 Persistencia real (cuando localStorage se quede corto)
Hoy los leads se guardan **solo en el navegador del admin**. Para producción real tienes 3 caminos:

| Camino | Esfuerzo | Resultado |
|---|---|---|
| **Webhook a Make/Zapier** | 1 h | Cada lead va directo a Notion / Sheet / CRM |
| **Backend ligero (Supabase)** | 1 día | API + auth real + dashboard SQL |
| **Backend completo** | 1 semana | Custom REST + admin con roles + reporting |

**Quick win recomendado:** Make.com webhook hacia tu CRM actual.

### 4.4 Autenticación admin (cuando salgas del piloto)
La contraseña actual está **en el código del cliente**. Para producción:
- [ ] Mover el login a un endpoint serverless (Vercel Function / Supabase Auth)
- [ ] Hashear contraseñas
- [ ] JWT con expiración

### 4.5 Performance / SEO
- [ ] Migrar de Babel standalone a build (Vite o Next) — divide el tiempo de carga inicial /3
- [ ] Añadir `og:image` y meta tags para social sharing
- [ ] Configurar Plausible / GA4

### 4.6 Analytics & tracking
- [ ] Plausible.io snippet en `<head>` (privacy-first)
- [ ] o Google Analytics 4 con consent mode
- [ ] Eventos clave: empezar entrevista · sector elegido · PDF descargado · CTA contactar

---

## 5. Migración a build profesional (cuando ya estés en tracción)

Cuando el piloto valide, conviértelo en proyecto Vite + React:

```bash
npm create vite@latest orientadorIA-prod -- --template react
cd orientadorIA-prod
npm install
npm install -D tailwindcss@4 vite-plugin-react
npm install jspdf pdfjs-dist
```

Luego:
1. Mueve el contenido de `app.js` a `src/App.jsx`
2. Configura Tailwind 4 (con tu paleta naranja/ink ya definida)
3. Convierte localStorage → Supabase / API
4. Despliega con `vercel --prod`

Pasarás de un HTML monolítico de 215 KB a un build de ~80 KB con code splitting.

---

## 6. Variables y configuraciones que querrás externalizar

Cuando migres a Vite/Next, estas constantes son las primeras candidatas a variables de entorno o admin DB:

| Constante | Dónde está | Qué hacer |
|---|---|---|
| `SUPERADMIN` (email + password) | `app.js` línea ~1132 | Mover a backend |
| `ADMIN_KEY` localStorage | `app.js` línea ~1131 | Reemplazar por sesión backend |
| `ACADEMIES` (13 verticales) | `app.js` líneas ~570-960 | Mover a Supabase/CMS |
| `ACADEMY_SKILLS` | `app.js` líneas ~990-1060 | Mover a Supabase/CMS |
| `DATA_SOURCES` regional | `app.js` líneas ~440-490 | Mover a config |
| Email del CTA del PDF | `app.js` (busca "admisiones@") | Variable de entorno |
| WhatsApp del CTA | `app.js` (busca "900000000") | Variable de entorno |
| Links de cada Aceleradora | Cada item de `ACADEMIES` | Variable / DB |

---

## 7. Foco final · roadmap recomendado

**Semana 1 — Demo viva**
- Deploy del standalone a Vercel
- Configurar dominio `orientador.refactika.com`
- Probar el flujo end-to-end con 5 personas

**Semana 2 — Captura de leads**
- Webhook a Make/Zapier hacia tu CRM
- Política de privacidad publicada
- Email transaccional real (Resend/Postmark) cuando alguien descarga el itinerario

**Semana 3 — Iteración**
- Tracking de embudo (qué % llega al PDF)
- Ajustar el copy de las verticales según preguntas reales
- Incorporar 2-3 verticales que pidan tus prospects

**Mes 2 — Escala**
- Migrar a Vite + Supabase
- Admin con roles reales
- Sistema de pagos integrado por aceleradora

---

## 8. Soporte rápido

Para resolver dudas o añadir features:

```bash
# Servir localmente con hot reload
cd /Users/rodrigopoblete/Desktop/Claude/orientadorIA
python3 /tmp/orientadorIA-serve.py
# Abrir http://localhost:8081
```

El admin sigue accesible en `http://localhost:8081/#admin` con `superadmin@refactika.com` / `refactika2026`.

---

**Resumen:** Hoy tienes un producto demo-ready con un solo archivo. La ruta más corta a producción real son **3 horas**:
1. Vercel deploy + dominio (1 h)
2. Webhook a Make hacia tu CRM (1 h)
3. Tracking básico + privacidad (1 h)

Y ya estás vendiendo.
