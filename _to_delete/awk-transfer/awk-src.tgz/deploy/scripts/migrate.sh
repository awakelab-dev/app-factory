#!/usr/bin/env bash
# Corre `prisma migrate deploy` (+ opcionalmente seed) contra staging o
# production usando la imagen "migrator" publicada en GHCR (mismo tag que
# awkplatform-api, ver apps/api/Dockerfile stage `migrator` y D-013/D-016).
# Se ejecuta DESDE el Lightsail de cómputo: la managed PG es privada
# (docs/runbooks/lightsail-postgres.md) y este host sí tiene ruta a ella.
#
# Uso:
#   ./migrate.sh staging    <tag>            # solo migraciones
#   ./migrate.sh staging    <tag> --seed      # migraciones + seed (primera vez)
#   ./migrate.sh production <tag>
set -euo pipefail

ENV_NAME="${1:?Uso: migrate.sh <staging|production> <tag> [--seed]}"
TAG="${2:?Uso: migrate.sh <staging|production> <tag> [--seed]}"
SEED="${3:-}"

case "$ENV_NAME" in
  staging|production) ;;
  *) echo "Entorno inválido: $ENV_NAME (usa staging o production)"; exit 1 ;;
esac

ENV_FILE="/opt/awkfactory/${ENV_NAME}/.env"
[ -f "$ENV_FILE" ] || { echo "No existe ${ENV_FILE}"; exit 1; }

IMAGE="ghcr.io/awakelab-dev/awkplatform-api-migrator:${TAG}"
docker pull "$IMAGE"

# Binarios directos (node_modules/.bin), NUNCA "pnpm exec ...": en este
# workspace "pnpm exec" dispara el chequeo de deps de pnpm 11 y termina
# reinstalando en modo --production a mitad de la corrida, borrando prisma/
# tsx (devDependencies) justo antes de usarlos — reproducido en el server
# real (2026-07-12). Ver comentario en apps/api/Dockerfile stage `migrator`.
RUN_CMD="node_modules/.bin/prisma migrate deploy"
if [ "$SEED" = "--seed" ]; then
  RUN_CMD="${RUN_CMD} && node_modules/.bin/tsx prisma/seed.ts"
fi

docker run --rm --env-file "$ENV_FILE" "$IMAGE" sh -c "$RUN_CMD"

echo "Migración (${ENV_NAME} @ ${TAG}) completada."
