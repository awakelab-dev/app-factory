import { z } from 'zod';

/**
 * @awk/types — contratos compartidos front↔back.
 * Cada endpoint de la API define aquí su schema Zod: un solo esquema da
 * validación runtime (API), tipos TS (web y api) y, más adelante, OpenAPI.
 */

// ---------------------------------------------------------------------------
// Hello (demo end-to-end de Fase 0)
// ---------------------------------------------------------------------------

export const helloResponseSchema = z.object({
  service: z.string(),
  message: z.string(),
  timestamp: z.iso.datetime()
});

export type HelloResponse = z.infer<typeof helloResponseSchema>;

// ---------------------------------------------------------------------------
// Auth (core). El dev-login es temporal hasta que haya IdP (ver STATUS).
// ---------------------------------------------------------------------------

/** Usuario autenticado tal como viaja entre api y web. */
export const authUserSchema = z.object({
  id: z.string(),
  email: z.email(),
  displayName: z.string(),
  roles: z.array(z.string())
});

export type AuthUser = z.infer<typeof authUserSchema>;

export const devLoginRequestSchema = z.object({
  email: z.email()
});

export type DevLoginRequest = z.infer<typeof devLoginRequestSchema>;

export const devLoginResponseSchema = z.object({
  accessToken: z.string(),
  user: authUserSchema
});

export type DevLoginResponse = z.infer<typeof devLoginResponseSchema>;

// ---------------------------------------------------------------------------
// Usuarios del core (GET /api/core/users — solo admin)
// ---------------------------------------------------------------------------

export const coreUserSchema = z.object({
  id: z.string(),
  email: z.email(),
  displayName: z.string(),
  isActive: z.boolean(),
  roles: z.array(z.string()),
  createdAt: z.iso.datetime()
});

export type CoreUser = z.infer<typeof coreUserSchema>;

export const coreUsersResponseSchema = z.array(coreUserSchema);

// ---------------------------------------------------------------------------
// Roles del core (GET /api/core/roles, PUT /api/core/users/:id/roles — admin).
//
// Incremento D, bloque 2: hasta 2026-08-17 los roles que declaraban los
// módulos generados no existían en la BD hasta que alguien metía un INSERT a
// mano, y no había forma de ASIGNARLOS que no fuera SQL (el controller de
// usuarios solo tenía @Get). Pasó con incidencias-aula y con reserva-salas
// (D-049): módulo desplegado y correcto, invisible para quien iba a validarlo.
// ---------------------------------------------------------------------------

export const coreRoleSchema = z.object({
  name: z.string(),
  description: z.string(),
  /** Cuántos usuarios lo tienen (para no borrar un rol en uso a ciegas). */
  usersCount: z.number().int()
});

export type CoreRole = z.infer<typeof coreRoleSchema>;

export const coreRolesResponseSchema = z.array(coreRoleSchema);

/**
 * Reemplaza el conjunto completo de roles de un usuario (no es un parche
 * incremental: lo que llega es el estado final). Lista vacía = sin roles.
 */
export const updateUserRolesRequestSchema = z.object({
  roles: z.array(z.string().min(1)).max(50)
});

export type UpdateUserRolesRequest = z.infer<typeof updateUserRolesRequestSchema>;

/**
 * Alta de usuario de plataforma (POST /api/core/users — admin).
 *
 * Cierra el último hueco de "cero consola" del bloque 2: `dev-login` exige que
 * el usuario EXISTA en `core.users`, así que un gerente del piloto no podía
 * entrar a staging a validar su módulo sin que alguien le insertara la fila por
 * SQL. Ojo con la confusión de conceptos: un actor de la Fábrica
 * (`factory_actors`, el que crea `create-actor` para el conector de Cowork) NO
 * es un usuario de plataforma — son dos bases de datos y dos identidades.
 */
export const createUserRequestSchema = z.object({
  email: z.email(),
  displayName: z.string().min(1).max(120),
  /** Roles iniciales; vacío = usuario sin roles (ve solo los módulos abiertos). */
  roles: z.array(z.string().min(1)).max(50).default([])
});

export type CreateUserRequest = z.infer<typeof createUserRequestSchema>;

/** Alta/baja de acceso de un usuario (PATCH /api/core/users/:id/active — admin). */
export const setUserActiveRequestSchema = z.object({
  isActive: z.boolean()
});

export type SetUserActiveRequest = z.infer<typeof setUserActiveRequestSchema>;

// ---------------------------------------------------------------------------
// Manifest de módulo. Cada módulo (generado por la fábrica o hecho a mano)
// declara uno; el shell de apps/web construye menú y rutas a partir de él.
// Es data serializable a propósito: más adelante la API podrá servir los
// manifests activos por tenant/rol.
// ---------------------------------------------------------------------------

export const navItemSchema = z.object({
  label: z.string(),
  /** Ruta absoluta dentro del shell (p. ej. "/admin/usuarios"). */
  path: z.string().startsWith('/'),
  /** Roles que ven este ítem; ausente o vacío = visible para cualquier usuario autenticado. */
  requiredRoles: z.array(z.string()).optional(),
  /** Nombre de icono de lucide-react (p. ej. "GraduationCap"); el shell cae a uno por defecto si falta o no lo reconoce. */
  icon: z.string().optional()
});

export type NavItem = z.infer<typeof navItemSchema>;

export const moduleManifestSchema = z.object({
  /** Slug estable del módulo (kebab-case). */
  id: z.string().regex(/^[a-z][a-z0-9-]*$/),
  name: z.string(),
  description: z.string().optional(),
  /** Prefijo de rutas del módulo (p. ej. "/admin"). */
  basePath: z.string().startsWith('/'),
  /** Roles con acceso al módulo completo; ausente o vacío = cualquier usuario autenticado. */
  requiredRoles: z.array(z.string()).optional(),
  /** Ítems que el shell pinta en el menú lateral. */
  nav: z.array(navItemSchema)
});

export type ModuleManifest = z.infer<typeof moduleManifestSchema>;

// ---------------------------------------------------------------------------
// Módulo moodle-insights (primer módulo ejemplar, D-020/D-021/D-022): réplica
// parcial de una instancia Moodle (cursos, alumnos, calificaciones) vía Moodle
// Web Services, disparada a mano con el botón "Actualizar datos" — no hay
// sincronización automática. Ver docs/DECISIONES.md D-022 para el detalle del
// contrato (funciones wsfunction usadas, alcance single-tenant).
// ---------------------------------------------------------------------------

export const moodleSyncStatusSchema = z.enum(['running', 'success', 'error']);
export type MoodleSyncStatus = z.infer<typeof moodleSyncStatusSchema>;

export const moodleSyncRunSchema = z.object({
  id: z.string(),
  status: moodleSyncStatusSchema,
  startedAt: z.iso.datetime(),
  finishedAt: z.iso.datetime().nullable(),
  coursesCount: z.number().int(),
  studentsCount: z.number().int(),
  enrollmentsCount: z.number().int(),
  errorMessage: z.string().nullable()
});
export type MoodleSyncRun = z.infer<typeof moodleSyncRunSchema>;

export const moodleSummarySchema = z.object({
  totalCourses: z.number().int(),
  visibleCourses: z.number().int(),
  totalStudents: z.number().int(),
  totalEnrollments: z.number().int(),
  avgGrade: z.number().nullable(),
  coursesByCategory: z.array(z.object({ categoryName: z.string(), count: z.number().int() })),
  lastSync: moodleSyncRunSchema.nullable()
});
export type MoodleSummary = z.infer<typeof moodleSummarySchema>;

export const moodleCourseRowSchema = z.object({
  id: z.string(),
  moodleId: z.number().int(),
  shortname: z.string(),
  fullname: z.string(),
  categoryName: z.string().nullable(),
  visible: z.boolean(),
  studentsCount: z.number().int(),
  avgGrade: z.number().nullable()
});
export type MoodleCourseRow = z.infer<typeof moodleCourseRowSchema>;
export const moodleCoursesResponseSchema = z.array(moodleCourseRowSchema);

export const moodleStudentRowSchema = z.object({
  id: z.string(),
  moodleId: z.number().int(),
  fullname: z.string(),
  email: z.string(),
  coursesCount: z.number().int(),
  avgGrade: z.number().nullable()
});
export type MoodleStudentRow = z.infer<typeof moodleStudentRowSchema>;
export const moodleStudentsResponseSchema = z.array(moodleStudentRowSchema);

// ---------------------------------------------------------------------------
// Módulo orientador-ia (D-024/D-025, docs/pipeline/orientador-ia/): flujo
// público de orientación de carrera (candidato, sin login) + panel admin
// para el rol acotado "orientador_admin" (personal de Grupo Aspasia/Refactika,
// cliente de este módulo). El análisis por candidato es UNA llamada corta a
// Claude Haiku (segundos) — a diferencia de moodle-insights, no hay patrón
// asíncrono con polling: POST /intake ya responde con el perfil generado.
// ---------------------------------------------------------------------------

/** 13 sectores del contenido original (prototipo `orientadorIA`, D-025: se mantiene tal cual). */
export const ORIENTADOR_SECTORS = [
  'marketing',
  'desarrollo',
  'ventas',
  'logistica',
  'gestion',
  'operaciones',
  'rrhh',
  'factoria',
  'innovacion',
  'finanzas',
  'sostenibilidad',
  'tecnologia',
  'proyectos'
] as const;

export const orientadorSectorSchema = z.enum(ORIENTADOR_SECTORS);
export type OrientadorSector = z.infer<typeof orientadorSectorSchema>;

export const orientadorInputTypeSchema = z.enum(['story', 'linkedin_url', 'cv_pdf']);
export type OrientadorInputType = z.infer<typeof orientadorInputTypeSchema>;

export const orientadorLevelSchema = z.enum(['inicial', 'aplicada', 'experto']);
export type OrientadorLevel = z.infer<typeof orientadorLevelSchema>;

/** Payload que envía el candidato tras el consentimiento (endpoint público). */
export const orientadorIntakeRequestSchema = z.object({
  fullName: z.string().min(1).max(200),
  email: z.email(),
  phone: z.string().max(40).optional(),
  consentGiven: z.literal(true),
  consentMarketing: z.boolean().default(false),
  rawInputType: orientadorInputTypeSchema,
  /** Texto libre, URL de LinkedIn, o texto ya extraído del CV (pdf.js client-side). */
  rawInputText: z.string().min(1).max(2000),
  declaredSector: orientadorSectorSchema.optional(),
  declaredLevel: orientadorLevelSchema.optional()
});
export type OrientadorIntakeRequest = z.infer<typeof orientadorIntakeRequestSchema>;

export const orientadorProfileSchema = z.object({
  leadId: z.string(),
  recommendedSector: orientadorSectorSchema,
  rationale: z.string(),
  estimatedLevel: orientadorLevelSchema,
  skillGaps: z.array(z.string()),
  createdAt: z.iso.datetime()
});
export type OrientadorProfile = z.infer<typeof orientadorProfileSchema>;

/** Respuesta de POST /intake: el candidato recibe su perfil ya generado, sin polling. */
export const orientadorIntakeResponseSchema = z.object({
  leadId: z.string(),
  profile: orientadorProfileSchema
});
export type OrientadorIntakeResponse = z.infer<typeof orientadorIntakeResponseSchema>;

export const orientadorAcademySchema = z.object({
  id: z.string(),
  sector: orientadorSectorSchema,
  name: z.string(),
  shortName: z.string(),
  icon: z.string(),
  color: z.string(),
  duration: z.string(),
  durationWeeks: z.number().int(),
  synchronous: z.string(),
  asynchronous: z.string(),
  challenge: z.string(),
  modules: z.array(z.string()),
  outcomes: z.array(z.string()),
  priceEur: z.string(),
  priceUsd: z.string(),
  purchaseUrl: z.string(),
  active: z.boolean()
});
export type OrientadorAcademy = z.infer<typeof orientadorAcademySchema>;
export const orientadorAcademiesResponseSchema = z.array(orientadorAcademySchema);

/** PUT /orientador-ia/admin/academies/:id (rol orientador_admin) — todo opcional, id fuera del body. */
export const orientadorAcademyUpdateSchema = orientadorAcademySchema
  .omit({ id: true, sector: true })
  .partial();
export type OrientadorAcademyUpdate = z.infer<typeof orientadorAcademyUpdateSchema>;

/** Fila de la lista de leads en el panel admin (rol orientador_admin). */
export const orientadorLeadRowSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  fullName: z.string(),
  email: z.string(),
  phone: z.string().nullable(),
  consentMarketing: z.boolean(),
  rawInputType: orientadorInputTypeSchema,
  declaredSector: orientadorSectorSchema.nullable(),
  analysisCount: z.number().int(),
  profile: orientadorProfileSchema.nullable()
});
export type OrientadorLeadRow = z.infer<typeof orientadorLeadRowSchema>;
export const orientadorLeadsResponseSchema = z.array(orientadorLeadRowSchema);

// ---------------------------------------------------------------------------
// Control plane de la Fábrica (D-030, paso 2 de D-026): contrato entre la API
// HTTP de apps/factory (/factory-api) y el módulo factory-console de apps/web.
// La Fábrica sigue siendo un sistema separado de la Plataforma (D-029: otra
// BD, sin FKs cruzadas) — aquí solo se comparte el CONTRATO de lectura/
// aprobación, igual que el resto de módulos comparten los suyos. Los valores
// de los enums coinciden 1:1 con apps/factory/prisma/schema.prisma (y con
// apps/factory/src/pipeline/types.ts — misma advertencia: si cambian allá,
// cambian aquí).
// ---------------------------------------------------------------------------

export const factoryProjectStatusSchema = z.enum([
  'received',
  'analyzing',
  'spec_ready',
  'pending_approval',
  'generating',
  'verifying',
  'pr_review',
  'staging',
  'manager_acceptance',
  'deployed',
  'changes_requested',
  'rejected',
  'error'
]);
export type FactoryProjectStatus = z.infer<typeof factoryProjectStatusSchema>;

export const factoryGateTypeSchema = z.enum(['functional', 'technical', 'pr_review', 'manager_acceptance']);
export type FactoryGateType = z.infer<typeof factoryGateTypeSchema>;

export const factoryGateStatusSchema = z.enum(['pending', 'approved', 'rejected', 'changes_requested']);
export type FactoryGateStatus = z.infer<typeof factoryGateStatusSchema>;

/** Decisión que puede tomar un revisor sobre un gate pendiente (docs/05: aprobar / rechazar / complementar). */
export const factoryGateDecisionSchema = z.enum(['approved', 'rejected', 'changes_requested']);
export type FactoryGateDecision = z.infer<typeof factoryGateDecisionSchema>;

export const factoryGateSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  gateType: factoryGateTypeSchema,
  status: factoryGateStatusSchema,
  reviewer: z.string().nullable(),
  decisionNotes: z.string().nullable(),
  decidedAt: z.iso.datetime().nullable()
});
export type FactoryGate = z.infer<typeof factoryGateSchema>;

export const factorySpecSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  version: z.number().int(),
  functionalContent: z.string(),
  technicalContent: z.string(),
  complexityScore: z.number().int().nullable(),
  sensitivityFlags: z.array(z.string()),
  reuseNotes: z.string().nullable(),
  gates: z.array(factoryGateSchema)
});
export type FactorySpec = z.infer<typeof factorySpecSchema>;

export const factoryRunTypeSchema = z.enum(['analysis', 'generation']);
export type FactoryRunType = z.infer<typeof factoryRunTypeSchema>;
export const factoryRunStatusSchema = z.enum(['pending', 'running', 'success', 'error']);
export type FactoryRunStatus = z.infer<typeof factoryRunStatusSchema>;

export const factoryRunSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  startedAt: z.iso.datetime().nullable(),
  finishedAt: z.iso.datetime().nullable(),
  runType: factoryRunTypeSchema,
  status: factoryRunStatusSchema,
  branchName: z.string().nullable(),
  prUrl: z.string().nullable(),
  outputSummary: z.string().nullable(),
  errorMessage: z.string().nullable(),
  costUsd: z.number().nullable(),
  inputTokens: z.number().int().nullable(),
  outputTokens: z.number().int().nullable()
});
export type FactoryRun = z.infer<typeof factoryRunSchema>;

/** Fila de GET /factory-api/projects (lista del control plane). */
export const factoryProjectSummarySchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  updatedAt: z.iso.datetime(),
  moduleSlug: z.string(),
  displayName: z.string(),
  requestedBy: z.string(),
  sourceType: z.enum(['manual', 'cowork_prototype']),
  status: factoryProjectStatusSchema,
  latestSpecVersion: z.number().int().nullable(),
  pendingGates: z.number().int()
});
export type FactoryProjectSummary = z.infer<typeof factoryProjectSummarySchema>;
export const factoryProjectsResponseSchema = z.array(factoryProjectSummarySchema);

/**
 * Trabajo de la cola de la Fábrica (`analysis_jobs`, D-047).
 *
 * Se expone (incremento D, bloque 5) porque hasta 2026-08-17 diagnosticar la
 * cola era `docker compose logs` por SSH: si un análisis no arrancaba o moría,
 * desde `/factory` y desde el chat el proyecto simplemente "no avanzaba", sin
 * ninguna señal de por qué.
 */
export const factoryAnalysisJobKindSchema = z.enum(['analysis', 'change_analysis']);
export type FactoryAnalysisJobKind = z.infer<typeof factoryAnalysisJobKindSchema>;

export const factoryAnalysisJobStatusSchema = z.enum(['queued', 'running', 'success', 'error']);
export type FactoryAnalysisJobStatus = z.infer<typeof factoryAnalysisJobStatusSchema>;

export const factoryAnalysisJobSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  kind: factoryAnalysisJobKindSchema,
  status: factoryAnalysisJobStatusSchema,
  /** Veces que un worker lo ha tomado (un 2 sin éxito ya es una señal). */
  attempts: z.number().int(),
  requestedBy: z.string(),
  /** Proceso que lo tomó (host:pid) — para cruzar con los logs si hace falta. */
  workerId: z.string().nullable(),
  claimedAt: z.iso.datetime().nullable(),
  /** Último latido del worker: si se queda atrás, el barrido lo da por muerto. */
  heartbeatAt: z.iso.datetime().nullable(),
  finishedAt: z.iso.datetime().nullable(),
  runId: z.string().nullable(),
  errorMessage: z.string().nullable(),
  changeRequestId: z.string().nullable()
});
export type FactoryAnalysisJob = z.infer<typeof factoryAnalysisJobSchema>;

/** GET /factory-api/projects/:id — proyecto completo (specs desc con gates + runs desc + cola). */
export const factoryProjectDetailSchema = factoryProjectSummarySchema
  .omit({ latestSpecVersion: true, pendingGates: true })
  .extend({
    sourceRef: z.string(),
    specs: z.array(factorySpecSchema),
    runs: z.array(factoryRunSchema),
    analysisJobs: z.array(factoryAnalysisJobSchema)
  });
export type FactoryProjectDetail = z.infer<typeof factoryProjectDetailSchema>;

/** POST /factory-api/gates/:id/decision — el reviewer sale del JWT, nunca del body. */
export const factoryGateDecisionRequestSchema = z.object({
  decision: factoryGateDecisionSchema,
  notes: z.string().max(4000).optional()
});
export type FactoryGateDecisionRequest = z.infer<typeof factoryGateDecisionRequestSchema>;

// ---------------------------------------------------------------------------
// Integración Cowork — incremento A de Fase 2 (D-036): contrato entre el
// conector MCP `awkfactory` (y cualquier otro cliente de /factory-api) y la
// Fábrica. `prototype.manifest.json` es lo que la skill de prototipado
// produce junto al HTML (docs/04, paso 1); la clasificación de sensibilidad
// por entidad es obligatoria (docs/05: "público / interno / confidencial /
// datos personales" — el análisis puede elevarla, nunca rebajarla).
// ---------------------------------------------------------------------------

/** Roles de actor de la Fábrica (PAT interino D-036; migrará a OAuth/SSO sin cambiar este contrato). */
export const factoryActorRoleSchema = z.enum(['gerente', 'admin']);
export type FactoryActorRole = z.infer<typeof factoryActorRoleSchema>;

/** Clasificación de sensibilidad por entidad (docs/05, "Clasificación en origen"). */
export const prototypeSensitivitySchema = z.enum(['publico', 'interno', 'confidencial', 'datos_personales']);
export type PrototypeSensitivity = z.infer<typeof prototypeSensitivitySchema>;

export const prototypeManifestSchema = z.object({
  /** Nombre de negocio del prototipo (no el slug — ese va aparte en la submission). */
  name: z.string().min(1).max(120),
  /** Qué problema resuelve y para quién, en lenguaje de negocio. */
  purpose: z.string().min(1).max(2000),
  /** Actores/roles que usan el módulo (docs/04: "actores/roles"). */
  actors: z
    .array(
      z.object({
        role: z.string().min(1).max(80),
        description: z.string().max(500).optional()
      })
    )
    .min(1),
  /** Entidades de datos detectadas, con sensibilidad declarada OBLIGATORIA por entidad. */
  entities: z
    .array(
      z.object({
        name: z.string().min(1).max(80),
        description: z.string().max(500).optional(),
        sensitivity: prototypeSensitivitySchema
      })
    )
    .min(1),
  /** Procesos de negocio relacionados (docs/04: "procesos relacionados"). */
  relatedProcesses: z.array(z.string().min(1).max(200)).default([])
});
export type PrototypeManifest = z.infer<typeof prototypeManifestSchema>;

/** Fila de GET /factory-api/modules — catálogo para antiduplicación desde Cowork (docs/04, list_modules). */
export const factoryModuleSummarySchema = z.object({
  moduleSlug: z.string(),
  displayName: z.string(),
  status: factoryProjectStatusSchema,
  latestSpecVersion: z.number().int().nullable(),
  /** Primeras líneas de la spec funcional vigente (o null si aún no hay spec). */
  specSummary: z.string().nullable()
});
export type FactoryModuleSummary = z.infer<typeof factoryModuleSummarySchema>;
export const factoryModulesResponseSchema = z.array(factoryModuleSummarySchema);

/** POST /factory-api/submissions — submittedBy sale SIEMPRE del actor autenticado, nunca del body. */
export const factorySubmissionRequestSchema = z.object({
  moduleSlug: z
    .string()
    .min(3)
    .max(60)
    .regex(/^[a-z][a-z0-9-]*[a-z0-9]$/, 'slug en kebab-case (minúsculas, dígitos y guiones)'),
  displayName: z.string().min(1).max(120),
  /** HTML autocontenido del prototipo (la fuente completa, no una ruta). */
  sourceHtml: z.string().min(1).max(5_000_000),
  manifest: prototypeManifestSchema
});
export type FactorySubmissionRequest = z.infer<typeof factorySubmissionRequestSchema>;

export const factorySubmissionResponseSchema = z.object({
  projectId: z.string(),
  submissionId: z.string(),
  moduleSlug: z.string(),
  status: factoryProjectStatusSchema,
  /** Mensaje para mostrar al gerente (qué sigue: análisis pendiente, D-036 incremento A). */
  message: z.string()
});
export type FactorySubmissionResponse = z.infer<typeof factorySubmissionResponseSchema>;

/** POST /factory-api/change-requests — requestedBy sale del actor autenticado. */
export const factoryChangeRequestRequestSchema = z.object({
  projectId: z.uuid(),
  requestText: z.string().min(10).max(4000)
});
export type FactoryChangeRequestRequest = z.infer<typeof factoryChangeRequestRequestSchema>;

export const factoryChangeRequestResponseSchema = z.object({
  id: z.string(),
  createdAt: z.iso.datetime(),
  projectId: z.string(),
  requestedBy: z.string(),
  requestText: z.string()
});
export type FactoryChangeRequestResponse = z.infer<typeof factoryChangeRequestResponseSchema>;
