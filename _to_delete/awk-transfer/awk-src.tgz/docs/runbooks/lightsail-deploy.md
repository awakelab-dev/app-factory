# Runbook · Deploy de la plataforma en el Lightsail de cómputo

> Runbook operativo. Ejecuta D-003/D-013/D-015/**D-016** sobre el Lightsail de
> 32 GB **existente y compartido** del grupo (Nginx nativo + certbot + pm2 +
> otras apps; no se toca nada de eso). Última revisión: 2026-07-13 (dominios
> actualizados a `apps.awakelab.world` por D-018 — ver
> `docs/runbooks/migracion-dominio-2026-07.md` para el cutover del dominio
> anterior en el server ya provisionado).
>
> **Por qué este runbook es manual y no lo corrió Claude directamente**: el
> sandbox de Cowork corre en una red aislada con proxy/allowlist — no tiene
> ruta TCP directa a `13.38.161.213:22` (verificado: `Network is unreachable`).
> Los pasos de esta página los ejecuta Leonardo por SSH normal desde su Mac.
> Una vez configurados los GitHub Secrets (paso 7), los deploys *sucesivos*
> sí son automáticos (GitHub Actions corre en runners con salida a
> internet normal, no en este sandbox).

## Qué existe ya (no crear de nuevo)

- Docker Engine 29.6.1 + Compose v2 instalados (D-015).
- Lightsail managed PostgreSQL 18.4 en `eu-west-3`, modo privado, bases
  `awkplatform_staging` y `awkplatform_production` creadas (ver
  `docs/runbooks/lightsail-postgres.md`). Faltan los roles de app (paso 5).
- Nginx nativo + certbot ya en uso por otras apps del grupo — solo se
  **añaden** server blocks nuevos, sin tocar los existentes.

## Dominios y puertos de esta tarea

| Entorno | Dominio | API (host) | Web (host) |
|---|---|---|---|
| staging | `staging.apps.awakelab.world` | 127.0.0.1:18100 | 127.0.0.1:18101 |
| production | `apps.awakelab.world` | 127.0.0.1:18102 | 127.0.0.1:18103 |

> Dominios migrados desde `staging.factory.wiloxagency.com` /
> `production.factory.wiloxagency.com` el 2026-07-13 (D-018). Si esta página
> se usa para reconstruir el server desde cero, usa directamente los dominios
> de arriba. Si el server ya existe con los dominios viejos, sigue primero
> `docs/runbooks/migracion-dominio-2026-07.md`.

Los puertos 18100-18103 son una elección "poco común" **a confirmar** en el
paso 1 — no chocan con nada conocido, pero nadie con acceso al server los
verificó contra el uso real de pm2/Nginx antes de escribir este runbook.
Los contenedores se publican solo en `127.0.0.1` (no en la interfaz
pública): el único camino de entrada es el Nginx del host.

## 0 · Autorizar la deploy key

Se generó un par de llaves **dedicado solo a este deploy** (no reutiliza
ninguna llave personal). La pública debe añadirse al server; la privada se
guarda como GitHub Secret (paso 7), nunca en el repo.

Clave pública a autorizar (usuario `ubuntu`):

```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILbOASwI0mV1bbHB1UxvDCoGAocyQDnI2r35kbEPt/UF awk-deploy@lightsail
```

En el server:

```bash
echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILbOASwI0mV1bbHB1UxvDCoGAocyQDnI2r35kbEPt/UF awk-deploy@lightsail" >> ~/.ssh/authorized_keys
```

La llave privada correspondiente se entrega junto con este runbook (archivo
`awk_deploy_ed25519`, fuera del repo) — solo úsala para el GitHub Secret del
paso 7 y luego bórrala de donde la hayas copiado.

## 1 · Confirmar puertos libres

```bash
ss -tlnp | grep -E ':(18100|18101|18102|18103)\b' || echo "libres"
```

Si alguno está ocupado, cambia `API_PORT_HOST`/`WEB_PORT_HOST` en el `.env`
del entorno correspondiente (paso 3) — **no** en `deploy/docker-compose.yml`
ni en los server blocks sin actualizar ambos a la vez.

## 2 · Estructura de directorios

```bash
sudo mkdir -p /opt/awkfactory/staging /opt/awkfactory/production
sudo chown ubuntu:ubuntu /opt/awkfactory/staging /opt/awkfactory/production
```

Copia el compose (idéntico para ambos entornos, sin secretos) a los dos:

```bash
# desde tu Mac, con el repo ya clonado:
scp deploy/docker-compose.yml AWK-Dev:/opt/awkfactory/staging/docker-compose.yml
scp deploy/docker-compose.yml AWK-Dev:/opt/awkfactory/production/docker-compose.yml
```

## 3 · Secretos por entorno (`.env`, fuera del repo)

Parte de `deploy/staging.env.example` y `deploy/production.env.example`
(están en el repo, sin secretos reales). **No hay repo clonado en el server**
(ni falta que lo haya, ver paso 6) — cópialos igual que el compose del paso 2,
**desde tu Mac**, con el repo local:

```bash
scp deploy/staging.env.example    AWK-Dev:/opt/awkfactory/staging/.env
scp deploy/production.env.example AWK-Dev:/opt/awkfactory/production/.env
```

Y ya en el server, edita cada uno para rellenar los valores reales:

```bash
nano /opt/awkfactory/staging/.env
nano /opt/awkfactory/production/.env
```

Rellena en cada `.env`:
- `DATABASE_URL`: con el rol `app_staging` / `app_production` (paso 5) y el
  endpoint real de la managed (`docs/runbooks/lightsail-postgres.md`).
- `JWT_SECRET`: `openssl rand -base64 48` — **distinto** en cada entorno.
- Puertos confirmados en el paso 1.

`chmod 600` a ambos `.env` (contienen credenciales de BD):

```bash
chmod 600 /opt/awkfactory/staging/.env /opt/awkfactory/production/.env
```

## 4 · Autenticar el server contra GHCR

Verifica primero si ya hay credenciales guardadas:

```bash
cat ~/.docker/config.json 2>/dev/null | grep -q ghcr.io && echo "ya autenticado" || echo "falta login"
```

Si falta: crea un PAT de GitHub (Settings → Developer settings → Personal
access tokens → **classic**, scope únicamente `read:packages`) del usuario
que tiene acceso a `awakelab-dev/app-factory`, y:

```bash
docker login ghcr.io -u <tu-usuario-github> -p <PAT>
```

Este login persiste en `~/.docker/config.json` del usuario `ubuntu` — no
hace falta repetirlo en cada deploy (ni pasarlo por los workflows de CI).

## 5 · Roles de app en la managed PostgreSQL

Si `docs/runbooks/lightsail-postgres.md` paso 9 aún no se ejecutó, hazlo
ahora (conectado como `dbmasteruser` a la base `postgres`):

```sql
CREATE ROLE app_staging    LOGIN PASSWORD '<secreto-staging>';
CREATE ROLE app_production LOGIN PASSWORD '<secreto-production>';

GRANT ALL PRIVILEGES ON DATABASE awkplatform_staging    TO app_staging;
GRANT ALL PRIVILEGES ON DATABASE awkplatform_production TO app_production;
```

**No te saltes esto**: además, conectado a **cada base** (no a `postgres`),
otorga el schema `public` — sin esto la migración falla con
`permission denied for schema public` (Prisma pone ahí su tabla interna
`_prisma_migrations` aunque los datos vivan en `core`; ver detalle en
lightsail-postgres.md):

```sql
\c awkplatform_staging
GRANT USAGE, CREATE ON SCHEMA public TO app_staging;

\c awkplatform_production
GRANT USAGE, CREATE ON SCHEMA public TO app_production;
```

Usa esos mismos secretos en los `DATABASE_URL` del paso 3.

## 6 · Primer arranque + migración de staging

```bash
cd /opt/awkfactory/staging
docker compose --env-file .env -p awk-staging pull
docker compose --env-file .env -p awk-staging up -d
docker compose -p awk-staging ps   # ambos healthy
```

Migración + seed (primera vez, imagen "migrator" de GHCR — ver D-016). Copia
el script desde tu Mac (mismo patrón que los pasos 2-3, no hace falta clonar
el repo en el server):

```bash
# desde tu Mac:
scp deploy/scripts/migrate.sh AWK-Dev:~/migrate.sh
ssh AWK-Dev chmod +x ~/migrate.sh

# ya en el server:
~/migrate.sh staging latest --seed
```

Verifica sin pasar aún por Nginx:

```bash
curl -s http://127.0.0.1:18100/api/hello   # health público, 200
curl -s http://127.0.0.1:18101/health      # web, "ok"
```

## 7 · Nginx + certbot para los dominios nuevos

Copia el server block desde tu Mac (mismo patrón que los pasos anteriores):

```bash
# desde tu Mac:
scp deploy/nginx/staging.conf AWK-Dev:~/staging.apps.awakelab.world

# ya en el server:
sudo mv ~/staging.apps.awakelab.world /etc/nginx/sites-available/staging.apps.awakelab.world
sudo ln -s /etc/nginx/sites-available/staging.apps.awakelab.world /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d staging.apps.awakelab.world
```

Repite para producción con `deploy/nginx/production.conf` y
`apps.awakelab.world` (el compose de producción puede quedar arriba sin
tráfico real hasta la primera promoción — pasos 2-4 y Nginx/certbot sí
conviene dejarlos listos ahora).

> **Cuidado al editar el server block DESPUÉS de correr certbot** (p. ej. para
> subir `proxy_read_timeout` u otro ajuste, ver moodle-insights/D-022):
> `certbot --nginx` reescribe el archivo en vivo en `/etc/nginx/sites-available/`
> para añadirle el bloque `listen 443 ssl` + `ssl_certificate`/`ssl_certificate_key`
> + el redirect 80→443 — el `staging.conf`/`production.conf` del repo son solo
> la plantilla HTTP original, **sin ese bloque**. Reproducido el 2026-07-13:
> sobreescribir el archivo del server con un `scp` directo del `.conf` del
> repo borró el bloque SSL y el navegador mostró "This Connection Is Not
> Private" (certificado no coincide). El certificado en `/etc/letsencrypt/`
> no se pierde — la forma correcta de arreglarlo es volver a correr
> `sudo certbot --nginx -d <dominio>` (detecta el cert existente y
> reconstruye el bloque 443 sin tocar los `location` ya presentes). **Para
> cualquier cambio a un server block ya emitido con certbot, editar el
> archivo en el server a mano (`nano`) con solo la línea que cambia — nunca
> volver a `scp` la plantilla completa por encima.**

DNS: confirma que ambos subdominios de `apps.awakelab.world` ya apuntan
(registro A) a `13.38.161.213` antes de pedir el certificado — certbot
falla si el dominio no resuelve al server.

## 8 · GitHub Secrets para el deploy automático

En `awakelab-dev/app-factory` → Settings → Secrets and variables → Actions:

| Secret | Valor |
|---|---|
| `LIGHTSAIL_HOST` | `13.38.161.213` |
| `LIGHTSAIL_SSH_USER` | `ubuntu` |
| `LIGHTSAIL_SSH_KEY` | contenido completo de la llave **privada** `awk_deploy_ed25519` (paso 0) |

Con esto, `.github/workflows/deploy.yml` despliega **staging automáticamente**
cada vez que `CI` termina en verde sobre `main`. Producción se promueve a
mano: Actions → **Deploy** → *Run workflow* → `image_tag` = el `sha` que ya
se validó en staging.

## 8b · Worker de análisis de la Fábrica (`factory-runner`, D-047)

El servicio que hace que un prototipo enviado desde Cowork **avance solo**, sin
que Sistemas lance ningún comando. Es el único contenedor que ejecuta el Agent
SDK, así que es el único con checkout del monorepo y `ANTHROPIC_API_KEY`.

**1 · Deploy key de SOLO LECTURA para el repo** (el server nunca ha clonado el
repo: hasta ahora solo bajaba imágenes de GHCR). Como root, porque el contenedor
corre como root y debe ser dueño de lo que escribe en el checkout:

```bash
sudo ssh-keygen -t ed25519 -N "" -C "awkfactory-runner@lightsail" -f /root/.ssh/id_ed25519
sudo ssh-keyscan github.com | sudo tee -a /root/.ssh/known_hosts
sudo cat /root/.ssh/id_ed25519.pub
```

Esa pública se añade en GitHub → repo → *Settings → Deploy keys → Add deploy key*,
**sin marcar "Allow write access"**. El worker solo necesita leer.

**2 · Checkout dedicado** (NUNCA un working copy de una persona: el worker hace
`git reset --hard` sobre él antes de cada análisis):

```bash
sudo git clone git@github.com:awakelab-dev/app-factory.git \
  /opt/awkfactory/staging/platform-repo
```

Para analizar NO hace falta `pnpm install`: el agente solo lee código y escribe
markdown. Si prefieres arrancar sin deploy key, deja `FACTORY_WORKER_GIT_SYNC=0`
— el worker avisa en el log y analiza con lo que haya en el checkout, que se irá
quedando viejo a medida que se mergeen módulos nuevos.

**3 · Variables** en `/opt/awkfactory/<entorno>/.env` (plantilla al final de
`deploy/staging.env.example`): `ANTHROPIC_API_KEY`, `PLATFORM_REPO_HOST_PATH`,
`PLATFORM_REPO_REF`, `FACTORY_WORKER_GIT_SYNC`, `FACTORY_RUNNER_SSH_PATH`,
`FACTORY_WORKER_POLL_MS`. Y **copia el compose nuevo** desde el Mac (el del
server es una copia, no sale de un clone): `scp deploy/docker-compose.yml
AWK-Dev:/opt/awkfactory/staging/docker-compose.yml`. Sin esas variables el
`docker compose up -d` falla por el volumen vacío.

**4 · Migración y arranque**:

```bash
~/migrate-factory.sh staging latest          # aplica 20260815120000_analysis_jobs
cd /opt/awkfactory/staging
docker compose --env-file .env -p awk-staging pull
docker compose --env-file .env -p awk-staging up -d factory-runner
docker compose -p awk-staging logs -f factory-runner
```

En el arranque debe aparecer `entorno OK (checkout /platform-repo)` seguido de
`Worker de análisis arrancado`. Si falta configuración, el contenedor **sale con
código 1 y lo dice** — deliberado: más vale que no levante a que se vaya comiendo
los trabajos de la cola marcándolos en error de uno en uno.

**5 · Prueba de humo** (desde Cowork o por CLI):

```bash
pnpm --filter=@awk/factory run cli -- enqueue-analysis --project <projectId>
# el worker debe tomarlo en <10 s; seguirlo por logs
```

**Coste**: cada análisis ronda 1,4 USD (D-046). El worker corre de uno en uno a
propósito — es lo que acota el gasto y la RAM del Lightsail, que es compartido.

## 9 · Verificación final (cerrar solo cuando todo ✅)

- [ ] `https://staging.apps.awakelab.world/api/hello` responde 200 por HTTPS.
- [ ] `https://staging.apps.awakelab.world` sirve el shell web.
- [ ] Dev-login (`POST /api/auth/dev-login`) funciona contra staging con
      `leonardo.barreto@awakelab.dev` (admin) — confirma que apunta a la
      managed real, no a un Postgres local.
- [ ] `docker compose -p awk-staging ps` → todos los servicios `healthy`.
- [ ] `factory-runner` arrancado con `entorno OK` en el log y un análisis de
      prueba tomado de la cola en menos de 10 s (D-047).
- [ ] Push a `main` dispara `Deploy` → job `staging` en verde sin intervención.
- [ ] Producción: estructura y Nginx listos; primera promoción manual
      ejecutada y verificada igual que staging.
- [ ] `docs/STATUS.md` actualizado con el resultado real (dominios, puertos
      confirmados, cualquier desvío de este runbook).

## Referencias

- [D-003](../DECISIONES.md), [D-013](../DECISIONES.md), [D-015](../DECISIONES.md), D-016 (este runbook)
- [03 · Arquitectura](../03-arquitectura.md)
- [lightsail-postgres.md](lightsail-postgres.md) — roles de app y `DATABASE_URL`
