# Runbook · Provisión de Lightsail managed PostgreSQL (consola AWS)

> Runbook operativo, no de estrategia. Ejecuta el aprovisionamiento de la base de datos gestionada definida en **[D-004](../DECISIONES.md)** y **[roadmap Fase 0](../06-roadmap.md)**. Última revisión: 2026-07-11 (precios/planes verificados en la página de precios de AWS Lightsail ese día).

## Qué vas a crear

Una instancia **Lightsail managed database PostgreSQL**, plan **Standard $30/mes** (2 GB RAM · 1 vCPU · 80 GB SSD · 100 GB transfer/mes · **cifrado en reposo**), en **modo privado**, en la **misma región** que el resto de Lightsails del grupo. Sobre esa única instancia conviven dos bases lógicas: `staging` y `production` (roadmap Fase 0).

Por qué este plan exactamente: es el escalón más pequeño que **cifra en reposo** ($15 no cifra → descartado en D-004). El plan HA ($60) duplica el precio para alta disponibilidad que a esta escala no se paga (D-004). No Aurora.

## Prerrequisitos (leer antes de tocar la consola)

1. **Región — decisión crítica e irreversible sin migración.** El "modo privado" de Lightsail es *scoped por región*: la BD solo es alcanzable por recursos Lightsail de **su misma región**. Debes crearla en la **misma región donde vive (o vivirá) el Lightsail de 32 GB** que aloja plataforma+fábrica, y esa región debe ser la del grupo. RGPD → región de la UE (p. ej. `eu-west-3` París o `eu-central-1` Fráncfort). **Confirma la región del grupo antes de crear.** Cambiar de región después obliga a snapshot + recrear.
2. **Versión de PostgreSQL: 18.x** (D-012; corrige el 16 que decía una versión anterior de este runbook). Lightsail ofrece hasta 18.4 (verificado en consola 2026-07-11); en greenfield se elige el major más nuevo estable por runway de soporte (EOL nov 2030 vs nov 2028 de la 16). La regla de **paridad dev=CI=prod** (D-003) se mantiene: `docker-compose.dev.yml` y CI corren `postgres:18`. Selecciona la 18.x más reciente del desplegable. Si en el futuro subes de major, súbelo **a la vez** en dev/CI y en la managed, nunca solo aquí.
3. **Acceso a la consola** con permisos de Lightsail en la cuenta AWS del grupo.
4. **El Lightsail de 32 GB no es bloqueante** para *crear* la BD, pero sí para *verificar la conexión privada* (paso 8). Puedes crear la BD en paralelo y verificar cuando el servidor exista.

## Paso a paso (consola)

### 1 · Región y arranque
- Entra a **console.aws.amazon.com/lightsail**.
- Arriba a la derecha, fija la **Región** correcta (la del grupo). Todo lo que sigue hereda esa región.
- Pestaña **Databases** → **Create database**.

### 2 · Motor y versión
- **Select a database**: `PostgreSQL`.
- **Version**: **18.x** (paridad con dev/CI, ver prerrequisito 2 y D-012). Anota la versión exacta elegida.

### 3 · Zona de disponibilidad
- Elige una **AZ dentro de la región**. Preferible la misma AZ que el Lightsail de 32 GB (menor latencia); no es obligatorio para el acceso privado (basta con la región).

### 4 · Credenciales y nombre de la BD inicial (opcional "Specify login credentials")
- Deja que Lightsail **genere la contraseña maestra** (más fuerte que una a mano). Guárdala de inmediato en el gestor de secretos del grupo / SSM Parameter Store — **no** en el repo ni en Slack.
- Usuario maestro: Lightsail lo fija en `dbmasteruser` (no editable).
- Nombre de la base inicial: p. ej. `awkplatform`. Crearemos `staging` y `production` como bases lógicas aparte en el paso 9.

### 5 · Plan
- Selecciona **Standard $30/mes → 2 GB RAM, 80 GB SSD, Data encrypted**.
- NO elijas High availability ($60) ni el de $15 (sin cifrado).

### 6 · Identificar y crear
- **Identify your database** (nombre del recurso Lightsail): p. ej. `awk-pg-prod`.
- **Create database**. Pasa a estado *Creating* → *Available* en ~10–15 min.

### 7 · Confirmar modo privado
- Abre la BD → pestaña **Networking**.
- **Public mode** debe estar **desactivado** (es el default). Así solo la alcanzan recursos Lightsail de la misma región. Déjalo así salvo necesidad puntual (import/export externo), y si lo activas, vuelve a apagarlo al terminar.

### 8 · Endpoint y prueba de conexión privada
- Pestaña **Connect**: copia **endpoint** (`ls-xxxx.xxxx.<region>.rds.amazonaws.com`), **puerto** (`5432`), usuario y contraseña.
- Desde el **Lightsail de 32 GB** (misma región), instala el cliente **v18** y prueba. Importante: el `postgresql-client` por defecto de Ubuntu 24.04 es v16, y sus meta-comandos (`\l`, `\d`) fallan contra un server 18 (`ERROR: column d.daticulocale does not exist`). Instala el cliente 18 desde PGDG para emparejar (paridad D-012):
  ```bash
  sudo apt-get install -y postgresql-common
  sudo /usr/share/postgresql-common/pgdg/apt.postgresql.org.sh -y
  sudo apt-get install -y postgresql-client-18
  psql "host=<endpoint> port=5432 user=dbmasteruser dbname=postgres sslmode=require"
  ```
  Conéctate a la base de mantenimiento **`postgres`** (siempre existe), no al nombre de la base inicial: así no dependes de recordarlo. Ya dentro, lista las bases con `\l` (cliente 18) o, si tienes el cliente 16, con SQL portable: `SELECT datname FROM pg_database WHERE datistemplate = false;`. Si conecta desde el servidor pero NO desde tu portátil, es la señal correcta de que el modo privado funciona. (El usuario maestro de Lightsail es **`dbmasteruser`**.)

### 9 · Bases lógicas y roles de aplicación (mínimo privilegio)
Conectado como `dbmasteruser` (a `postgres`), crea una base por entorno y un rol de app por entorno (nunca uses `dbmaster` desde la aplicación):
```sql
CREATE DATABASE awkplatform_staging;
CREATE DATABASE awkplatform_production;

CREATE ROLE app_staging    LOGIN PASSWORD '<secreto-staging>';
CREATE ROLE app_production LOGIN PASSWORD '<secreto-production>';

GRANT ALL PRIVILEGES ON DATABASE awkplatform_staging    TO app_staging;
GRANT ALL PRIVILEGES ON DATABASE awkplatform_production TO app_production;
```

**Falta un paso**: `GRANT ALL PRIVILEGES ON DATABASE` es a nivel de base
(`CONNECT`/`CREATE`/`TEMP`), **no** da permisos dentro del schema `public`.
Prisma migrate crea ahí su tabla interna `_prisma_migrations` (aunque los
datos de la app vivan en el schema `core`) — sin esto falla con
`permission denied for schema public` (reproducido en staging real,
2026-07-12; PG 15+ ya no da `CREATE` en `public` a `PUBLIC` por defecto).
Conéctate a **cada base** (no a `postgres`) y otorga el schema:
```sql
\c awkplatform_staging
GRANT USAGE, CREATE ON SCHEMA public TO app_staging;

\c awkplatform_production
GRANT USAGE, CREATE ON SCHEMA public TO app_production;
```
El rol de app **no** es superusuario — es exactamente lo que quieres para que la Row-Level Security del core (ver [05-gobernanza-seguridad](../05-gobernanza-seguridad.md)) tenga efecto.

### 10 · Ventanas de backup y mantenimiento
- En la BD → pestaña de configuración, revisa **preferred backup window** y **maintenance window**. Backups automáticos diarios + **point-in-time restore (7 días)** vienen activados por defecto en el plan Standard.

## Cadena de conexión para la plataforma (Prisma)

`DATABASE_URL` por entorno, inyectada como variable del *compose project* correspondiente, **fuera del repo** (fuente: SSM Parameter Store si se centraliza — ver [03-arquitectura](../03-arquitectura.md)):

```
# staging
postgresql://app_staging:<secreto>@<endpoint>:5432/awkplatform_staging?sslmode=require&uselibpqcompat=true
# production
postgresql://app_production:<secreto>@<endpoint>:5432/awkplatform_production?sslmode=require&uselibpqcompat=true
```

`sslmode=require` no es opcional: Lightsail sirve TLS y la app debe usarlo. **No** lleva `?schema=public`: el schema `core` lo gestiona Prisma vía multiSchema (`schemas = ["core"]`), no el search_path de la URL.

**`uselibpqcompat=true` tampoco es opcional** (reproducido en staging real,
2026-07-12): el driver adapter `@prisma/adapter-pg` usa `pg`/
`pg-connection-string`, que en la versión actual trata `sslmode=require`
como alias de `verify-full` (verificación completa de cadena de
certificados) en vez de la semántica estándar de libpq ("solo cifra, no
verifica"). El certificado de Lightsail falla esa verificación estricta →
`self-signed certificate in certificate chain` / `P1011`. Esto **no** afecta
al motor de migraciones (usa otra ruta de TLS y sí funciona solo con
`sslmode=require`), pero sí a todo lo que pase por `@prisma/adapter-pg`:
el seed (`prisma/seed.ts`) y la API en runtime (`prisma.service.ts`) por
igual. `uselibpqcompat=true` restaura la semántica estándar (cifra, no
verifica) — que es lo que esta arquitectura ya asume (modo privado de
Lightsail como control de acceso, no PKI).

**¿Dónde vive este valor?** La API lee `process.env.DATABASE_URL` en CLI (`prisma.config.ts`) y runtime (`prisma.service.ts`), con fallback al Postgres de Docker local. Por tanto:
- **Dev local** → `apps/api/.env` apuntando al **Postgres de Docker** (`docker-compose.dev.yml`), NUNCA a la managed. El dev diario no toca staging/prod.
- **Staging/production** → estas URLs son secretos del **entorno del deploy** (compose en el Lightsail de 32 GB / SSM). No existe destino hasta que se construya esa infra (tarea pendiente); mientras tanto, guárdalas en el gestor de secretos.
- **Migraciones contra la managed**: como la BD es **privada** (solo recursos Lightsail de su región), `prisma migrate deploy` + seed se ejecutan **desde el Lightsail de 32 GB o el runner de CI**, jamás desde un portátil. Es parte del pipeline de deploy, no un paso manual local.

## Verificación (cerrar solo cuando todo esté ✅)

- [ ] BD en estado **Available** en la región correcta del grupo.
- [ ] Plan **Standard $30**, **Data encryption = Enabled**.
- [ ] **Public mode = Off** (privado).
- [ ] `psql` conecta **desde el Lightsail de 32 GB** y **falla desde fuera** de la red Lightsail.
- [ ] Bases `awkplatform_staging` y `awkplatform_production` creadas, con roles de app de mínimo privilegio.
- [ ] Contraseñas (maestra + roles app) guardadas en el gestor de secretos, **no** en el repo.
- [ ] **Point-in-time restore probado** una vez (requisito explícito para cerrar Fase 0, roadmap): restaura a una instancia temporal, valida, y elimínala.

## Operación posterior

- **Antes de cada migración de esquema al core**: snapshot manual (Snapshots → Create snapshot). Barato ($0.05/GB-mes) y es tu rollback.
- **Escalado**: no hay resize en caliente; se hace snapshot → crear instancia mayor desde el snapshot → repuntar `DATABASE_URL`. Corte planificado de minutos.
- **Límite de transfer**: 100 GB/mes incluidos. El tráfico privado entre recursos Lightsail de la misma región no es la preocupación; vigila import/export y dumps grandes.
- **CI/tests**: NO usan esta instancia. La BD efímera de CI corre en contenedor Postgres (D-003 / arquitectura). Esta instancia es solo staging+production.

## Referencias

- [D-004 · elección de la BD](../DECISIONES.md)
- [03 · Arquitectura — tabla de infraestructura](../03-arquitectura.md)
- [06 · Roadmap — Fase 0](../06-roadmap.md)
- Precios verificados: https://aws.amazon.com/lightsail/pricing/ (sección *Managed databases*)

## Operar la BD de la PLATAFORMA a mano (roles, datos puntuales)

Añadido el 2026-08-17 (D-049): hasta entonces solo estaba documentado el túnel
a `awkfactory_*` (la base de la FÁBRICA, que es otra). Para `awkplatform_*` no
hace falta túnel — la managed PG está en modo privado y **el Lightsail sí la
alcanza**, así que se opera desde dentro:

```bash
ssh AWK-Dev

# La URL con endpoint y contraseña sale del .env del entorno, nunca del repo
# (D-008). Se extrae SOLO esa línea: sourcear el .env entero ensucia otras
# variables (el JWKS del AS lleva comillas y bash se las come).
DB=$(grep -m1 '^DATABASE_URL=' /opt/awkfactory/staging/.env | cut -d= -f2-)

# `uselibpqcompat` es un parámetro de Prisma, NO de libpq: si se lo pasas a
# psql, falla con "invalid URI query parameter". Se recorta la query string.
PG="${DB%%\?*}?sslmode=require"

psql "$PG" -c "SELECT id, email FROM core.users ORDER BY email;"
```

Si `psql` no está instalado en el host, por contenedor (la red del host alcanza
la managed PG igual):

```bash
docker run --rm -i --network host postgres:18 psql "$PG" -c "\dt core.*"
```

### Asignar roles a un usuario

Mientras no exista alta de roles en `core-admin` ni siembra desde los manifests
(backlog de D-049), es la única vía. Ejemplo con los roles de `reserva-salas`:

```sql
INSERT INTO core.roles (id, name, description)
VALUES
  (gen_random_uuid(), 'empleado',  'Empleado: consulta disponibilidad y reserva salas a su nombre'),
  (gen_random_uuid(), 'recepcion', 'Recepción: gestiona el catálogo de salas y todas las reservas')
ON CONFLICT (name) DO NOTHING;

INSERT INTO core.user_roles ("userId", "roleId")
SELECT u.id, r.id FROM core.users u, core.roles r
WHERE u.email = '<email>' AND r.name IN ('empleado', 'recepcion')
ON CONFLICT DO NOTHING;
```

> `id` NO tiene DEFAULT en Postgres: Prisma genera el uuid en el cliente, así
> que un INSERT crudo debe pasarlo (`gen_random_uuid()`).

> **Después, cerrar sesión y volver a entrar.** Los roles viajan dentro del JWT:
> con el token anterior el shell sigue filtrando el módulo aunque la BD ya diga
> otra cosa. Es el paso que parece opcional y no lo es.
